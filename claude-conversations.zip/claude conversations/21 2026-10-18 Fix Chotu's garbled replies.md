# Fix Chotu's garbled replies

Sun 18 Oct 2026, 14:24 IST to Sun 18 Oct 2026, 17:05 IST · 17 entries, 1 from you

---

**Claude** · Sun 18 Oct 2026, 14:24 IST

Fixing Chotu's garbled replies, starting with the on-phone version in your screenshots.

---

**Claude** · Sun 18 Oct 2026, 14:24 IST

I'm tracing why the on-phone model answers a feelings question with date and number puzzles.

---

_Sun 18 Oct 2026, 14:24 IST · Claude's checklist:_

> Fixing Chotu's garbled replies
> 
> ✱ Reading screenshots and finding Chotu's code
> ○ Reproduce and find the cause
> ○ Fix on-device and check cloud route
> ○ Open draft PR and drive it green

---

_Sun 18 Oct 2026, 14:26 IST · Instructions Claude sent to the PC session:_

> You are working for the Claude thread "Fixing Chotu's garbled replies" in this project. Only the bug below is your task; ignore the other items in the user's message. Report back to the session that started you by cross-session message (send_message); do not message the user.
> 
> BUG: The on-device ("ran on this phone") Chotu replies are nonsense. Student asked "How do I stop comparing myself?" and got "**Step 1: Understanding the Problem** We are given a sequence of numbers-like expressions and need to analyze their correctness...", then talk of translating a date "2023年9月5日". After "don't understand" it replied "### 2. **Analyzing the Numbers**". Raw markdown (**, ###, ---) is also shown unrendered in the chat bubbles. Talk mode should be 1-4 short warm sentences per server/src/chotu-prompt.txt.
> 
> The model is behaving as if it never got Chotu's system prompt or the user's actual text, with the wrong chat format (that "We are given..." voice is typical of Qwen3 0.6B or a Gemma model fed a mis-templated prompt). Models offered: server/src/chotu.ts MODELS (Gemma 4 E4B, Gemma 4 E2B, Qwen3 0.6B with noThink: true). Runtime: LiteRT-LM (libs.litertlm in android/app/build.gradle.kts).
> 
> Do this:
> 1. Read android/app/src/main/java/com/upscpods/app/data/Chotu.kt and ui/ChotuScreen.kt. Find exactly how the on-device prompt is built and sent to LiteRT-LM: system prompt (is it passed via the Conversation/SystemInstruction API or hand-concatenated?), chat history, any hand-written chat template tokens (e.g. <start_of_turn>, <|im_start|>, /no_think), sampler settings (temperature, topK, topP, max tokens), and whether a fresh conversation/session is created per chat or reused. Look for: hand-rolled template tokens that double up with the template LiteRT-LM already applies; the system prompt or user text getting dropped/empty; the Qwen /no_think handling leaking; history fed back wrongly; stale KV cache from a previous chat; sampler too hot.
> 2. Fix the root cause so the phone sends: Chotu's on-device system prompt + the conversation turns, in the format the LiteRT-LM API expects (prefer the library's own conversation/system-instruction API over manual template strings). Keep the on-device distress check as is. Sensible sampler for chat (e.g. temperature ~0.7, topK 40, topP 0.95) and a reply cap appropriate for talk mode. If the Lite (Qwen3 0.6B) model is simply too weak to stay on task even with a correct prompt, say so in your report rather than hiding it.
> 3. Render basic markdown in Chotu's bubbles (bold, italics, headings to bold lines, bullet lists, drop stray --- rules) using Compose AnnotatedString, no new dependency, or at minimum strip the markdown symbols. Applies to both on-device and cloud replies.
> 4. Build: run the Gradle debug build (android/ gradlew assembleDebug, or whatever android/README.md says) and fix any compile errors. If there are unit tests, run them. Don't change server/ code, signing config, keystores, or .dev.vars.
> 5. If the folder is a git repo, commit on a new branch named fix/chotu-on-device-prompt (don't push anywhere). If it isn't a git repo, don't create one; just leave the edited files.
> 6. Report back by send_message: the root cause in plain words with file:line evidence, what you changed (files and a short diff summary), build/test result with the last lines of output, the path to the built debug APK, and anything you couldn't verify (e.g. you can't run the model on a phone).

---

_Sun 18 Oct 2026, 14:26 IST · Claude's checklist:_

> Fixing Chotu's garbled replies
> 
> ✓ Read screenshots and found Chotu's code on your PC
> ✓ Checked cloud Chotu: sends the full prompt, looks fine
> ✱ Fixing the phone prompt and markdown on your PC
> ○ Build the app and check the fix

---

**Claude asked for a decision** · Sun 18 Oct 2026, 14:34 IST

**Download the 0.5 GB Chotu Lite model onto your PC to test it?**

Found the main cause: your phone always picks the smallest model, Chotu Lite (Qwen3 0.6B), and that's the one rambling. The bigger Gemma model gave three good short replies with the same rules when run on your PC. To confirm whether Lite is broken or just too weak, I want to download the same Lite file the app uses (497 MB, from Google's official Hugging Face page) to a scratch folder on your PC and replay your chat. I'm already fixing the model choice and the raw ** and ### symbols meanwhile.

- **(recommended)** Yes, download: I test Lite on your PC and tell you whether to fix it or drop it.
- No, skip it: I just make phones prefer the bigger model and keep Lite as a last resort.

---

_Sun 18 Oct 2026, 14:34 IST · Claude's checklist:_

> Fixing Chotu's garbled replies
> 
> ✓ Read screenshots and found Chotu's code on your PC
> ✓ Checked cloud Chotu: sends the full prompt, looks fine
> ✓ Traced it to the phone always picking the Lite model
> ✱ Fixing model choice and the raw ** and ### symbols
> ○ Test Lite on your PC (waiting on your yes)
> ○ Build the app and check the fix

---

_Sun 18 Oct 2026, 14:41 IST · Claude's checklist:_

> Fixing Chotu's garbled replies
> 
> ✓ Read screenshots and found Chotu's code on your PC
> ✓ Checked cloud Chotu: sends the full prompt, looks fine
> ✓ Traced it to the phone always picking the Lite model
> ✓ Fixed Lite settings, added a nonsense guard, rendered ** and ###
> **✓ Built a new debug app on your PC**
> ○ Test Lite on your PC (waiting on your yes)
> ○ Test on your phone

---

**Claude** · Sun 18 Oct 2026, 14:41 IST

I've fixed it and built a new debug app on your PC, but I haven't run it on a phone yet. Please install `android\app\build\outputs\apk\debug\app-debug.apk` and ask Chotu the same questions again.

**What was wrong:** your phone always picks the smallest model, Chotu Lite (Qwen3 0.6B), even when it could run the bigger Gemma model. The rambling came from Lite. The prompt code was fine. With the same rules, Gemma gave short, kind, on-topic replies when I ran it on your PC, for example: "Comparison is natural, but focus on your own journey…"

**What I changed:**
- Lite now always runs on the phone's processor (CPU), with the settings Qwen recommends. The graphics chip (GPU) is the most likely thing garbling it.
- Replies that slip into Chinese or start sounding like a maths problem ("We are given…") are thrown away. Online Chotu answers instead.
- Chotu is told to write plain sentences with no headings or lists. Any `**` and `###` that still come through now show as bold text and bullets, for online replies too.
- Online Chotu wasn't affected, so I didn't change it.

There's no git repo in that folder, so the files are edited in place and there's no PR.

One more call for you: Lite is weak even when it works. My recommendation is that phones with 5 GB+ RAM get Gemma (a 2.6 GB download) and only smaller phones fall back to Lite. Tell me if you want that.

---

**Edureka** · Sun 18 Oct 2026, 14:44 IST

if lite is so bad, let's stop using it. Instead we use Gemma where possible and Groq or whatever we choose as the online model router otherwise.

---

**Claude** · Sun 18 Oct 2026, 14:44 IST

Got it. I'm removing Lite, so phones use Gemma when they can and online Chotu otherwise.

---

_Sun 18 Oct 2026, 14:44 IST · Decision made: option 1 picked_

---

_Sun 18 Oct 2026, 14:44 IST · Instructions Claude sent to the PC session:_

> New task from the owner (their message is attached): stop using Chotu Lite (Qwen3 0.6B) entirely. Phones use on-device Gemma where they can; otherwise Chotu uses the online route (cloud /chotu, Groq/NVIDIA/Google router). Do NOT download the Qwen file; that test is cancelled.
> 1. server/src/chotu.ts: remove the qwen3-0.6b-int4 entry from MODELS so /models never offers it. Keep both Gemma entries as they are.
> 2. Android Chotu.kt: DeviceProbe.pick() must never return Lite; a phone that can't fit Gemma E2B (RAM/space) gets no on-device model and goes online. Remove Qwen-specific code that's now dead (custom Qwen chat template, noThink handling, Qwen sampler/CPU branch) only where clearly unused; keep the Gemma path, offTask() guard, markdown rendering and distress check. If a phone already has the Lite file downloaded, stop using it and, if there's an existing "delete model" helper, delete the file to free 0.5 GB; otherwise just ignore it. Make sure the UI copy (model picker, About, settings) no longer mentions "Lite"; if it showed a Lite option, remove it. Also fix android/README.md line about models to say Gemma E2B / E4B on-device, else online.
> 3. Check the server: run the server's typecheck/tests if package.json has them (npm test / npx tsc --noEmit). Build the Android debug APK again (same JAVA_TOOL_OPTIONS workaround as before).
> 4. Report back by send_message: what changed (files), test/build output tail, APK path, and what a phone below the Gemma threshold now sees. Don't deploy the server (no wrangler deploy) — tell me it needs a deploy instead.

---

_Sun 18 Oct 2026, 14:44 IST · Claude's checklist:_

> Removing Chotu Lite
> 
> ✓ Fixed garbled replies and rendered ** and ###
> ✱ Removing Lite from the phone and the server list
> ○ Check the server and rebuild the app
> ○ Test on your phone

---

_Sun 18 Oct 2026, 14:48 IST · Claude's checklist:_

> Removing Chotu Lite
> 
> ✓ Fixed garbled replies and rendered ** and ###
> ✓ Removed Lite from the phone and the server list
> **✓ Checked the server and rebuilt the app**
> ○ Deploy the server (your step)
> ○ Test on your phone

---

**Claude** · Sun 18 Oct 2026, 14:48 IST

Lite is gone. You need to do two things: run `npm run deploy` in `server` so live phones stop being offered it, then install the new `android\app\build\outputs\apk\debug\app-debug.apk` and try Chotu. I haven't deployed anything.

- **Phones with 5 GB+ RAM and about 3.6 GB free space** get an opt-in offer to download Gemma for offline use (2.6 GB, Wi-Fi only). They use online Chotu until it's downloaded.
- **Smaller phones** always use online Chotu. Their card says offline Chotu needs a bigger phone, and they get the usual offline line when there's no signal.
- **Phones that already downloaded Lite** delete it the next time the app opens, which frees 0.5 GB.

The server type check, the Chotu tests and the Android build all passed. The local server now lists only the two Gemma models, and online Chotu answered in the test. I didn't run the general server smoke test because it needs your editor token, and I left that file alone.

---

_Sun 18 Oct 2026, 17:05 IST · I've hit my usage limit. It resets in about 85 minutes. I'll continue then, so there's no need to do anything._
