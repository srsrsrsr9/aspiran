# Content generation prompt kit

Thu 22 Oct 2026, 18:07 IST to Thu 22 Oct 2026, 18:18 IST · 7 entries, 1 from you

---

**Edureka** · Thu 22 Oct 2026, 18:07 IST

Give me prompt, style guides, templates plus a set of 5 topics each to get Claude Sonnet 5.5 Medium to generate the following:

1. Deepstash styles shorts
2. Most addictive games - but designed to engage learners when they get bored - but made for educating them about some important topics
3. Printable notes they can download and circulate (free publicity for us, but only if these are share worthy)
4. anything else a UPSC aspirant would die for

_Attached: README.md, sample-writs.en.pdf, sample-writs.hi.pdf, print-note.html_

---

**Claude** · Thu 22 Oct 2026, 18:07 IST

I'll start by reading the existing content schemas and plans, then draft the prompts, style guides, templates and topics.

---

_Thu 22 Oct 2026, 18:07 IST · Claude's checklist:_

> Content prompt kit
> 
> ✱ Read existing schemas and prior content plans
> ○ Write prompts, style guides, templates, topics for 4 categories
> ○ Save kit to project files and your artefacts folder
> ○ Send you the kit

---

_Thu 22 Oct 2026, 18:10 IST · Claude's checklist:_

> Content prompt kit
> 
> ✓ Read existing schemas and prior content plans
> ✱ Write prompts, style guides, templates, topics for 4 categories
> ○ Build a printable-note layout and render a sample
> ○ Save kit to project files and your artefacts folder
> ○ Send you the kit

---

_Thu 22 Oct 2026, 18:14 IST · Claude's checklist:_

> Content prompt kit
> 
> ✓ Read existing schemas and prior content plans
> ✓ Build a printable-note layout and render a sample (EN + HI, one A4 page each)
> ✱ Write prompts, style guides, templates, topics for 4 categories
> ○ Save kit to project files and your artefacts folder
> ○ Send you the kit

---

_Thu 22 Oct 2026, 18:17 IST · Claude's checklist:_

> Content prompt kit
> 
> ✓ Read existing schemas and prior content plans
> ✓ Build a printable-note layout and render a sample (EN + HI, one A4 page each)
> ✓ Write prompts, style guides, templates, topics for 4 categories
> ✓ Save kit to project files and your artefacts folder
> ✓ Send you the kit

---

**Claude** · Thu 22 Oct 2026, 18:18 IST (edited)

The prompt kit is ready: [README.md](/mnt/project-files/content/prompt-kit/README.md). It has one shared system prompt, and then each category gets its own prompt, style guide, JSON template and 5 topics.

1. **Deepstash-style shorts.** These reuse the Hidden Why format, which already runs in the pipeline. The new topics include Kerala fishermen and mobile phones, Van Panchayats and the default effect.
2. **Games.** There are three modes: Pods Connect (16 tiles in 4 hidden groups, NYT-style), Higher or Lower, and Fact or Fake. Each mode has 5 topics. The pull comes from "one away" near-misses and reveals, not streaks or timers, because those would break your house rules.
3. **Printable notes.** Each note is one A4 page with a summary table, traps crossed out, "what most notes miss" and a self-test. The branding is only a small footer: "Free to print, copy and share", plus a QR code that opens the same topic in the app. I made a finished sample on the five writs, in English and Hindi (PDFs attached).
4. **Anything else.** I chose the three things aspirants pay coaching institutes for: feedback on their own Mains answers (Answer Mirror), Mains value-add sheets with data, cases and committees, and interview drills built from their own application form (DAF).

You can run it now in a claude.ai chat, and the pipeline (`generate.mjs --model claude-sonnet-5-5`) works today for the shorts. I haven't run the prompts through Sonnet 5.5 yet because this environment has no API key. Before the seven new formats work in the pipeline, each needs a template folder, and the note's QR link `upscpods.app/n/<id>` needs confirming. I also saved a copy to your artefacts folder.
