# AI models for app and content

Sun 11 Oct 2026, 07:08 IST to Sun 11 Oct 2026, 07:09 IST · 6 entries, 1 from you

---

**Edureka** · Sun 11 Oct 2026, 07:08 IST

Does it make sense to have a few models fine tuned / trained / quantized/ distilled and kept ready? What about content creation - daily content, fresh content for subjects? Any audio / video models to be used?

_Attached: models-and-content-plan.md_

---

**Claude** · Sun 11 Oct 2026, 07:08 IST

I'm starting by checking which AI pieces the app and content pipeline already use, then I'll weigh fine-tuned, quantized and audio or video models against them.

---

_Sun 11 Oct 2026, 07:08 IST · Claude's checklist:_

> Models and content plan
> 
> ✱ Reading earlier decisions on AI and content
> ○ Write the recommendation

---

_Sun 11 Oct 2026, 07:09 IST · Claude's checklist:_

> Models and content plan
> 
> ✓ Read earlier decisions on AI and content
> ✱ Writing the recommendation

---

_Sun 11 Oct 2026, 07:09 IST · Claude's checklist:_

> Models and content plan
> 
> ✓ Read earlier decisions on AI and content
> **✓ Wrote the recommendation**

---

**Claude** · Sun 11 Oct 2026, 07:09 IST

I need one decision from you: should the app read cards aloud in the phone's built-in voice? Everything else below works without that answer. The full plan is in [models-and-content-plan.md](/mnt/project-files/research/models-and-content-plan.md).

**Models.** Yes, keep models ready, but use the quantized versions that already exist (Gemma 4 E2B/E4B, EmbeddingGemma, Llama Guard). Pin one version of each and host the files yourself. The only training worth doing now is small classifiers on top of EmbeddingGemma for distress, syllabus tagging and pod matching. They're tiny, and every moderator decision makes them better. I'd only fine-tune Gemma for Chotu if the pilot shows its Hindi or tone falls short. By then your editors will have approved thousands of items to train on. Don't distill a model or train one from scratch, because nothing on the phone needs it.

**Content.** Keep the current Haiku pipeline and add two lanes:
- A daily lane: an early-morning job turns primary sources (PIB, PRS, RBI, court judgments) into Chai cards and a few interactive items. It runs through the Batches API and the drafts reach the desk before morning.
- A subject lane: a syllabus map for GS1-4, filled one paper at a time. I'd start with Polity. Haiku writes the bulk, and a larger Claude model writes the reasoning-heavy types, like answer skeletons and ethics.
- Editor time is what limits volume, not model cost. I'd cap daily output at what two editors can approve in both languages.

**Audio and video.**
- Narrations, quotes and anything in a person's voice stay human-recorded.
- For voice input, use the phone's own speech recogniser.
- No generative video. Render reels from the JSON timelines you already have.
- No image models either, since they get Indian map borders wrong.

**The decision.** Adding "read aloud" in the phone's built-in voice would change the earlier no-AI-voice rule. It's free, works offline in Hindi, and would be labelled as a device voice. I'd add it for accessibility, but it's your call.
