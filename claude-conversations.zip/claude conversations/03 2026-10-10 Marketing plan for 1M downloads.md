# Marketing plan for 1M downloads

Sat 10 Oct 2026, 16:56 IST to Sun 11 Oct 2026, 23:32 IST · 42 entries, 3 from you

---

**Claude** · Sat 10 Oct 2026, 16:56 IST

Marketing plan for 1M downloads

_Attached: UPSC Pods: Marketing Plan to 1M Downloads, UPSC Pods Launch Kit, Pods Routine Builder, UPSC Pods Website, akela-nahi-preview.mp4, akela-nahi-lyrics-and-storyboard.md, akela-nahi-hinglish.mp4, akela-nahi-english.mp4, akela-nahi-telugu.mp4, akela-nahi-tamil.mp4, akela-nahi-bengali.mp4_

---

_Sat 10 Oct 2026, 16:56 IST · Claude's checklist:_

> Marketing plan for 1M downloads
> 
> ✱ Opening the plan as a Claude Doc
> ○ Read the founding brief and research thread
> ○ Check the content plan thread for overlap
> ○ Write each section of the plan
> ○ Share the doc

---

**Claude** · Sat 10 Oct 2026, 16:56 IST

The plan's outline is up in a doc. I'm reading the founding brief before I fill it in.

---

_Sat 10 Oct 2026, 16:57 IST · Claude's checklist:_

> Marketing plan for 1M downloads
> 
> ✓ Opened the plan as a Claude Doc
> ✓ Read the founding brief and research thread
> **✓ Checked the content plan thread for overlap**
> ✱ Writing each section of the plan
> ○ Draw the growth target and channel mix
> ○ Share the doc

---

_Sat 10 Oct 2026, 17:01 IST · Claude's checklist:_

> Marketing plan for 1M downloads
> 
> ✓ Opened the plan as a Claude Doc
> ✓ Read the founding brief and research thread
> ✓ Checked the content plan thread for overlap
> ✓ Wrote each section of the plan
> **✓ Drew the growth target and channel mix**

---

**Claude** · Sat 10 Oct 2026, 17:01 IST (edited)

The [marketing plan](https://claude.ai/code/artifact/18cd7d6f-4faf-4cde-a848-e2110066c4e1) is ready. You can edit it directly or leave comments and I'll revise.

It gets to 1M installs by December 2027. About 85% of that is planned to come from channels the app owns: pod invites, share cards, the daily Chai card with short explainer videos, Play Store search and community channels. Paid ads make up the other 15% and only run around the notification, Prelims and the Prelims result. The total budget is about ₹1.45 crore. Every figure in the plan is a planning estimate, not measured data.

Four calls are yours. I used the first option in each:
1. **Deadline:** 31 Dec 2027 (recommended), or tie it to the 2028 cycle.
2. **Audience:** UPSC plus state PSC aspirants from launch (recommended). UPSC alone makes 1M much harder, because only about 10 lakh people apply each year.
3. **Budget:** about ₹1.45 crore (recommended), or a lean plan with no ads, which I'd expect to reach roughly 600k to 700k.
4. **Public launch:** early December 2026 (recommended), after the closed test.

Two app issues affect downloads:
- **App size:** the current test build is 65 MB because the on-device AI is bundled in. Making the AI a separate download would keep the install small for low-end phones.
- **App name:** "UPSC" in the name may need a quick legal check, since it could look like the app is affiliated with UPSC.

[Edit: the plan now uses the content plan's own format names and posting schedule, so the two plans match.]

---

_Sat 10 Oct 2026, 17:28 IST · Note from the coordinator:_

> The user wants roughly the first 10% of your marketing plan actually built, as output they can preview (see attached). Default: pick the earliest, highest-leverage pieces (for example Play Store listing copy and screenshots mockups, a few launch posts or share cards, the pod invite flow copy) and deliver them as previewable artifacts or files. Don't publish or post anything externally. The content thread is doing the same for its plan, so coordinate on shared assets.

---

_Sat 10 Oct 2026, 17:29 IST · Claude's checklist:_

> Building the first 10% of the marketing plan
> 
> ✱ Agreeing shared assets with the content thread
> ○ Write Play Store listing copy (English and Hindi)
> ○ Design store screenshots and share cards
> ○ Write pod invite, Parent page and launch posts
> ○ Publish a preview page

---

_Sat 10 Oct 2026, 17:29 IST · Claude's checklist:_

> Building the first 10% of the marketing plan
> 
> **✓ Agreed shared assets with the content thread**
> ✱ Writing Play Store listing copy (English and Hindi)
> ○ Design store screenshots and share cards
> ○ Write pod invite, Parent page and launch posts
> ○ Publish a preview page

---

_Sat 10 Oct 2026, 17:33 IST · Claude's checklist:_

> Building the first 10% of the marketing plan
> 
> ✓ Agreed shared assets with the content thread
> ✓ Wrote Play Store listing copy (English and Hindi)
> ✓ Designed store screenshots and share cards
> ✓ Wrote pod invite, Parent page and launch posts
> **✓ Published a preview page**

---

**Claude** · Sat 10 Oct 2026, 17:33 IST (edited)

The first 10% of the marketing plan is built: [UPSC Pods Launch Kit](https://claude.ai/artifact/WyCpp4nn9qXAHqHbEtbRY7). You can switch the whole page between English and Hindi, and nothing has been posted anywhere.

It covers the pieces launch day needs first:
- **Play Store listing.** The text is checked against Play's length limits.
- **Store screenshots.** Five layouts in the order people swipe through them.
- **Share cards.** A Wins card and an attempts and age card, with a calculator that works on the page.
- **Pod invite.** Three screens plus the WhatsApp message the friend receives.
- **Parent page.** The one-page note a member can send home.
- **Week-1 posts.** For Telegram, r/UPSC, Instagram and the WhatsApp Channel.

~~The Chai of the Day card visuals in the screenshots are placeholders.~~ [Edit: the screenshots and posts now use the same sample Chai cards as the content preview. The kit links to that preview for the Chai of the Day card, the chai sound and the sample reel.]

Before anything here goes live, three things need a check:
- The calculator's attempt and age rules against the CSE 2027 notice.
- The helpline numbers, with a test call.
- The app name, for the legal check.

---

**Claude** · Sat 10 Oct 2026, 20:00 IST

I've updated the [launch kit](https://claude.ai/artifact/WyCpp4nn9qXAHqHbEtbRY7) and the plan with your ask to credit the great thinkers. Nothing has been sent or posted.

- **Play listing:** it now opens with "No rank promises. No countdowns. No toppers' secret notes." It also says the app is built on research by Kahneman, Oakley and others, and that they have not endorsed it.
- **Screenshot captions:** they now describe what the aspirant gets, for example "Close the day without the 11 pm guilt".
- **Parent page:** it now gives parents a role ("Ask about the week, not the rank") and the 2026 numbers. Of every 1,000 people who sat Prelims, about 24 reached Mains and there are about 2 posts. These need checking on upsc.gov.in.
- **Weekly quote post:** I've drafted one, with a Sun Tzu line from a public-domain translation and a link to read it free.
- **Email to living authors:** a draft asking for a 30-second message to aspirants and nothing else. It's for you to review and send.

I left out photos of the thinkers and any imitation of their voices, because using those without written permission isn't allowed. The post and the email use drawn portraits and recordings the authors make themselves instead.

---

_Sun 11 Oct 2026, 10:50 IST · Note from the coordinator:_

> New items from the user's comments on the project summary (attached): marketing items M18 to M20 in sections F and G of /mnt/project-files/research/great-minds-playbook.md, covering Indian thinkers and calm and routines. Fold them into the marketing plan. Nothing gets posted publicly.

---

**Claude** · Sun 11 Oct 2026, 10:51 IST (edited)

Nothing needed from you. I've added your Indian-thinkers and routines ideas to the [marketing plan](https://claude.ai/code/artifact/18cd7d6f-4faf-4cde-a848-e2110066c4e1), and nothing has been posted:
- ~~The weekly quote post now rotates Indian thinkers such as Thiruvalluvar, Kabir, Ambedkar and Tagore, including Tamil, Kannada and Telugu posts.~~ [Edit: following your later note, the quote post now features older thinkers such as Chanakya, Thiruvalluvar, Kabir and Basavanna. Regional-language captions and comments are written in a colloquial tone, while the quotes stay formal.]
- ~~A calendar of thinker days, starting with Kalam on 15 Oct, with one useful card for each.~~ [Edit: the thinker-days calendar now covers only those older thinkers.]
- A free web routine builder that saves your day as a timetable or phone wallpaper.
- "Calm now" breathing reels with optional calm tones and no health claims.

---

_Sun 11 Oct 2026, 13:08 IST · Note from the coordinator:_

> The user decided (attached) to drop Gandhi, Ambedkar and Sen as featured thinkers and to use older figures like Chanakya instead. Your weekly quote rotation and thinker-days calendar currently include Ambedkar and similar modern figures, so please update the marketing plan to match. They also want any comments and instructions in Telugu and other languages written in a colloquial tone, while core content stays formal. No reply to the user is needed unless something is unclear.

---

_Sun 11 Oct 2026, 17:03 IST · Note from the coordinator:_

> The user asked what else can be completed (attached), so here is your share of the open list. The rationale is in /mnt/project-files/status/next-steps.md §2. Build: a web landing page with the calculator hooks, plus the free shareable routine builder (as a preview, not deployed); a wave plan for the January 2027 notification day; a thinker-anniversary calendar with older thinkers only; and a check of the Launch Kit against CCPA rules on misleading ads and dark patterns. Nothing gets posted or published publicly.

---

_Sun 11 Oct 2026, 17:03 IST · Claude's checklist:_

> Finishing the open marketing items
> 
> ✱ Building the landing page with the calculators
> ○ Build the shareable routine builder
> ○ Write the notification-day wave plan
> ○ Finalise the older-thinkers calendar
> ○ Check the launch kit against CCPA ad and dark-pattern rules

---

_Sun 11 Oct 2026, 17:07 IST · Claude's checklist:_

> Finishing the open marketing items
> 
> ✓ Built the landing page with the calculators
> ✓ Built the shareable routine builder
> ✱ Writing the notification-day wave plan
> ✓ Older-thinkers calendar already in the plan
> ○ Check the launch kit against CCPA ad and dark-pattern rules

---

_Sun 11 Oct 2026, 17:08 IST · Claude's checklist:_

> Finishing the open marketing items
> 
> ✓ Built the landing page with the calculators
> ✓ Built the shareable routine builder
> ✓ Wrote the notification-day wave plan
> ✓ Older-thinkers calendar already in the plan
> **✓ Checked the launch kit against CCPA rules and fixed 3 items**

---

**Claude** · Sun 11 Oct 2026, 17:08 IST

Nothing needed from you right now. All four marketing items are done as previews, and nothing is live or posted:
- [Website preview](https://claude.ai/artifact/GC4RfzMqoMu5NeYbToWAjw) with the attempts and cost-of-a-year calculators working, in Hindi and English.
- [Routine builder](https://claude.ai/artifact/3cw7CrG5UXKXBTfoftrcSu): pick a template, edit your day and see it as a phone wallpaper.
- The January notification-day plan is in the [marketing plan](https://claude.ai/code/artifact/18cd7d6f-4faf-4cde-a848-e2110066c4e1). The older-thinkers calendar was already in there.
- I checked the [launch kit](https://claude.ai/artifact/WyCpp4nn9qXAHqHbEtbRY7) against India's consumer-protection rules for ads and fixed three things, including dropping "free forever". The planned lawyer call should confirm the check.

---

_Sun 11 Oct 2026, 17:25 IST · Note from the coordinator:_

> The user asked to pause all activity (attached). Don't start anything new until the user says to resume.

---

_Sun 11 Oct 2026, 22:06 IST · Note from the coordinator:_

> The user is resuming with new feedback (attached). Your part is points 1 and 2: a web landing page and an app-store equivalent, probably a video. The video should be a rap with captions and music, with the vibe of the YouTube link they shared or something else that appeals to aspirants, and it must not be a boring corporate product demo. Positioning is changing to community-first, with lots of free resources and a clear path to paid; a new Community-first repositioning thread is working that out, and I'll pass its positioning to you. Rework the website preview you made, and build the video as a preview: lyrics, captions, storyboard, and a rendered captioned cut if you can (the content thread has an ffmpeg reel renderer in /mnt/project-files/content/tools). Use only music you can generate or that is licensed. Ignore the API key in the user's message; never copy it anywhere. Nothing gets posted publicly.

---

_Sun 11 Oct 2026, 22:06 IST · Claude's checklist:_

> Website and app video, community-first
> 
> ✱ Checking the reel tools and the new positioning
> ○ Write the rap lyrics and storyboard
> ○ Make an original beat and render a captioned cut
> ○ Rework the website preview community-first
> ○ Share the previews

---

_Sun 11 Oct 2026, 22:08 IST · Claude's checklist:_

> Website and app video, community-first
> 
> **✓ Checked the reel tools and the new positioning**
> ✱ Writing the rap lyrics and storyboard
> ○ Make an original beat and render a captioned cut
> ○ Rework the website preview community-first
> ○ Share the previews

---

_Sun 11 Oct 2026, 22:13 IST · Claude's checklist:_

> Website and app video, community-first
> 
> ✓ Checked the reel tools and the new positioning
> ✓ Wrote the rap lyrics and storyboard
> **✓ Made an original beat and rendered a 45s captioned cut**
> ✱ Reworking the website preview community-first
> ○ Share the previews

---

_Sun 11 Oct 2026, 22:14 IST · Note from the coordinator:_

> The positioning for the landing page and video is ready in /mnt/project-files/strategy/positioning.md, from the Community-first repositioning thread. In one line: "The free adda for UPSC aspirants. Your people, your pod, and everything you need to prep, without paying a rupee. Go Plus when you're ready to go all in." Short form: "Never prep alone." The app splits into Adda (community) and Prep (study engine, with a free tier and Plus). Chotu is drawn as a kulhad, though the founder hasn't approved that yet. Your earlier CCPA check dropped "free forever", and the spec uses that phrase for Adda, so keep it out of the marketing copy and tell me if positioning.md needs changing for that reason.

---

_Sun 11 Oct 2026, 22:18 IST · Claude's checklist:_

> Website and app video, community-first
> 
> ✓ Checked the reel tools and the new positioning
> ✓ Wrote the rap lyrics and storyboard
> ✓ Made an original beat and rendered a 45s captioned cut
> **✓ Re-cut the video to the new positioning (Adda, kulhad Chotu)**
> ✱ Reworking the website preview with Adda and Prep
> ○ Share the previews

---

_Sun 11 Oct 2026, 22:20 IST · Claude's checklist:_

> Website and app video, community-first
> 
> ✓ Checked the reel tools and the new positioning
> ✓ Wrote the rap lyrics and storyboard
> ✓ Made an original beat and rendered a 45s captioned cut
> ✓ Re-cut the video to the new positioning (Adda, kulhad Chotu)
> **✓ Reworked the website preview with Adda and Prep**
> ✓ Shared the previews

---

**Claude** · Sun 11 Oct 2026, 22:20 IST

I've reworked the [website preview](https://claude.ai/artifact/GC4RfzMqoMu5NeYbToWAjw) to put the community first, using the new positioning. "Never prep alone" leads. Below it the page splits clearly into Adda (your pod, the Commons, Chotu as an AI kulhad, and the free tools) and Prep. Plus appears only in Prep and in a short free-vs-Plus section. The app video sits in the hero.

The app video is "Akela Nahi", a 45-second Hinglish lo-fi rap with captions. It goes from a PG room at night to the pod, then Chotu, then the free Adda, and ends on "Never prep alone". The beat and visuals are our own; nothing is copied from the reference track.

One thing needs you: hiring a human rapper to record the vocals. For now the cut has captions over the beat only, with no voice. The lyrics and storyboard are in [akela-nahi-lyrics-and-storyboard.md](/mnt/project-files/marketing/app-video/akela-nahi-lyrics-and-storyboard.md). Nothing has been posted.

---

**Edureka** · Sun 11 Oct 2026, 22:31 IST

Awesome! Just the video only has music; can't hear the vocals with lyrics. And make one in English, Telugu, and more languages.

---

**Claude** · Sun 11 Oct 2026, 22:32 IST

Got it. I'll add a sung guide vocal and make English, Telugu and other language versions, starting with voice options.

---

_Sun 11 Oct 2026, 22:34 IST · Claude's checklist:_

> Vocals and language versions
> 
> ✓ Checked voice options (natural voice models are blocked here)
> ✱ Writing English, Telugu, Tamil and Bengali lyrics
> ○ Generate a synthetic guide vocal for each language
> ○ Render captioned cuts in all five languages
> ○ Share the versions

---

_Sun 11 Oct 2026, 22:37 IST · Claude's checklist:_

> Vocals and language versions
> 
> ✓ Checked voice options (natural voice models are blocked here)
> ✓ Wrote English, Telugu, Tamil and Bengali lyrics
> **✓ Generated a synthetic guide vocal for each language**
> ✱ Rendering captioned cuts in all five languages
> ○ Share the versions

---

_Sun 11 Oct 2026, 22:42 IST · Claude's checklist:_

> Vocals and language versions
> 
> ✓ Checked voice options (natural voice models are blocked here)
> ✓ Wrote English, Telugu, Tamil and Bengali lyrics
> ✓ Generated a synthetic guide vocal for each language
> **✓ Rendered captioned cuts in all five languages**

---

**Claude** · Sun 11 Oct 2026, 22:42 IST

I've made five versions, each with vocals and captions: Hinglish, English, Telugu, Tamil and Bengali.

The vocals are a generic synthetic guide voice. They sound robotic, but they let you hear the lyrics on the beat. This environment can't download natural-sounding voice models because its network blocks huggingface.co.

Before anything goes public, two things are needed. A human rapper should record each language, and a native speaker should check each set of lyrics. Want me to add Marathi, Kannada or Malayalam next?

---

**Edureka** · Sun 11 Oct 2026, 22:48 IST

Good try - the vocals are horrible but the poetry is almost there. Need some improvement on Telugu, Tamil and Bengali. Can you pull vocals from elevenlabs using their V4? Here is the api key - [REDACTED KEY]

Try for one language first and then we'll see.

---

**Claude** · Sun 11 Oct 2026, 22:48 IST

Got it. I'll try ElevenLabs vocals for one language first, using a stock voice, and keep the key out of files.

---

**Claude** · Sun 11 Oct 2026, 22:49 IST (edited)

I can't reach ElevenLabs from here, because this environment's network blocks api.elevenlabs.io. This project has no cloud environment of its own yet, so it runs on a built-in one that has no settings to change.

To allow it, open [Project settings](#project-settings/environment), choose **Add cloud environment**, and add `api.elevenlabs.io` under **Allowed domains**. It only applies to threads started after that, so tell me here once it's done.

Please also rotate that ElevenLabs key, since it's now in the chat. I haven't saved it anywhere. When the domain is open, send a fresh key and I'll do the Telugu version first with a stock voice, using ElevenLabs' newest model.

Meanwhile I've tightened the Telugu, Tamil and Bengali lyrics so the lines rhyme in couplets. For example, the Telugu now has "chaay / bye-bye" and "thodu / choodu". They're saved in the shared `marketing/app-video/source/langs` folder and still need a native speaker's check.

[Edit: the new environment is set, but this thread still can't reach ElevenLabs because it started before the change. The vocals will need a new thread. Ask in the project chat with a fresh key and it will pick up these lyrics and scripts.]

---

_Sun 11 Oct 2026, 23:31 IST · Note from the coordinator:_

> FYI: the user just set a new default cloud environment for the project, probably the ElevenLabs allowlist you asked for. Running sessions don't pick it up, only new ones. When the user returns with a fresh key, check whether api.elevenlabs.io is reachable from here. If it isn't, say they need a new thread for the vocals, and the coordinator can start one.

---

**Edureka** · Sun 11 Oct 2026, 23:32 IST

check now

---

**Claude** · Sun 11 Oct 2026, 23:32 IST

Checking whether ElevenLabs is reachable from this thread now.

---

**Claude** · Sun 11 Oct 2026, 23:32 IST

This thread still can't reach ElevenLabs. It started before the new environment, so it keeps the old network rules. I've asked for a new thread for the Telugu vocals, set up with the lyrics, beat and scripts. Paste a fresh key there once it opens.
