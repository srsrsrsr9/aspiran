# Deepstash-style insight stories

Wed 14 Oct 2026, 10:49 IST to Thu 15 Oct 2026, 05:57 IST · 31 entries, 0 from you

---

**Claude** · Wed 14 Oct 2026, 10:49 IST

Deepstash-style insight stories

_Attached: The Hidden Why, README.md_

---

_Wed 14 Oct 2026, 10:49 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✱ Studying the Deepstash screenshots
> ○ Review existing content formats
> ○ Design an insight-story format
> ○ Write sample stories on exam topics
> ○ Publish a visual preview

---

_Wed 14 Oct 2026, 10:50 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✓ Studied the Deepstash screenshots
> ✱ Reviewing existing content formats
> ○ Design an insight-story format
> ○ Write sample stories on exam topics
> ○ Publish a visual preview

---

_Wed 14 Oct 2026, 10:51 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✓ Studied the Deepstash screenshots
> ✓ Reviewed existing content formats
> ✱ Designing an insight-story format
> ○ Write sample stories on exam topics
> ○ Publish a visual preview

---

_Wed 14 Oct 2026, 10:53 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✓ Studied the Deepstash screenshots
> ✓ Reviewed existing content formats
> ✓ Designed the "Hidden Why" story format
> ✱ Writing six sample stories (EN + HI)
> ○ Publish a visual preview

---

_Wed 14 Oct 2026, 10:55 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✓ Studied the Deepstash screenshots
> ✓ Reviewed existing content formats
> ✓ Designed the "Hidden Why" story format
> ✓ Wrote six sample stories (EN + HI)
> ✱ Building the visual preview
> ○ Publish it with the proposal

---

_Wed 14 Oct 2026, 10:59 IST · Claude's checklist:_

> Deepstash-style insight stories
> 
> ✓ Studied the Deepstash screenshots
> ✓ Reviewed existing content formats
> ✓ Designed the "Hidden Why" story format
> ✓ Wrote six sample stories (EN + HI)
> ✓ Built the visual preview
> **✓ Published it with the proposal**

---

**Claude** · Wed 14 Oct 2026, 10:59 IST

I've built a proposal for a new format called **The Hidden Why**, with six sample stories you can tap through in English and Hindi: [The Hidden Why](https://claude.ai/artifact/RsVs1Xderu4TS7G3uj7ryZ).

It copies the Deepstash ad's pattern. Each story opens with a claim that sounds wrong, tells it in 5 to 7 captions over one sepia drawing that the camera pans across, and names the idea in the last frame ("Economists call this the Cobra Effect"). Then it adds three cards for the exam:
- **Say it smart:** a line of about 40 words to use in the interview or to open an answer.
- **Careful:** the nuance a board member would raise. For example, the Delhi cobra story in the ad has no archive record anyone has found, but Hanoi's 1902 rat bounty is documented.
- **Use it in:** which paper the story fits, the likely follow-up question, and the sources.

The six stories:
- The cobra effect, told through the Hanoi rat bounty
- Goodhart's law, from New York hospital report cards and ASER reading data
- The Haifa day-care fine study
- Punjab's 2009 water law and stubble fires
- The women pradhans natural experiment
- Survivorship bias, from Wald's bombers and topper talks

The packs and a README are in [content/hidden-why/](/mnt/project-files/content/hidden-why/README.md). All of them are drafts. I wrote them from memory of the named studies and have not checked them yet. Each fact that still needs a subject editor (the ASER figures, Punjab's free-power year, the Hanoi and Wald details) is flagged on its sources card, and every Hindi line needs the Hindi editor.

**What it would take to add to the app:**
- It runs on the existing Step-through engine, so no new engine is needed, only one new full-screen pan-and-caption look.
- It needs a `hidden-why` template, a few validator rules, and an "interview" entry in the exam formats, which leave the interview out today.
- Each story needs one tall illustration. My SVG drawings are only stand-ins, and an illustrator would set the etched house style for launch.

I haven't registered the template yet, so nothing in the build changes until you want it to.

---

_Wed 14 Oct 2026, 11:30 IST · Note from the coordinator:_

> The user asked to pause all work (attached). Don't start anything new until they say to resume; no reply needed.

---

_Wed 14 Oct 2026, 15:24 IST · Note from the coordinator:_

> The user says to resume and deploy once done (attached). Carry on with The Hidden Why: build it into the app as you proposed (template, validator rules, interview format, the pan-and-caption view) and ship it with the next deploy. The user hasn't reviewed the six stories yet and their facts are unchecked, so check them against sources before they go in, and leave out or mark as draft any story whose facts you can't confirm. Coordinate with the Community-first and Signup threads via send_message if you touch the same app build.

---

_Wed 14 Oct 2026, 15:24 IST · Claude's checklist:_

> Hidden Why: build into the app and deploy
> 
> ✱ Finding the app build and how deploys work
> ○ Fact-check the six stories against sources
> ○ Add template, validator rules, interview format
> ○ Build the pan-and-caption view in the app
> ○ Ship with the next deploy

---

_Wed 14 Oct 2026, 15:26 IST · I've hit my usage limit. It resets in about 13 minutes. I'll continue then, so there's no need to do anything._

---

_Wed 14 Oct 2026, 15:42 IST · Instructions Claude sent to the PC session:_

> You are working for the "Deepstash-style insight stories" thread (the user has since said "Continue all and deploy once done"). Task: add a new content type, "The Hidden Why" (schema `upsc-pods/hidden-why@1`, key `hidden-why`), to the app so it ships with the next server deploy. Do NOT deploy, run wrangler or publish.bat, commit or push: two other threads (Community-first, Signup) are also editing this folder and the Signup thread owns the server deploy. Keep edits small and additive; re-read any shared file right before editing it. Do not touch Auth*, Chotu.kt or wrangler.jsonc.
> 
> What the format is: a picture story. 5 to 8 caption frames over ONE tall illustration (360x640); each frame has `focus: [x, y, zoom]` and the view pans/zooms the illustration to that point (CSS transform `scale(z) translate((180-x)/360*100%, (320-y)/640*100%)`, x and y clamped so no edge shows, ~1.3 s ease; with reduced motion, no transition). The caption sits in a rounded white pill in the lower third, bold uppercase (no uppercase for Hindi). The last frame names the idea and uses a chai-coloured pill. After the frames come 3 cards on the app surface: (1) "Say it smart": `named` chip + `sayItSmart` quote + Copy button; (2) "Careful" text, then "If they ask next": `followUp.q` and `followUp.hint`; (3) "Use it in": `useItIn[]` as paper chip + text, then `sources[]` (show "check" on any with verify:true). Story-style progress bars at the top; tap right/left to move; it ends (no autoplay, no infinite feed). Sound: sfx/page per step, sfx/chime on the reveal frame, off until the member turns sound on, like the other types.
> 
> Pack fields: schema, id, tone, scene, tags{stage,papers,formats}, title{en,hi}, frames[{en,hi,focus}], named{en,hi}, sayItSmart{en,hi}, careful{en,hi}, followUp{q{en,hi},hint{en,hi}}, useItIn[{paper,en,hi}], linkedPacks[], sources[{label,verify}], mood, sfx, review.
> 
> Steps:
> 1. Find where the content templates, `tools/validate.mjs`, `templates/registry.json`, `templates/exam-formats.json` and the content packs live in this folder, and how the web app (server/public/app/) and the Android app render Step-through types such as story-beats. Report this to me first in one short message.
> 2. Add `templates/hidden-why/` (schema.json, fill.schema.json, config.json, brief.md, example.json) following the story-beats folder's conventions, a registry entry (engine: steps, family: Watch), and add an `interview` paper and format to exam-formats.json (the interview is currently listed as not covered; hidden-why is its first template). Make `node tools/selftest.mjs` pass.
> 3. Validator rules for hidden-why: every EN caption 16 words or fewer; 5 to 8 frames; focus within 0..360 / 0..640 and zoom 1..2.5; careful, followUp and at least one source required; EN and HI list lengths match; Devanagari in HI fields.
> 4. Web app: a renderer for hidden-why wherever story-beats is rendered, using the app's tokens. Illustrations: load `content/illustrations/hidden-why/<scene>.svg`; if missing, show a plain paper background (the caption still works). Android: if Android renders packs natively, add the same view in Compose; if that is large, do the web app only and say so.
> 5. I will send you the fact-checked packs and their SVG illustrations by message; put them where packs live (`hidden-why/`) and the SVGs under illustrations/hidden-why/. Until they arrive, test with the template example.
> 6. Run the validator on all packs, selftest, `npm run check` in server/ and any web tests that exist; screenshot the web viewer if you can.
> Final report to me: files changed, test results, whether the web and Android views are in, and anything blocking.

---

_Wed 14 Oct 2026, 15:42 IST · Claude's checklist:_

> Hidden Why: build into the app and deploy
> 
> ✓ Found the app build and how deploys work
> ✱ Fact-checking the six stories against sources
> ✱ Adding template, validator and viewer on your PC
> ○ Load the checked stories and illustrations
> ○ Hand over to the next server deploy

---

_Wed 14 Oct 2026, 15:44 IST · Instructions Claude sent to the PC session:_

> Reply to your step-1 findings. (a) Skip the Library drop folder: I'm editing the Library myself (template folder, registry, exam-formats, validator, selftest). I'll send a JSON snippet with the hidden-why entries (registry row, examFormats additions, types["hidden-why"] = {schema, fill, config, brief, example}) to merge into server/src/vendor/templates.json. (b) Yes: add a "picture" engine in engines.ts (hidden-why maps to it) plus checkPlay rules: 5 to 8 frames, focus x 0..360, y 0..640, zoom 1..2.5, careful/followUp/at least one source present, EN and HI list lengths equal. (c) Yes: the Compose HiddenWhyEngine in EngineScreens.kt, as described before. (d) Skip the web viewer, since the web app has no engine players for any type. Packs go in server/content/preview-2026-10-10/hidden-why/ and illustrations in .../illustrations/hidden-why/<scene>.svg (scenes: rats, goodhart, fine, punjab, pradhan, wald). I'll send them next; build and test against a pack shaped like the spec meanwhile. Same rules: no deploy, no commits.

---

_Wed 14 Oct 2026, 15:47 IST · Claude's checklist:_

> Hidden Why: build into the app and deploy
> 
> ✓ Found the app build and how deploys work
> ✓ Fact-checked the six stories (4 fixes made)
> ✓ Added template, validator rule and interview format
> ✱ Building the picture engine and Android view on your PC
> ✱ Preparing stories and illustrations for the app
> ○ Hand over to the next server deploy

---

_Wed 14 Oct 2026, 15:50 IST · Instructions Claude sent to the PC session:_

> Hidden Why, part 1 of 3: template data for server/src/vendor/templates.json and the validator rule. The Library copies are already updated and its selftest and validator pass.
> 
> A) In server/src/vendor/templates.json: (1) append this object to registry.types: {"key":"hidden-why","schema":"upsc-pods/hidden-why@1","title":"The Hidden Why","family":"Watch","folder":"content/hidden-why/","template":"templates/hidden-why/","new":true,"engine":"picture","wave":7,"tags":{"stage":["mains"],"papers":["interview","mains-gs2","mains-gs4","mains-essay"],"formats":["interview-talk","mains-answer"]}}  (2) registry.engines.picture = {"title":"Picture story","sfx":"A page turn per frame, a santoor chime on the frame that names the idea.","motion":"The camera pans across one illustration to each frame's focus point in 1.3 s; with motion off, each frame is a still crop."}  (3) examFormats.papers.interview = "Interview (personality test), 275 marks"; append to examFormats.formats {"id":"interview-talk","paper":"interview","name":"Talking about ideas in the interview","desc":"Explaining a concept or a piece of evidence clearly and honestly when the board asks for your view, including what the evidence does not show.","coveredBy":["hidden-why"]}; add "hidden-why" to coveredBy of format "mains-answer"; set examFormats.note to "Every UPSC CSE Prelims and Mains question format, and the templates that practise it. Format descriptions follow the public exam pattern; they are not previous-year questions. Optional-subject papers are out of scope. The interview (personality test) has one format so far, covered by hidden-why."  (4) types["hidden-why"] = {schema, fillSchema (compute it with the vendored lib: fillSchema(schema, config), and use whatever key name the other types use), config, brief} with:
> 
> schema = {"$schema":"https://json-schema.org/draft/2020-12/schema","$id":"upsc-pods/hidden-why@1","title":"The Hidden Why","type":"object","additionalProperties":false,"required":["schema","id","tone","title","mood","sfx","scene","frames","named","sayItSmart","careful","followUp","useItIn","sources","review"],"properties":{"schema":{"type":"string","const":"upsc-pods/hidden-why@1","x-from":"config"},"id":<copy story-beats' id property>,"tone":<copy story-beats' tone property>,"title":{"type":"object","additionalProperties":false,"required":["en","hi"],"properties":{"en":{"type":"string","minLength":1,"x-maxWords":8},"hi":{"type":"string","minLength":1,"x-maxWords":11}}},"mood":<copy story-beats' mood>,"sfx":<copy story-beats' sfx>,"scene":{"type":"string","pattern":"^[a-z0-9]+(-[a-z0-9]+)*$","maxLength":40,"description":"Illustration key: content/illustrations/hidden-why/<scene>.svg, drawn 360x640"},"frames":{"type":"array","minItems":5,"maxItems":8,"description":"Caption frames over one illustration. The first is the hook (a claim that sounds wrong); the last names the idea.","items":{"type":"object","additionalProperties":false,"required":["en","hi","focus"],"properties":{"en":{"type":"string","minLength":1,"x-maxWords":16},"hi":{"type":"string","minLength":1,"x-maxWords":22},"focus":{"type":"array","items":{"type":"number"},"minItems":3,"maxItems":3,"description":"[x, y, zoom] on the 360x640 illustration: where the camera pans for this frame. x 0-360, y 0-640, zoom 1-2.5"}}}},"named":BI(14,20,"The idea the story names, e.g. 'Cobra Effect (a perverse incentive)'"),"sayItSmart":BI(55,75,"A line the aspirant can say in the interview or open an answer with, first person, with the evidence in it"),"careful":BI(45,62,"The nuance a board member would raise: what is contested, what the evidence does not show"),"followUp":{"type":"object","additionalProperties":false,"required":["q","hint"],"properties":{"q":BI(16,22,"The likely next question"),"hint":BI(35,48,"How to handle it")}},"useItIn":{"type":"array","minItems":1,"maxItems":3,"items":{"type":"object","additionalProperties":false,"required":["paper","en","hi"],"properties":{"paper":{"type":"string","enum":["prelims-gs1","prelims-csat","mains-gs1","mains-gs2","mains-gs3","mains-gs4","mains-essay","interview"]},"en":{"type":"string","minLength":1,"x-maxWords":20},"hi":{"type":"string","minLength":1,"x-maxWords":28}}}},"linkedPacks":{"type":"array","items":{"type":"string"},"description":"Paths of related packs, or empty"},"sources":{"type":"array","minItems":1,"maxItems":5,"description":"The study, record or law each story stands on. Never invent a source.","items":{"type":"object","additionalProperties":false,"required":["label","verify"],"properties":{"label":{"type":"string","minLength":1,"x-maxWords":45},"verify":{"type":"boolean","description":"true until someone has checked this source"}}}},"review":<copy story-beats' review>,"tags":<copy story-beats' tags>,"provenance":<copy story-beats' provenance>}}
> where BI(a,b,desc) = {"type":"object","additionalProperties":false,"required":["en","hi"],"properties":{"en":{"type":"string","minLength":1,"x-maxWords":a},"hi":{"type":"string","minLength":1,"x-maxWords":b}},"description":desc}
> 
> config = {"schemaId":"upsc-pods/hidden-why@1","knobs":{},"defaults":{"mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs2","mains-gs4","mains-essay"],"formats":["interview-talk","mains-answer"]}},"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Generated from a template. Needs an editor check for EN and HI before publishing."}}
> 
> brief = a short markdown: "# The Hidden Why\n\nSchema: `upsc-pods/hidden-why@1` · Folder: `content/hidden-why/` · Family: Watch · Engine: picture\n\nA Deepstash-style picture story with a Freakonomics question. 5 to 8 captions (16 words or fewer) over one 360x640 illustration, each with focus [x, y, zoom]; the first is a hook that sounds wrong, the last names the idea. Then named, sayItSmart (about 40 words, with the evidence), careful (what is contested), followUp {q, hint}, useItIn (1 to 3 papers) and sources (verify true until checked). Prefer Indian evidence. No invented quotes, no result claims."
> 
> B) In server/src/vendor/pods-templates.cjs, add this rule next to RULES["long-read"]:
>   RULES["hidden-why"] = function (p, err) {
>     var fr = p.frames || [];
>     fr.forEach(function (f, i) {
>       var z = f.focus || [];
>       if (z.length === 3 && (z[0] < 0 || z[0] > 360 || z[1] < 0 || z[1] > 640)) err("$.frames[" + i + "].focus: x must be 0 to 360 and y 0 to 640");
>       if (z.length === 3 && (z[2] < 1 || z[2] > 2.5)) err("$.frames[" + i + "].focus: zoom must be 1 to 2.5");
>     });
>     var last = fr.length ? String(fr[fr.length - 1].en || "").toLowerCase() : "", name = String((p.named && p.named.en) || "").split(/[:(]/)[0].trim().toLowerCase();
>     var key = name.split(/\s+/).filter(function (w) { return w.length > 3; });
>     if (last && key.length && !key.some(function (w) { return last.indexOf(w.replace(/'s$/, "")) >= 0; })) err("$.frames: the last frame should name the idea (\"" + name + "\")");
>     if (!(p.sources || []).length) err("$.sources: name at least one study, record or law");
>   };
> 
> Note for the Android view: render the SVGs with an SVG library (for example AndroidSVG or Coil's SVG decoder), not Vector Asset import, because they contain text. Parts 2 and 3 (illustration generator and the six packs) follow.

---

_Wed 14 Oct 2026, 15:53 IST · Instructions Claude sent to the PC session:_

> Hidden Why, part 2 of 3: the illustrations. Thanks for part 1. The channel I use to send this refuses angle brackets, so every less-than sign in the script below is written {LT} and every greater-than sign is written {GT}. Save the text between the BEGIN and END lines as server/scripts/make-hidden-why-svgs.cjs (UTF-8), then replace every {LT} with a less-than sign and every {GT} with a greater-than sign (for example with a small node one-liner). Run `node server/scripts/make-hidden-why-svgs.cjs server/content/preview-2026-10-10/illustrations/hidden-why`. It should write six files. My outputs' sha256 prefixes: fine 8791bfb972081e85, goodhart 045d2a3c459310fa, pradhan bcb2018cfe9ef78a, punjab 9a75a70ed1920cc6, rats c2d0f03ebc2f693f, wald fddb371876687d54. If one differs, check that it parses as XML and has no duplicate attributes, and carry on.
> 
> ----- BEGIN -----
> /* ---------- Illustrations: 360x640 scenes in an etched, sepia print style ---------- */
> const P = {paper:"#F3E6D3", p2:"#E8D3B6", ink:"#2A211A", chai:"#8D4F01", rust:"#B4532A", teal:"#14696B", mari:"#C98A0B", grey:"#8A8079", sky:"#EFDCC2"};
> const DEFS = `{LT}defs{GT}
>  {LT}pattern id="h1" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"{GT}{LT}line x1="0" y1="0" x2="0" y2="5" stroke="${P.ink}" stroke-width=".8" opacity=".45"/{GT}{LT}/pattern{GT}
>  {LT}pattern id="h2" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(-35)"{GT}{LT}line x1="0" y1="0" x2="0" y2="4" stroke="${P.ink}" stroke-width=".7" opacity=".35"/{GT}{LT}/pattern{GT}
>  {LT}pattern id="dots" width="6" height="6" patternUnits="userSpaceOnUse"{GT}{LT}circle cx="2" cy="2" r=".8" fill="${P.ink}" opacity=".3"/{GT}{LT}/pattern{GT}
>  {LT}filter id="grain"{GT}{LT}feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" stitchTiles="stitch"/{GT}{LT}feColorMatrix values="0 0 0 0 .16 0 0 0 0 .12 0 0 0 0 .08 0 0 0 .22 0"/{GT}{LT}/filter{GT}
>  {LT}radialGradient id="vig" cx="50%" cy="45%" r="75%"{GT}{LT}stop offset="60%" stop-color="${P.ink}" stop-opacity="0"/{GT}{LT}stop offset="100%" stop-color="${P.ink}" stop-opacity=".35"/{GT}{LT}/radialGradient{GT}
> {LT}/defs{GT}`;
> const S = 'stroke="'+P.ink+'" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"';
> const T = (x,y,t,size=14,w=700,fill=P.ink,anchor="middle",fam="Georgia, serif") ={GT} `{LT}text x="${x}" y="${y}" font-family="${fam}" font-size="${size}" font-weight="${w}" fill="${fill}" text-anchor="${anchor}"{GT}${t}{LT}/text{GT}`;
> const dedupe = s ={GT} s.replace(/{LT}([a-zA-Z]+)((?:\s+[\w:-]+="[^"]*")+)\s*(\/?){GT}/g, (m, tag, attrs, slash) ={GT} { const o = new Map(); for (const [, k, v] of attrs.matchAll(/([\w:-]+)="([^"]*)"/g)) { o.delete(k); o.set(k, v); } return "{LT}" + tag + [...o].map(([k, v]) ={GT} ` ${k}="${v}"`).join("") + (slash ? "/{GT}" : "{GT}"); });
> const frame = body ={GT} dedupe(`{LT}svg viewBox="0 0 360 640" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"{GT}${DEFS}{LT}rect width="360" height="640" fill="${P.paper}"/{GT}${body}{LT}rect width="360" height="640" filter="url(#grain)"/{GT}{LT}rect width="360" height="640" fill="url(#vig)"/{GT}{LT}/svg{GT}`);
> function person(x,y,s=1,col=P.p2,extra=""){ // standing figure, feet at y
>   return `{LT}g transform="translate(${x},${y}) scale(${s})"{GT}
>    {LT}path d="M-11 0 L-9 -40 Q0 -48 9 -40 L11 0 Z" fill="${col}" ${S}/{GT}{LT}path d="M-11 0 L-9 -40 Q0 -48 9 -40 L11 0 Z" fill="url(#h2)"/{GT}
>    {LT}circle cx="0" cy="-54" r="9" fill="${P.p2}" ${S}/{GT}${extra}{LT}/g{GT}`;
> }
> function rat(x,y,s=1,flip=false,tail=false){
>   return `{LT}g transform="translate(${x},${y}) scale(${flip?-s:s},${s})"{GT}
>    ${tail?`{LT}path d="M-18 2 C-34 -2 -38 14 -54 8" fill="none" ${S} stroke-width="1.6"/{GT}`:`{LT}path d="M-19 1 l-4 1" ${S} stroke-width="2"/{GT}`}
>    {LT}ellipse cx="0" cy="0" rx="19" ry="10" fill="${P.grey}" ${S}/{GT}{LT}ellipse cx="0" cy="0" rx="19" ry="10" fill="url(#h1)"/{GT}
>    {LT}circle cx="19" cy="-3" r="8" fill="${P.grey}" ${S}/{GT}{LT}circle cx="16" cy="-11" r="4" fill="${P.p2}" ${S} stroke-width="1.5"/{GT}
>    {LT}circle cx="22" cy="-4" r="1.4" fill="${P.ink}"/{GT}{LT}path d="M-10 9 l-2 6 M8 9 l2 6" ${S} stroke-width="1.6"/{GT}{LT}/g{GT}`;
> }
> const SCENES = {
>  rats: () ={GT} frame(`
>   {LT}rect x="48" y="38" width="264" height="178" fill="${P.p2}" ${S}/{GT}{LT}rect x="48" y="38" width="264" height="178" fill="url(#dots)"/{GT}
>   {LT}circle cx="60" cy="50" r="3" fill="${P.ink}"/{GT}{LT}circle cx="300" cy="50" r="3" fill="${P.ink}"/{GT}
>   ${T(180,82,"AVIS",28,800)}${T(180,116,"PRIME : 1 CENT",19,700,P.rust)}${T(180,140,"PAR QUEUE DE RAT",15,700)}
>   {LT}line x1="90" y1="156" x2="270" y2="156" ${S} stroke-width="1.2"/{GT}${T(180,184,"HANOI · 1902",14,700,P.ink)}${T(180,202,"Le Résident-Maire",10,400,P.ink)}
>   {LT}rect x="40" y="304" width="280" height="14" fill="${P.chai}" ${S}/{GT}{LT}rect x="40" y="304" width="280" height="14" fill="url(#h1)"/{GT}
>   {LT}path d="M60 318 v70 M300 318 v70" ${S} stroke-width="5"/{GT}
>   {LT}ellipse cx="170" cy="296" rx="92" ry="15" fill="${P.p2}" ${S}/{GT}
>   ${[0,1,2,3,4,5,6,7,8].map(i={GT}`{LT}path d="M${100+i*16} 296 c 6 -14 -6 -22 4 -34" fill="none" ${S} stroke-width="1.8"/{GT}`).join("")}
>   {LT}circle cx="285" cy="292" r="10" fill="${P.mari}" ${S}/{GT}{LT}circle cx="298" cy="286" r="10" fill="${P.mari}" ${S}/{GT}${T(298,290,"1¢",9,700)}
>   {LT}path d="M0 610 H360" ${S}/{GT}{LT}rect x="0" y="610" width="360" height="30" fill="url(#h1)"/{GT}
>   ${rat(70,470,1.05)}${rat(150,505,1,true)}${rat(95,560,1.15)}${rat(205,455,.9,true)}${rat(175,590,1)}
>   {LT}rect x="226" y="520" width="112" height="86" fill="${P.p2}" ${S}/{GT}{LT}path d="M226 548 H338 M226 576 H338" ${S} stroke-width="1.4"/{GT}
>   {LT}rect x="226" y="520" width="112" height="86" fill="url(#h2)"/{GT}${rat(262,512,.75)}${rat(305,512,.75,true)}
>   ${T(282,600,"élevage",11,700,P.rust)}`),
> 
>  goodhart: () ={GT} frame(`
>   {LT}rect x="0" y="0" width="360" height="300" fill="${P.sky}"/{GT}
>   {LT}rect x="40" y="62" width="280" height="226" fill="${P.p2}" ${S}/{GT}{LT}rect x="40" y="62" width="280" height="226" fill="url(#h2)"/{GT}
>   {LT}rect x="80" y="74" width="200" height="34" fill="${P.paper}" ${S}/{GT}${T(180,99,"HOSPITAL",22,800)}
>   {LT}rect x="96" y="118" width="168" height="26" fill="${P.rust}" ${S}/{GT}${T(180,136,"SURVIVAL ★★★★★",13,700,P.paper)}
>   ${[60,100,240,280].map(x={GT}`{LT}rect x="${x-8}" y="160" width="26" height="32" fill="${P.paper}" ${S} stroke-width="1.6"/{GT}`).join("")}
>   {LT}rect x="150" y="200" width="62" height="88" fill="${P.ink}" ${S}/{GT}
>   ${person(170,286,.8,P.paper,'{LT}path d="M10 -36 l14 -10 M10 -30 l15 -2" '+S+'/{GT}')}${person(196,286,.8,P.paper)}
>   {LT}path d="M210 296 h96" ${S} stroke-width="3"/{GT}{LT}circle cx="222" cy="306" r="6" fill="${P.paper}" ${S}/{GT}{LT}circle cx="294" cy="306" r="6" fill="${P.paper}" ${S}/{GT}
>   {LT}path d="M214 290 q 40 -14 88 0" fill="${P.p2}" ${S}/{GT}
>   {LT}path d="M300 260 q 30 10 18 40" fill="none" stroke="${P.rust}" stroke-width="3" stroke-dasharray="6 5"/{GT}
>   {LT}rect x="34" y="350" width="292" height="248" rx="6" fill="#2F3A33" ${S} stroke-width="4"/{GT}
>   ${T(54,392,"ENROLLED (age 6–14)",15,700,"#EDE6D6","start")}
>   {LT}rect x="54" y="404" width="221" height="22" fill="#EDE6D6" opacity=".9"/{GT}${T(282,421,"95%+",15,800,"#EDE6D6","start")}
>   ${T(54,486,"CLASS 5 CAN READ",15,700,"#EDE6D6","start")}${T(54,506,"A CLASS 2 TEXT (govt)",15,700,"#EDE6D6","start")}
>   {LT}rect x="54" y="520" width="104" height="22" fill="${P.mari}"/{GT}{LT}rect x="54" y="520" width="233" height="22" fill="none" stroke="#EDE6D6" stroke-dasharray="4 4"/{GT}${T(166,537,"45%",15,800,"#EDE6D6","start")}
>   ${T(54,580,"ASER 2024, rural · full bar = 100%",10,400,"#EDE6D6","start","system-ui, sans-serif")}`),
> 
>  fine: () ={GT} frame(`
>   {LT}circle cx="180" cy="128" r="84" fill="${P.p2}" ${S} stroke-width="4"/{GT}{LT}circle cx="180" cy="128" r="84" fill="url(#dots)"/{GT}
>   ${Array.from({length:12},(_,i)={GT}{const a=i*Math.PI/6;return `{LT}line x1="${180+70*Math.sin(a)}" y1="${128-70*Math.cos(a)}" x2="${180+78*Math.sin(a)}" y2="${128-78*Math.cos(a)}" ${S}/{GT}`}).join("")}
>   {LT}line x1="180" y1="128" x2="${180+42*Math.sin(130*Math.PI/180)}" y2="${128-42*Math.cos(130*Math.PI/180)}" ${S} stroke-width="5"/{GT}
>   {LT}line x1="180" y1="128" x2="${180+62*Math.sin(120*Math.PI/180)}" y2="${128-62*Math.cos(120*Math.PI/180)}" ${S} stroke-width="3"/{GT}
>   {LT}circle cx="180" cy="128" r="5" fill="${P.ink}"/{GT}${T(180,236,"CLOSES 16:00",14,700,P.rust)}
>   {LT}rect x="34" y="252" width="128" height="170" fill="${P.p2}" ${S}/{GT}{LT}rect x="56" y="300" width="84" height="122" fill="${P.chai}" ${S}/{GT}{LT}rect x="56" y="300" width="84" height="122" fill="url(#h1)"/{GT}
>   {LT}rect x="58" y="264" width="80" height="24" fill="${P.paper}" ${S} stroke-width="1.5"/{GT}${T(98,281,"DAY CARE",12,800)}
>   ${person(112,420,.9,P.teal,'{LT}rect x="10" y="-30" width="16" height="12" fill="'+P.mari+'" '+S+' stroke-width="1.4"/{GT}')}
>   {LT}rect x="190" y="262" width="136" height="140" fill="${P.paper}" ${S}/{GT}{LT}path d="M190 262 l68 -16 l68 16" fill="none" ${S} stroke-width="1.4"/{GT}
>   ${T(258,292,"LATE PICKUP",14,800)}${T(258,330,"₪10",32,800,P.rust)}${T(258,354,"per child",12,400)}${T(258,374,"10 min late or more",12,400)}
>   {LT}path d="M40 600 H330" ${S}/{GT}{LT}path d="M40 600 V450" ${S}/{GT}
>   ${Array.from({length:20},(_,i)={GT}{const h=i{LT}4?26:i{LT}8?26+(i-3)*9:i{LT}16?66+(i%2)*4:68+(i%2)*3; const x=46+i*14; return `{LT}rect x="${x}" y="${600-h}" width="10" height="${h}" fill="${i{LT}4?P.grey:P.rust}" ${S} stroke-width="1"/{GT}`}).join("")}
>   {LT}path d="M100 600 V462 M268 600 V462" stroke="${P.ink}" stroke-width="1.4" stroke-dasharray="4 4"/{GT}
>   ${T(104,474,"fine starts",11,700,P.ink,"start","system-ui, sans-serif")}${T(264,474,"fine dropped",11,700,P.ink,"end","system-ui, sans-serif")}
>   ${T(185,622,"late pickups by week, 20 weeks (shape only)",10,400,P.ink,"middle","system-ui, sans-serif")}`),
> 
>  punjab: () ={GT} frame(`
>   {LT}rect width="360" height="190" fill="${P.sky}"/{GT}
>   ${Array.from({length:12},(_,i)={GT}{const a=i*Math.PI/6;return `{LT}line x1="${90+48*Math.cos(a)}" y1="${90+48*Math.sin(a)}" x2="${90+64*Math.cos(a)}" y2="${90+64*Math.sin(a)}" stroke="${P.mari}" stroke-width="3" stroke-linecap="round"/{GT}`}).join("")}
>   {LT}circle cx="90" cy="90" r="38" fill="${P.mari}" ${S}/{GT}{LT}circle cx="90" cy="90" r="38" fill="url(#h2)"/{GT}
>   {LT}rect x="214" y="44" width="112" height="112" fill="${P.paper}" ${S}/{GT}{LT}rect x="214" y="44" width="112" height="28" fill="${P.rust}" ${S}/{GT}${T(270,64,"JUNE",15,800,P.paper)}
>   ${Array.from({length:15},(_,i)={GT}`{LT}rect x="${222+(i%5)*20}" y="${80+Math.floor(i/5)*24}" width="16" height="18" fill="none" stroke="${P.ink}" stroke-width="1"/{GT}`).join("")}
>   {LT}circle cx="290" cy="113" r="13" fill="none" stroke="${P.rust}" stroke-width="3"/{GT}${T(270,152,"no paddy before this",10,700,P.ink,"middle","system-ui, sans-serif")}
>   {LT}rect x="40" y="200" width="96" height="58" fill="${P.p2}" ${S}/{GT}{LT}rect x="40" y="200" width="96" height="58" fill="url(#h1)"/{GT}${T(88,234,"PUMP",13,800)}
>   {LT}path d="M136 230 h40 v18" fill="none" ${S} stroke-width="4"/{GT}{LT}path d="M176 252 q 4 14 -2 24 M182 252 q 6 12 2 22" stroke="${P.teal}" stroke-width="2.4" fill="none"/{GT}
>   {LT}rect x="0" y="262" width="360" height="110" fill="${P.p2}"/{GT}{LT}rect x="0" y="262" width="360" height="110" fill="url(#h2)"/{GT}
>   {LT}path d="M88 258 V360" ${S} stroke-width="5"/{GT}
>   ${[300,326,352].map((y,i)={GT}`{LT}path d="M20 ${y} H330" stroke="${P.teal}" stroke-width="${3-i*.6}" stroke-dasharray="${i?'6 6':'0'}" opacity="${1-i*.25}"/{GT}`).join("")}
>   {LT}path d="M300 296 V352" stroke="${P.teal}" stroke-width="2.5"/{GT}{LT}path d="M292 344 l8 10 l8 -10" fill="none" stroke="${P.teal}" stroke-width="2.5"/{GT}${T(244,292,"water table",11,700,P.teal,"middle","system-ui, sans-serif")}
>   {LT}rect x="0" y="372" width="360" height="110" fill="${P.paper}"/{GT}
>   ${Array.from({length:30},(_,i)={GT}{const x=14+(i%10)*14, y=392+Math.floor(i/10)*30;return `{LT}path d="M${x} ${y+18} q -4 -12 -8 -16 M${x} ${y+18} q 0 -14 2 -20 M${x} ${y+18} q 4 -10 9 -14" fill="none" stroke="${P.teal}" stroke-width="1.6"/{GT}`}).join("")}
>   ${Array.from({length:14},(_,i)={GT}`{LT}path d="M${170+i*13} 478 l3 -12" ${S} stroke-width="1.5"/{GT}`).join("")}
>   {LT}path d="M190 476 q -10 -26 6 -40 q 2 16 12 10 q -4 -22 14 -34 q -2 24 14 30 q 8 -10 6 -20 q 16 18 4 54 Z" fill="${P.rust}" ${S}/{GT}
>   {LT}path d="M206 476 q -4 -16 6 -24 q 4 10 10 6 q 4 10 -2 18 Z" fill="${P.mari}"/{GT}
>   {LT}rect x="268" y="392" width="72" height="26" fill="${P.paper}" ${S} stroke-width="1.5"/{GT}${T(304,410,"LATE OCT",12,800,P.rust)}
>   {LT}path d="M0 482 H360" ${S}/{GT}
>   ${[[205,430,24],[225,400,30],[250,372,26]].map(([x,y,r])={GT}`{LT}ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.6}" fill="${P.grey}" opacity=".55"/{GT}`).join("")}
>   {LT}rect x="0" y="483" width="360" height="157" fill="${P.sky}"/{GT}
>   ${[[150,540,34],[200,552,40],[255,548,42],[310,556,36]].map(([x,y,r])={GT}`{LT}ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.45}" fill="${P.grey}" opacity=".6"/{GT}`).join("")}
>   {LT}path d="M90 520 H350" stroke="${P.ink}" stroke-width="2" stroke-dasharray="8 6"/{GT}${T(96,512,"warm layer acts as a lid",10,700,P.ink,"start","system-ui, sans-serif")}
>   ${[[200,590,22,46],[226,600,18,36],[248,580,20,56],[272,596,16,40],[292,586,22,50],[318,598,18,38]].map(([x,b,w,h])={GT}`{LT}rect x="${x}" y="${b-h+40}" width="${w}" height="${h}" fill="${P.p2}" ${S} stroke-width="1.6"/{GT}`).join("")}
>   {LT}path d="M0 636 H360" ${S}/{GT}`),
> 
>  pradhan: () ={GT} frame(`
>   {LT}path d="M130 120 q -40 40 -10 96 q 60 34 120 0 q 30 -56 -10 -96 Z" fill="${P.chai}" ${S}/{GT}{LT}path d="M130 120 q -40 40 -10 96 q 60 34 120 0 q 30 -56 -10 -96 Z" fill="url(#h1)"/{GT}
>   {LT}rect x="140" y="98" width="80" height="24" rx="4" fill="${P.chai}" ${S}/{GT}{LT}path d="M146 156 h68" stroke="${P.mari}" stroke-width="4"/{GT}
>   ${[[150,70,-14],[188,52,6],[226,74,18]].map(([x,y,r])={GT}`{LT}g transform="translate(${x},${y}) rotate(${r})"{GT}{LT}rect x="-14" y="-9" width="28" height="18" fill="${P.paper}" ${S} stroke-width="1.5"/{GT}{LT}/g{GT}`).join("")}
>   ${T(188,58,"♀",12,700,P.rust)}${T(180,244,"SEATS ROTATE",13,800,P.ink)}
>   {LT}path d="M30 400 V300 L180 262 L330 300 V400 Z" fill="${P.p2}" ${S}/{GT}{LT}path d="M30 400 V300 L180 262 L330 300 V400 Z" fill="url(#h2)"/{GT}
>   {LT}rect x="80" y="296" width="200" height="26" fill="${P.paper}" ${S}/{GT}${T(180,314,"GRAM PANCHAYAT",13,800)}
>   {LT}rect x="150" y="332" width="60" height="68" fill="${P.ink}" ${S}/{GT}
>   ${person(180,400,1.05,P.teal,'{LT}path d="M-9 -40 Q 10 -60 12 -20" fill="'+P.mari+'" '+S+' stroke-width="1.4"/{GT}')}
>   ${person(70,400,.75,P.p2)}${person(290,400,.75,P.p2)}
>   {LT}path d="M0 412 H360" ${S}/{GT}
>   {LT}rect x="166" y="452" width="28" height="120" fill="${P.grey}" ${S}/{GT}{LT}rect x="166" y="452" width="28" height="120" fill="url(#h1)"/{GT}
>   {LT}path d="M194 470 L262 440" ${S} stroke-width="6"/{GT}{LT}path d="M166 486 h-30 v12" fill="none" ${S} stroke-width="7"/{GT}
>   {LT}path d="M136 504 q -2 14 0 22 M140 506 q 2 12 0 20" stroke="${P.teal}" stroke-width="2.4" fill="none"/{GT}
>   {LT}path d="M112 528 h44 l-6 44 h-32 Z" fill="${P.mari}" ${S}/{GT}
>   ${person(270,600,.9,P.rust)}${person(306,600,.8,P.teal)}${person(60,600,.85,P.chai)}
>   {LT}path d="M0 600 H360" ${S}/{GT}{LT}rect x="0" y="600" width="360" height="40" fill="url(#h2)"/{GT}`),
> 
>  wald: () ={GT} frame(`
>   {LT}rect width="360" height="330" fill="${P.sky}"/{GT}
>   {LT}path d="M30 150 L160 132 L200 132 L330 150 L330 166 L200 168 L160 168 L30 166 Z" fill="${P.grey}" ${S}/{GT}{LT}path d="M30 150 L160 132 L200 132 L330 150 L330 166 L200 168 L160 168 L30 166 Z" fill="url(#h1)"/{GT}
>   {LT}path d="M168 58 Q180 40 192 58 L196 260 Q180 274 164 260 Z" fill="${P.grey}" ${S}/{GT}{LT}path d="M168 58 Q180 40 192 58 L196 260 Q180 274 164 260 Z" fill="url(#h1)"/{GT}
>   {LT}path d="M120 248 L240 248 L240 262 L120 262 Z" fill="${P.grey}" ${S}/{GT}
>   ${[86,128,232,274].map(x={GT}`{LT}rect x="${x-9}" y="128" width="18" height="34" rx="5" fill="${P.p2}" ${S}/{GT}`).join("")}
>   {LT}circle cx="180" cy="70" r="9" fill="${P.p2}" ${S}/{GT}
>   ${[[50,156],[62,152],[70,160],[104,150],[112,158],[150,146],[150,160],[208,148],[214,160],[248,152],[252,160],[296,154],[310,158],[318,152],[175,110],[184,122],[176,190],[186,204],[178,222],[132,254],[150,256],[214,254],[230,256],[60,162],[300,162]].map(([x,y])={GT}`{LT}circle cx="${x}" cy="${y}" r="3.2" fill="${P.rust}" stroke="${P.ink}" stroke-width=".8"/{GT}`).join("")}
>   ${[86,128,232,274].map(x={GT}`{LT}rect x="${x-14}" y="122" width="28" height="46" rx="6" fill="none" stroke="${P.teal}" stroke-width="2.4" stroke-dasharray="5 4"/{GT}`).join("")}
>   {LT}rect x="166" y="56" width="28" height="28" rx="6" fill="none" stroke="${P.teal}" stroke-width="2.4" stroke-dasharray="5 4"/{GT}
>   ${T(180,302,"armour where the holes aren't",13,800,P.teal)}
>   {LT}path d="M180 330 L120 492 L240 492 Z" fill="${P.mari}" opacity=".28"/{GT}
>   {LT}rect x="40" y="492" width="280" height="18" fill="${P.chai}" ${S}/{GT}{LT}rect x="40" y="492" width="280" height="18" fill="url(#h1)"/{GT}
>   ${person(180,492,1.2,P.rust,'{LT}path d="M12 -44 l10 -18 h10 l-2 10 q -8 6 -10 0" fill="'+P.mari+'" '+S+' stroke-width="1.5"/{GT}')}
>   ${T(180,382,"TOPPER TALK",13,800,P.chai)}
>   ${Array.from({length:22},(_,i)={GT}`{LT}g opacity=".38"{GT}${person(22+(i%11)*32,(i{LT}11?566:620),.6,P.grey)}{LT}/g{GT}`).join("")}
>   ${T(180,636,"the ones who didn't clear",11,700,P.ink,"middle","system-ui, sans-serif")}`)
> };
> 
> const fs=require("fs"),path=require("path");const out=process.argv[2];fs.mkdirSync(out,{recursive:true});
> for(const k of Object.keys(SCENES)){fs.writeFileSync(path.join(out,k+".svg"),'{LT}?xml version="1.0" encoding="UTF-8"?{GT}\n'+SCENES[k]().replace("{LT}svg ",'{LT}svg width="360" height="640" '));}
> console.log("wrote",Object.keys(SCENES).join(", "));
> ----- END -----
> 
> Part 3 (the six packs) follows.

---

_Wed 14 Oct 2026, 15:53 IST · Claude's checklist:_

> Hidden Why: build into the app and deploy
> 
> ✓ Found the app build and how deploys work
> ✓ Fact-checked the six stories (4 fixes made)
> ✓ Added template, validator rule and interview format
> ✓ Built the picture engine and Android view on your PC
> ✱ Copying stories and illustrations into the app
> ○ Run checks, then hand over to the next server deploy

---

_Wed 14 Oct 2026, 15:54 IST · Instructions Claude sent to the PC session:_

> Hidden Why, part 3a of 3: the first three packs. Save each JSON line below to server/content/preview-2026-10-10/hidden-why/<name>.json (UTF-8, pretty-printing is fine). To check the copy, hash sha256(JSON.stringify(JSON.parse(file))) in node; the first 16 hex characters should be: cobra-effect-hanoi-rats 55ff7a5f0ea81d1d, goodharts-law-report-cards 4fdb6e00726538ea, fine-is-a-price 394aec58d39080ca. If one differs, tell me which and I'll resend it. Then import them the way other preview packs are imported (import-pack.mjs) only if that writes to the local dev database, never production. Part 3b with the other three follows.
> 
> === cobra-effect-hanoi-rats
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs2","mains-gs4","mains-essay"],"formats":["interview-talk","mains-answer"]},"id":"cobra-effect-hanoi-rats","tone":"NEUTRAL","title":{"en":"The bounty that bred more rats","hi":"इनाम जिसने चूहे बढ़ा दिए"},"scene":"rats","frames":[{"en":"Pay people to kill rats, and you can end up with more rats.","hi":"चूहे मारने पर इनाम दो, और चूहे घटने के बजाय बढ़ सकते हैं।","focus":[180,320,1]},{"en":"Hanoi, 1902. Fearing plague, French rulers pay a bounty for every rat killed.","hi":"हनोई, 1902। प्लेग के डर से फ़्रांसीसी शासक हर मरे चूहे पर इनाम देने लगे।","focus":[180,130,1.7]},{"en":"The proof they ask for: just bring in the tail.","hi":"सबूत क्या चाहिए? बस चूहे की पूँछ ले आओ।","focus":[180,320,1.9]},{"en":"Soon, rats without tails are seen running through the city.","hi":"जल्द ही शहर में बिना पूँछ वाले चूहे घूमते दिखने लगे।","focus":[150,500,1.7]},{"en":"People cut off tails, let the rats go, and some even farmed them.","hi":"लोग पूँछ काटकर चूहे छोड़ देते थे, और कुछ ने तो चूहे पालने शुरू कर दिए।","focus":[270,560,2.1]},{"en":"Economists call this the Cobra Effect.","hi":"अर्थशास्त्री इसे 'कोबरा इफ़ेक्ट' कहते हैं।","focus":[180,320,1]}],"named":{"en":"Cobra Effect (a perverse incentive)","hi":"कोबरा इफ़ेक्ट (उल्टा असर करने वाला प्रोत्साहन)"},"sayItSmart":{"en":"A scheme gets what it pays for, not what it hopes for. In 1902 Hanoi paid for rat tails and ended up breeding rats. So before judging a scheme, I'd ask what exactly its money is tied to.","hi":"कोई भी योजना उसी चीज़ को बढ़ाती है जिसका वह भुगतान करती है, उसे नहीं जिसकी वह उम्मीद करती है। 1902 में हनोई ने चूहों की पूँछ का पैसा दिया और चूहे पलने लगे। इसलिए मैं पहले देखूँगा कि योजना का पैसा किस चीज़ से बँधा है।"},"careful":{"en":"The famous Delhi cobra version has no archive record that anyone has found; economist Horst Siebert popularised it in 2001. The Hanoi rat bounty is documented by historian Michael Vann, so quote Hanoi.","hi":"दिल्ली के कोबरा वाली मशहूर कहानी का कोई सरकारी रिकॉर्ड अब तक नहीं मिला; इसे 2001 में अर्थशास्त्री होर्स्ट ज़ीबर्ट ने लोकप्रिय बनाया। हनोई के चूहों वाला इनाम इतिहासकार माइकल वैन ने दस्तावेज़ों से साबित किया है, इसलिए उदाहरण हनोई का दें।"},"followUp":{"q":{"en":"Can you give an Indian example?","hi":"क्या आप कोई भारतीय उदाहरण दे सकते हैं?"},"hint":{"en":"Pick one you can back with a source, and frame it as a risk to design against, not as an accusation.","hi":"ऐसा उदाहरण चुनें जिसका स्रोत आप बता सकें, और उसे आरोप की तरह नहीं, बल्कि एक जोखिम की तरह रखें जिससे बचकर योजना बनानी है।"}},"useItIn":[{"paper":"mains-gs2","en":"Opening line for answers on scheme design, outcome-based funding or targets for officials.","hi":"योजना की बनावट, नतीजों पर आधारित फ़ंडिंग या अफ़सरों के लक्ष्यों वाले उत्तरों की पहली पंक्ति।"},{"paper":"mains-gs4","en":"Incentives versus intrinsic motivation in public service.","hi":"लोक सेवा में प्रोत्साहन बनाम भीतर की प्रेरणा।"},{"paper":"mains-essay","en":"Any essay on good intentions and unintended consequences.","hi":"अच्छी नीयत और अनचाहे नतीजों वाला कोई भी निबंध।"}],"linkedPacks":[],"sources":[{"label":"Michael G. Vann, 'Of Rats, Rice, and Race: The Great Hanoi Rat Massacre', French Colonial History, vol. 4 (2003); Vann and Clarke, The Great Hanoi Rat Hunt (2019)","verify":false},{"label":"Horst Siebert, Der Kobra-Effekt (2001)","verify":true}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}
> 
> === goodharts-law-report-cards
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs2","mains-essay"],"formats":["interview-talk","mains-answer"]},"id":"goodharts-law-report-cards","tone":"NEUTRAL","title":{"en":"When a number becomes a target","hi":"जब आँकड़ा ही लक्ष्य बन जाए"},"scene":"goodhart","frames":[{"en":"Rank hospitals on survival rates, and some very sick patients get turned away.","hi":"अस्पतालों को बचने की दर पर रैंक करो, तो कुछ गंभीर मरीज़ लौटा दिए जाते हैं।","focus":[180,220,1.2]},{"en":"Early 1990s: New York publishes each hospital's death rate for heart bypass surgery.","hi":"1990 के दशक की शुरुआत: न्यूयॉर्क हर अस्पताल में बाईपास सर्जरी की मृत्यु दर छापने लगा।","focus":[180,110,1.8]},{"en":"The easiest way to look good: operate on healthier patients.","hi":"अच्छा दिखने का सबसे आसान तरीका: कम बीमार मरीज़ों का ऑपरेशन करो।","focus":[190,250,1.9]},{"en":"A 2003 study found the sickest patients did worse after the report cards.","hi":"2003 के एक अध्ययन में पाया गया कि रिपोर्ट कार्ड के बाद सबसे बीमार मरीज़ों का हाल बिगड़ा।","focus":[180,220,1.2]},{"en":"India counted school enrolment for years, and it crossed 95 percent.","hi":"भारत बरसों तक स्कूल में दाख़िले गिनता रहा, और यह 95 प्रतिशत के पार पहुँचा।","focus":[180,440,1.5]},{"en":"Yet in rural government schools, only 45% of Class 5 can read Class 2 text.","hi":"फिर भी गाँव के सरकारी स्कूलों में कक्षा 5 के सिर्फ़ 45% बच्चे कक्षा 2 का पाठ पढ़ पाते हैं।","focus":[180,470,1.5]},{"en":"Economists call this Goodhart's Law.","hi":"अर्थशास्त्री इसे 'गुडहार्ट का नियम' कहते हैं।","focus":[180,320,1]}],"named":{"en":"Goodhart's Law: when a measure becomes a target, it stops being a good measure","hi":"गुडहार्ट का नियम: जब कोई पैमाना लक्ष्य बन जाता है, तो वह अच्छा पैमाना नहीं रहता"},"sayItSmart":{"en":"Measure, but audit and rotate what you measure. Report cards in New York pushed surgeons away from the sickest patients. NIPUN Bharat's move from enrolment to foundational reading is a good example of changing the target once the old one stopped telling us much.","hi":"मापिए ज़रूर, पर जो माप रहे हैं उसकी जाँच भी कीजिए और उसे बदलते रहिए। न्यूयॉर्क के रिपोर्ट कार्ड ने सर्जनों को सबसे बीमार मरीज़ों से दूर कर दिया। दाख़िले से हटकर बुनियादी पढ़ाई पर ध्यान देने वाला निपुण भारत इसका अच्छा उदाहरण है कि पुराना पैमाना बेकार हो जाए तो लक्ष्य बदलना चाहिए।"},"careful":{"en":"The neat one-line version is anthropologist Marilyn Strathern's 1997 paraphrase, not Goodhart's 1975 wording. Report cards also did some good, so the lesson is to watch for gaming, not to stop measuring.","hi":"एक पंक्ति वाला मशहूर रूप मानवविज्ञानी मैरिलिन स्ट्रैथर्न का 1997 का सार है, गुडहार्ट के 1975 के शब्द नहीं। रिपोर्ट कार्ड से कुछ फ़ायदे भी हुए, इसलिए सबक यह है कि आँकड़ों से खिलवाड़ पर नज़र रखें, मापना बंद न करें।"},"followUp":{"q":{"en":"So should we stop ranking colleges and states?","hi":"तो क्या कॉलेजों और राज्यों की रैंकिंग बंद कर दें?"},"hint":{"en":"No. Use several indicators, audit them, and check who gets left out of the count.","hi":"नहीं। कई पैमाने रखें, उनकी जाँच करें, और देखें कि गिनती में कौन छूट रहा है।"}},"useItIn":[{"paper":"mains-gs2","en":"Answers on health and education outcomes, state rankings and indices.","hi":"स्वास्थ्य और शिक्षा के नतीजों, राज्यों की रैंकिंग और सूचकांकों वाले उत्तर।"},{"paper":"mains-essay","en":"Essays on 'what gets measured gets managed' or on data in governance.","hi":"'जो मापा जाता है वही सँभाला जाता है' या शासन में आँकड़ों वाले निबंध।"}],"linkedPacks":[],"sources":[{"label":"Dranove, Kessler, McClellan and Satterthwaite, 'Is More Information Better? The Effects of Report Cards on Health Care Providers', Journal of Political Economy 111(3), 2003","verify":false},{"label":"ASER 2024 (Pratham), National findings: enrolment of 6 to 14 year olds above 95% for close to 20 years (98.1% in 2024); 44.8% of Std V children in government schools can read a Std II text","verify":false},{"label":"Marilyn Strathern, 'Improving ratings: audit in the British University system', European Review 5(3), 1997","verify":true},{"label":"Ministry of Education, NIPUN Bharat guidelines (2021)","verify":false}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}
> 
> === fine-is-a-price
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs4","mains-gs2","mains-essay"],"formats":["interview-talk","mains-answer"]},"id":"fine-is-a-price","tone":"LIGHT","title":{"en":"The fine that made parents later","hi":"जुर्माना जिससे माता-पिता और देर से आए"},"scene":"fine","frames":[{"en":"Fine parents for picking up their kids late, and more of them come late.","hi":"बच्चों को देर से लेने पर जुर्माना लगाओ, तो और ज़्यादा माता-पिता देर से आते हैं।","focus":[180,320,1]},{"en":"Haifa, Israel, 1998. Ten day-care centres, all closing at 4 pm.","hi":"हाइफ़ा, इज़राइल, 1998। दस डे-केयर सेंटर, सब शाम 4 बजे बंद होते थे।","focus":[180,140,1.7]},{"en":"Six of them start a small fine for picking up ten minutes late or more.","hi":"इनमें से छह ने दस मिनट या उससे ज़्यादा देर पर छोटा-सा जुर्माना शुरू किया।","focus":[250,330,2]},{"en":"Late pickups roughly double.","hi":"देर से आने वाले लगभग दोगुने हो गए।","focus":[180,520,1.6]},{"en":"The guilt was gone. Parents had simply bought extra time.","hi":"शर्मिंदगी ख़त्म हो गई। माता-पिता ने बस थोड़ा और समय ख़रीद लिया था।","focus":[110,330,2]},{"en":"When the fine was dropped, lateness stayed high.","hi":"जुर्माना हटाने के बाद भी देरी ऊँची ही बनी रही।","focus":[270,520,2]},{"en":"The researchers' verdict: a fine is a price.","hi":"शोधकर्ताओं का निष्कर्ष: जुर्माना भी एक क़ीमत है।","focus":[180,320,1]}],"named":{"en":"A fine is a price (crowding out)","hi":"जुर्माना एक क़ीमत है (क्राउडिंग आउट)"},"sayItSmart":{"en":"A small fine can turn a moral duty into a purchase. When day-care centres in Haifa fined late parents, lateness doubled and stayed high. So a penalty works best when it is big and sure enough to deter, or when it backs a strong social norm instead of replacing it.","hi":"छोटा जुर्माना नैतिक ज़िम्मेदारी को ख़रीद-फ़रोख़्त में बदल सकता है। हाइफ़ा के डे-केयर सेंटरों ने देर से आने वालों पर जुर्माना लगाया तो देरी दोगुनी हो गई और वैसी ही बनी रही। इसलिए सज़ा तब कारगर है जब वह इतनी बड़ी और पक्की हो कि डर पैदा करे, या जब वह सामाजिक मानदंड को सहारा दे, उसकी जगह न ले।"},"careful":{"en":"This is one small field experiment in one city. Other studies find that large, certain fines do deter. The lesson is about small fines replacing a social norm, not that penalties never work.","hi":"यह एक ही शहर का एक छोटा प्रयोग है। दूसरे अध्ययन बताते हैं कि बड़े और पक्के जुर्माने रोकते हैं। सबक यह है कि छोटा जुर्माना सामाजिक मानदंड की जगह ले सकता है, यह नहीं कि सज़ा कभी काम नहीं करती।"},"followUp":{"q":{"en":"So should India not raise traffic fines?","hi":"तो क्या भारत को ट्रैफ़िक जुर्माने नहीं बढ़ाने चाहिए?"},"hint":{"en":"Size and certainty of enforcement matter more than the rule on paper. Pair fines with campaigns that build the norm.","hi":"काग़ज़ पर नियम से ज़्यादा जुर्माने का आकार और उसकी वसूली का पक्कापन मायने रखता है। जुर्माने के साथ ऐसे अभियान चलाएँ जो मानदंड मज़बूत करें।"}},"useItIn":[{"paper":"mains-gs4","en":"Attitude, social influence and persuasion; intrinsic and extrinsic motivation.","hi":"अभिवृत्ति, सामाजिक प्रभाव और अनुनय; भीतरी और बाहरी प्रेरणा।"},{"paper":"mains-gs2","en":"Regulation and penalties, such as traffic fines or littering rules.","hi":"नियमन और दंड, जैसे ट्रैफ़िक जुर्माना या कूड़ा फैलाने के नियम।"},{"paper":"mains-essay","en":"Essays on law versus morality, or markets and values.","hi":"क़ानून बनाम नैतिकता, या बाज़ार और मूल्यों पर निबंध।"}],"linkedPacks":[],"sources":[{"label":"Uri Gneezy and Aldo Rustichini, 'A Fine Is a Price', Journal of Legal Studies 29(1), 2000","verify":false},{"label":"Steven Levitt and Stephen Dubner, Freakonomics (2005), chapter 1","verify":false}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}

---

_Wed 14 Oct 2026, 15:55 IST · Instructions Claude sent to the PC session:_

> Hidden Why, part 3b of 3: the last three packs. Save as before in server/content/preview-2026-10-10/hidden-why/. Hash prefixes: punjab-water-and-smoke 72edf03823688d8b, women-pradhans-natural-experiment 6df7bc37e69b6961, survivorship-bias-toppers 7761b34de59bf538. Then run checkPlay and the vendored validator over all six packs, `npm run check`, and the local tests that don't touch production. Send me a final report: files changed, test results, hash matches, and anything blocking. Still no deploy and no commits.
> 
> === punjab-water-and-smoke
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs3","mains-gs2","mains-essay"],"formats":["interview-talk","mains-answer"]},"id":"punjab-water-and-smoke","tone":"NEUTRAL","title":{"en":"How saving water moved Punjab's fires","hi":"पानी बचाने से पंजाब की आग कैसे खिसकी"},"scene":"punjab","frames":[{"en":"A law to save Punjab's water made its smoke season worse.","hi":"पंजाब का पानी बचाने वाले क़ानून ने धुएँ का मौसम और बिगाड़ दिया।","focus":[180,320,1]},{"en":"Free farm power since 1997. Pumps run, paddy spreads, groundwater falls.","hi":"1997 से खेती की बिजली मुफ़्त। पंप चलते रहे, धान फैला, भूजल गिरता गया।","focus":[110,270,1.8]},{"en":"2009: a law bars transplanting paddy before a set date in June.","hi":"2009: एक क़ानून ने जून की तय तारीख़ से पहले धान की रोपाई पर रोक लगा दी।","focus":[270,100,2]},{"en":"The aim: skip the hottest weeks, when water evaporates fastest.","hi":"मक़सद: सबसे गर्म हफ़्तों से बचना, जब पानी सबसे तेज़ी से भाप बनता है।","focus":[90,90,2]},{"en":"Later sowing means a later harvest, pushed into late October.","hi":"देर से रोपाई यानी देर से कटाई, जो अक्टूबर के आख़िर तक खिसक गई।","focus":[180,440,1.7]},{"en":"That leaves only a short gap before wheat must go in. A match is quickest.","hi":"गेहूँ बोने से पहले बहुत कम समय बचता है। माचिस सबसे तेज़ रास्ता है।","focus":[170,470,2]},{"en":"And late autumn's still, cold air traps the smoke over the plains.","hi":"और देर पतझड़ की ठहरी, ठंडी हवा धुएँ को मैदानों के ऊपर रोक लेती है।","focus":[250,565,1.7]},{"en":"Economists call this a second-order effect.","hi":"अर्थशास्त्री इसे 'दूसरे दर्जे का असर' कहते हैं।","focus":[180,320,1]}],"named":{"en":"Second-order effects (a policy trade-off)","hi":"दूसरे दर्जे का असर (नीति का ट्रेड-ऑफ़)"},"sayItSmart":{"en":"Punjab traded water for air. The 2009 law that delayed paddy saved groundwater but squeezed the gap before wheat, pushing stubble fires into the weeks when the air is stillest. So stubble burning has to be solved through power pricing, crop choice and the calendar together.","hi":"पंजाब ने पानी के बदले हवा का सौदा किया। धान की रोपाई टालने वाले 2009 के क़ानून ने भूजल तो बचाया, पर गेहूँ से पहले का समय घटा दिया, और पराली की आग उन हफ़्तों में चली गई जब हवा सबसे ठहरी होती है। इसलिए पराली का हल बिजली के दाम, फ़सल के चुनाव और कैलेंडर को साथ रखकर ही निकलेगा।"},"careful":{"en":"Stubble fires are one source of Delhi's winter smog, alongside vehicles, industry, dust and weather, and their share swings from day to day. The water law did save groundwater, which is why it stays.","hi":"पराली की आग दिल्ली की सर्दियों के स्मॉग का एक स्रोत है; गाड़ियाँ, उद्योग, धूल और मौसम भी ज़िम्मेदार हैं, और इसका हिस्सा रोज़ बदलता है। पानी वाले क़ानून ने भूजल बचाया भी है, इसीलिए वह बना हुआ है।"},"followUp":{"q":{"en":"What would you do about it?","hi":"आप इसके लिए क्या करेंगे?"},"hint":{"en":"Name two or three options, such as moving away from paddy, metering farm power, or machines that sow wheat through stubble, and the trade-off each one carries.","hi":"दो-तीन विकल्प बताइए, जैसे धान से हटना, खेती की बिजली की मीटरिंग, या पराली के बीच गेहूँ बोने वाली मशीनें, और हर एक का ट्रेड-ऑफ़ भी।"}},"useItIn":[{"paper":"mains-gs3","en":"Cropping patterns, irrigation, farm subsidies, air pollution.","hi":"फ़सल चक्र, सिंचाई, कृषि सब्सिडी, वायु प्रदूषण।"},{"paper":"mains-gs2","en":"Inter-state issues: one state's policy, another state's air.","hi":"अंतर-राज्यीय मुद्दे: एक राज्य की नीति, दूसरे राज्य की हवा।"},{"paper":"mains-essay","en":"Essays on trade-offs, or why every solution creates new problems.","hi":"ट्रेड-ऑफ़ पर, या हर समाधान नई समस्या क्यों पैदा करता है, इस पर निबंध।"}],"linkedPacks":["content/_generated/haiku-test/stubble-burning-chain.json"],"sources":[{"label":"Punjab Preservation of Subsoil Water Act, 2009","verify":false},{"label":"Balwinder-Singh, McDonald, Srivastava and Gerard, 'Tradeoffs between groundwater conservation and air pollution from agricultural fires in northwest India', Nature Sustainability 2, 580-583, 2019 (November PM2.5 about 29% higher after the 2009 Acts)","verify":false},{"label":"Disha Gupta, Centre for Development Economics, Delhi School of Economics, working paper 316: free farm electricity in Punjab from February 1997","verify":false}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}
> 
> === women-pradhans-natural-experiment
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["mains"],"papers":["interview","mains-gs2","mains-gs1","mains-essay"],"formats":["interview-talk","mains-answer"]},"id":"women-pradhans-natural-experiment","tone":"NEUTRAL","title":{"en":"India's accidental experiment on women leaders","hi":"महिला नेतृत्व पर भारत का अनजाना प्रयोग"},"scene":"pradhan","frames":[{"en":"India accidentally ran one of the world's best experiments on women leaders.","hi":"भारत ने अनजाने में महिला नेतृत्व पर दुनिया का एक बेहतरीन प्रयोग कर डाला।","focus":[180,320,1]},{"en":"1992: the 73rd Amendment reserves a third of panchayat chief posts for women.","hi":"1992: 73वें संशोधन ने पंचायत प्रमुख के एक-तिहाई पद महिलाओं के लिए आरक्षित किए।","focus":[180,330,1.7]},{"en":"Which villages get a reserved post rotates, almost like a lottery.","hi":"किन गाँवों में पद आरक्षित होगा, यह बारी से तय होता है, लगभग लॉटरी की तरह।","focus":[180,135,1.8]},{"en":"So researchers could compare reserved and unreserved villages fairly.","hi":"इसलिए शोधकर्ता आरक्षित और अनारक्षित गाँवों की निष्पक्ष तुलना कर सके।","focus":[180,320,1.1]},{"en":"Women pradhans invested more in drinking water, a top demand of women.","hi":"महिला प्रधानों ने पीने के पानी पर ज़्यादा ख़र्च किया, जो महिलाओं की सबसे बड़ी माँग थी।","focus":[180,525,1.8]},{"en":"Later, men in villages that had a woman pradhan stopped rating women leaders lower.","hi":"बाद में, जिन गाँवों में महिला प्रधान रहीं, वहाँ के पुरुषों ने महिला नेताओं को कमतर आँकना बंद कर दिया।","focus":[180,330,1.7]},{"en":"Economists call this a natural experiment.","hi":"अर्थशास्त्री इसे 'प्राकृतिक प्रयोग' कहते हैं।","focus":[180,320,1]}],"named":{"en":"Natural experiment","hi":"प्राकृतिक प्रयोग"},"sayItSmart":{"en":"Because reserved posts rotate almost at random, India gave researchers a clean test. Chattopadhyay and Duflo found women pradhans in West Bengal and Rajasthan put more into drinking water. Representation changed what got built, not just who sat in the chair.","hi":"आरक्षित पद लगभग लॉटरी की तरह बदलते हैं, इसलिए भारत ने शोधकर्ताओं को एक साफ़ परीक्षण दे दिया। चट्टोपाध्याय और डुफ़्लो ने पाया कि पश्चिम बंगाल और राजस्थान में महिला प्रधानों ने पीने के पानी पर ज़्यादा काम किया। प्रतिनिधित्व से सिर्फ़ कुर्सी पर बैठा व्यक्ति नहीं, बल्कि यह भी बदला कि क्या बना।"},"careful":{"en":"The study covered one district each in West Bengal and Rajasthan, so call it strong evidence, not a law. In Rajasthan, women pradhans also spent less on roads. 'Sarpanch pati' proxies are a real problem it does not settle.","hi":"अध्ययन पश्चिम बंगाल और राजस्थान के एक-एक ज़िले पर था, इसलिए इसे पक्का सबूत कहिए, अटल नियम नहीं। राजस्थान में महिला प्रधानों ने सड़कों पर कम ख़र्च भी किया। 'सरपंच पति' वाली समस्या असली है, जिसे यह अध्ययन हल नहीं करता।"},"followUp":{"q":{"en":"Then why do we keep hearing about 'sarpanch pati'?","hi":"तो फिर 'सरपंच पति' की बातें क्यों सुनाई देती हैं?"},"hint":{"en":"Both are true. Give the evidence, admit the proxy problem, and suggest a fix such as training and stronger gram sabha oversight.","hi":"दोनों बातें सच हैं। सबूत बताइए, प्रॉक्सी की समस्या मानिए, और प्रशिक्षण व ग्राम सभा की मज़बूत निगरानी जैसा उपाय सुझाइए।"}},"useItIn":[{"paper":"mains-gs2","en":"Panchayati Raj, the 73rd Amendment, devolution and reservation.","hi":"पंचायती राज, 73वाँ संशोधन, विकेंद्रीकरण और आरक्षण।"},{"paper":"mains-gs1","en":"Women's empowerment and changing social attitudes.","hi":"महिला सशक्तीकरण और बदलते सामाजिक नज़रिए।"},{"paper":"mains-essay","en":"Essays on representation, democracy or women in leadership.","hi":"प्रतिनिधित्व, लोकतंत्र या नेतृत्व में महिलाओं पर निबंध।"}],"linkedPacks":["content/jobs/sources/73rd-amendment.txt"],"sources":[{"label":"Raghabendra Chattopadhyay and Esther Duflo, 'Women as Policy Makers: Evidence from a Randomized Policy Experiment in India', Econometrica 72(5), 2004","verify":false},{"label":"Beaman, Chattopadhyay, Duflo, Pande and Topalova, 'Powerful Women: Does Exposure Reduce Bias?', Quarterly Journal of Economics 124(4), 2009","verify":false},{"label":"Constitution of India, Article 243D(4)","verify":false}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}
> 
> === survivorship-bias-toppers
> {"schema":"upsc-pods/hidden-why@1","mood":{"bed":null,"sfx":true,"motion":"gentle"},"sfx":{"next":"sfx/page","reveal":"sfx/chime"},"tags":{"stage":["prelims","mains"],"papers":["interview","prelims-csat","mains-gs4","mains-essay"],"formats":["interview-talk","csat-reasoning"]},"id":"survivorship-bias-toppers","tone":"LIGHT","title":{"en":"Why topper talks can mislead you","hi":"टॉपर की बातें आपको क्यों भटका सकती हैं"},"scene":"wald","frames":[{"en":"Want to know how to crack UPSC? Don't ask only the toppers.","hi":"UPSC कैसे निकालें, यह जानना है? सिर्फ़ टॉपर्स से मत पूछिए।","focus":[180,320,1]},{"en":"World War Two: bombers come back full of bullet holes.","hi":"दूसरा विश्व युद्ध: बमवर्षक विमान गोलियों के छेदों से भरे लौटते हैं।","focus":[180,160,1.5]},{"en":"The obvious idea: add armour where the holes are.","hi":"सीधा-सा विचार: जहाँ छेद हैं, वहाँ कवच लगाओ।","focus":[140,150,2]},{"en":"Statistician Abraham Wald's answer: armour where the holes aren't.","hi":"सांख्यिकीविद अब्राहम वाल्ड का जवाब: कवच वहाँ लगाओ जहाँ छेद नहीं हैं।","focus":[235,165,2]},{"en":"Planes hit there never came back to be counted.","hi":"जिन विमानों को वहाँ गोली लगी, वे गिनती के लिए लौटे ही नहीं।","focus":[180,160,1.5]},{"en":"Topper talks are the planes that came back.","hi":"टॉपर्स की बातें वही विमान हैं जो लौट आए।","focus":[180,450,1.9]},{"en":"Thousands who followed the same routine and didn't clear are never on stage.","hi":"वही दिनचर्या अपनाकर भी जो हज़ारों पास नहीं हुए, वे कभी मंच पर नहीं आते।","focus":[180,545,1.6]},{"en":"Statisticians call this survivorship bias.","hi":"सांख्यिकीविद इसे 'सर्वाइवरशिप बायस' कहते हैं।","focus":[180,320,1]}],"named":{"en":"Survivorship bias","hi":"सर्वाइवरशिप बायस (बचे हुओं से बना भ्रम)"},"sayItSmart":{"en":"Success stories are a filtered sample. Like Abraham Wald's returning bombers, they show what people survived, not what made them succeed. Before copying a routine, I'd want to hear from people who followed it and didn't make it.","hi":"सफलता की कहानियाँ छना हुआ नमूना होती हैं। अब्राहम वाल्ड के लौटे विमानों की तरह, वे बताती हैं कि लोग क्या झेलकर बचे, यह नहीं कि सफलता किससे मिली। किसी की दिनचर्या अपनाने से पहले मैं उन लोगों से भी सुनना चाहूँगा जिन्होंने उसे अपनाया और सफल नहीं हुए।"},"careful":{"en":"Wald's real work was a set of 1943 technical memos on estimating aircraft vulnerability. The red-dot plane drawing is modern, and how his advice was used is less documented. The logic is sound.","hi":"वाल्ड का असली काम 1943 के तकनीकी नोट्स थे, जिनमें विमानों की कमज़ोर जगहों का अनुमान था। लाल बिंदुओं वाला विमान का चित्र आज का है, और उनकी सलाह कैसे लागू हुई यह कम दर्ज है। पर तर्क सही है।"},"followUp":{"q":{"en":"Isn't your own preparation biased the same way?","hi":"क्या आपकी अपनी तैयारी भी इसी तरह पक्षपाती नहीं है?"},"hint":{"en":"Say yes, then say how you check it: what failed for others, and what you dropped when it didn't work for you.","hi":"हाँ कहिए, फिर बताइए कि आप इसे कैसे जाँचते हैं: दूसरों के लिए क्या नाकाम रहा, और जो आपके लिए काम नहीं आया उसे आपने कैसे छोड़ा।"}},"useItIn":[{"paper":"prelims-csat","en":"Spotting the flaw in an argument built on a biased sample.","hi":"पक्षपाती नमूने पर टिके तर्क की ख़ामी पकड़ना।"},{"paper":"mains-essay","en":"Essays on success, failure or learning from data.","hi":"सफलता, असफलता या आँकड़ों से सीखने पर निबंध।"},{"paper":"mains-gs4","en":"Evaluating evidence before decisions; humility in judgement.","hi":"फ़ैसलों से पहले सबूत परखना; आँकलन में विनम्रता।"}],"linkedPacks":["content/honest/coaching-guide.json"],"sources":[{"label":"Abraham Wald, 'A Method of Estimating Plane Vulnerability Based on Damage of Survivors', Statistical Research Group, Columbia University (1943; reprinted by the Center for Naval Analyses, 1980)","verify":false},{"label":"Marc Mangel and Francisco Samaniego, 'Abraham Wald's Work on Aircraft Survivability', Journal of the American Statistical Association 79(386), 1984","verify":false}],"review":{"status":"draft","checkedBy":null,"checkedOn":null,"note":"Facts checked by Claude against the named sources on 14 Oct 2026 (sources still marked verify could not be opened). A subject editor and a Hindi editor must approve before members see it."}}

---

_Wed 14 Oct 2026, 15:56 IST · Claude's checklist:_

> Hidden Why: build and ship
> 
> ✓ Fact-checked all six stories against sources
> ✓ Built template, validator rule and interview format
> ✓ Drew six illustrations
> ✓ Added picture engine to server and Android
> **✓ Copied stories and illustrations into the app**
> ✱ Running checks and a local import on your PC
> ○ Hand over to the next server deploy

---

_Wed 14 Oct 2026, 15:56 IST · Claude's checklist:_

> Hidden Why: build and ship
> 
> ✓ Fact-checked all six stories against sources
> ✓ Built template, validator rule and interview format
> ✓ Drew six illustrations
> ✓ Added picture engine to server and Android
> **✓ Copied stories and illustrations into the app**
> ✱ Running checks and a local import on your PC
> ○ Hand over to the next server deploy

---

_Wed 14 Oct 2026, 15:57 IST · Claude's checklist:_

> Hidden Why: build and ship
> 
> ✓ Fact-checked all six stories against sources
> ✓ Built template, validator rule and interview format
> ✓ Drew six illustrations
> ✓ Added picture engine to server and Android
> ✓ Copied stories and illustrations into the app
> **✓ Checks pass; server part handed to the next deploy**
> ○ Android build in Android Studio (needs you)

---

**Claude** · Wed 14 Oct 2026, 15:57 IST

**Needed from you:** one Android Studio build of the app. Gradle can't compile it from my session on your PC, so the new story screen has only been checked by reading the code.

- **Server:** ready. All six stories pass the checks and will go out with the Signup thread's next deploy. Members won't see them until an EN and a HI editor approve.
- **Facts:** two sources are still marked for an editor to check, one each on the cobra and Goodhart stories.
- **Older app versions:** they show "update the app" for these stories instead of crashing.

[Samples](https://claude.ai/artifact/RsVs1Xderu4TS7G3uj7ryZ) · [README.md](/mnt/project-files/content/hidden-why/README.md)

---

_Wed 14 Oct 2026, 15:57 IST · Note from the coordinator:_

> The user asked to pause everything again (attached). Stop where you are and don't start anything new or ship anything until they say to resume. Leave work in place. No reply needed beyond a status refresh.

---

_Wed 14 Oct 2026, 15:57 IST · Claude's checklist:_

> Hidden Why: paused at your request
> 
> ✓ Fact-checked all six stories against sources
> ✓ Built template, validator rule and interview format
> ✓ Drew six illustrations
> ✓ Added picture engine to server and Android
> ✓ Copied stories and illustrations into the app
> ✓ Checks pass; server part handed to the next deploy
> ○ Android build in Android Studio (paused)

---

_Wed 14 Oct 2026, 16:18 IST · Note from the coordinator:_

> The user says continue and deploy (attached). Resume where you paused. Your server work rides on the Signup thread's deploy; the Android Studio build you asked the user for is still outstanding, so keep that ask in your thread.

---

_Wed 14 Oct 2026, 16:18 IST · Claude's checklist:_

> Hidden Why: build and ship
> 
> ✓ Fact-checked all six stories against sources
> ✓ Built template, validator rule and interview format
> ✓ Drew six illustrations
> ✓ Added picture engine to server and Android
> ✓ Copied stories and illustrations into the app
> **✓ Server part handed to the Signup thread's deploy**
> ○ Android build in Android Studio (needs you)

---

**Claude** · Wed 14 Oct 2026, 16:18 IST

Picked back up. The server side of Hidden Why goes out with the Signup thread's deploy. The stories go out as drafts, so members won't see them until editors approve.

The one thing I still need from you is a build in Android Studio. Gradle can't compile the app from my session on your PC.

---

_Thu 15 Oct 2026, 05:57 IST · Note from the coordinator:_

> The user says continue (attached). Your server work ships with the Signup thread's deploy, and the Android Studio build is still the user's to do. If you need anything on the PC, its app folder isn't served by Remote Control right now, so request a fresh session from your thread.
