# Plan Rs 3000-month dev and run stack

Sat 24 Oct 2026, 19:55 IST to Sat 24 Oct 2026, 19:58 IST · 6 entries, 1 from you

---

**Edureka** · Sat 24 Oct 2026, 19:55 IST

You know the app completely. Help me come up with a stack of subscriptions to keep this going with appropriate quality without burning a lot of money - including bug fixes, new features etc. Say I have a budget of Rs 3000 per month. I am open to using OpenCode Go etc. but you tell me if it's right. Think and answer.

---

**Claude** · Sat 24 Oct 2026, 19:56 IST

First I'll check the app's current running costs, then compare today's coding-assistant plans against the budget.

---

_Sat 24 Oct 2026, 19:56 IST · Claude's checklist:_

> Subscription stack under ₹3,000/month
> 
> ✱ Read the app's stack, running costs and earlier AI-stack threads
> ○ Check current prices (OpenCode Go, Claude, Copilot, APIs)
> ○ Recommend a stack and reply

---

_Sat 24 Oct 2026, 19:57 IST · Claude's checklist:_

> Subscription stack under ₹3,000/month
> 
> ✓ Read the app's stack, running costs and earlier AI-stack threads
> ✱ Check current prices (OpenCode Go, Claude, Copilot, APIs)
> ○ Recommend a stack and reply

---

_Sat 24 Oct 2026, 19:58 IST · Claude's checklist:_

> Subscription stack under ₹3,000/month
> 
> ✓ Read the app's stack, running costs and earlier AI-stack threads
> ✓ Check current prices (OpenCode Go, Claude, Copilot, Codex, Gemini)
> ✓ Recommend a stack and reply

---

**Claude** · Sat 24 Oct 2026, 19:58 IST

**My pick: one Claude Pro plan plus the app's running costs, about ₹3,000 a month. I'd hold OpenCode Go back for now.** The budget has to cover keeping the app live, not just the coding tools, so here's how it splits:

| Item | ₹/month |
|---|---|
| Claude Pro, the plan this project already runs on (bug fixes, features, plans, runbooks) | ~2,000 (cheapest on annual billing) |
| Cloudflare Workers Paid, which hosts the server, database and pods | ~520 with GST |
| Domain | ~70 |
| Claude API for making content (Haiku batches), with a $4 spend cap | ~400 |
| Chotu's cloud models (NVIDIA, Gemini and Groq free tiers), Firebase emails, Cloudflare Access | 0 |

**Why not OpenCode Go:** it's good value at $10 (about ₹1,000 with GST). It gives you plenty of cheap models like DeepSeek V4.1 Flash, but the strong ones (GLM-5.3, Kimi K3) are capped at about $15 a month each. Those open models are a step below Claude on big changes that touch the Android app, server and database together, and a bad fix reaches students. It's also a terminal tool you'd drive yourself on your PC, which means giving up these threads, docs and runs on your PC. A few of its models keep or train on prompts, so keys and student data shouldn't go through them.

**Others:** Copilot Pro ($10) is built for people writing code in an editor. ChatGPT Plus with Codex costs the same as Claude Pro, so switching gains nothing. Google ended free Gemini CLI for individuals in June.

**When to change:**
- If you hit Pro's weekly limit often, move content-making to the free NVIDIA and Gemini models and spend that money on OpenCode Go for routine chores. That's still far cheaper than Max at ₹12,000.
- Buy ElevenLabs only in months you record audio.

Two caveats. I can't see your current Claude plan, so if it's an Edureka company seat, most of this budget is free for OpenCode Go and ElevenLabs. And these prices come from third-party trackers as of this month, so check the checkout page before you pay.

Sources: [OpenCode Go limits](https://www.creacosas.com/en/blogs/technology/opencode-go-precio-limites-opinion), [Claude India price](https://opentherank.com/ai-pricing/claude/india/), [Copilot](https://tech-insider.org/au/github-copilot-usage-based-billing-2026/), [Gemini CLI](https://www.tembo.io/blog/gemini-cli-pricing); running costs come from the [deployment plan](/mnt/project-files/deploy/deployment-plan.md) and the [AI cost sheet](/mnt/project-files/status/ai-economics.xlsx).
