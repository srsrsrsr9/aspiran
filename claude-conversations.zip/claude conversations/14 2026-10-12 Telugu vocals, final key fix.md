# Telugu vocals, final key fix

Mon 12 Oct 2026, 05:56 IST to Mon 12 Oct 2026, 10:50 IST · 25 entries, 2 from you

---

**Claude** · Mon 12 Oct 2026, 05:56 IST

Your ElevenLabs key is saved correctly now, so I'm making the Telugu vocals in a new thread that can use it.

_Attached: akela-nahi-telugu-elevenlabs.mp4, akela-nahi-hindi-elevenlabs.mp4, akela-nahi-hinglish-elevenlabs.mp4, akela-nahi-english-elevenlabs.mp4, akela-nahi-tamil-elevenlabs.mp4, akela-nahi-bengali-elevenlabs.mp4, akela-nahi-marathi-elevenlabs.mp4, akela-nahi-kannada-elevenlabs.mp4, akela-nahi-malayalam-elevenlabs.mp4, akela-nahi-gujarati-elevenlabs.mp4, akela-nahi-odia-elevenlabs.mp4_

---

**Claude** · Mon 12 Oct 2026, 05:56 IST

I'm checking that ElevenLabs accepts the key now, then making the Telugu vocals.

---

_Mon 12 Oct 2026, 05:56 IST · Connect your device to this thread? Open this project in an up-to-date app to allow or decline._

---

_Mon 12 Oct 2026, 05:56 IST · Claude's checklist:_

> Telugu vocals via ElevenLabs
> 
> ✱ Running the Telugu ElevenLabs script
> ○ Mix vocals into the video
> ○ Deliver the mp4

---

_Mon 12 Oct 2026, 05:57 IST · Allowed. Connecting your device._

---

_Mon 12 Oct 2026, 05:57 IST · Claude's checklist:_

> Telugu vocals via ElevenLabs
> 
> ✓ Ran the Telugu ElevenLabs script on Eleven v4
> ✓ Mixed the vocals into the video
> **✓ Attached the mp4**

---

**Claude** · Mon 12 Oct 2026, 05:57 IST

Your Telugu version with ElevenLabs vocals is attached. It's 45 seconds, using the same caption video with the new audio.

- **Model:** Eleven v4 (`eleven_v4`). I tested it directly and it accepts Telugu.
- **Voice:** "Rao garu", a Telugu voice already in your ElevenLabs library. It's designed, not cloned. I chose it over the stock American voices because it's native to the language.

Your key works for speech, but it doesn't have permission to list models, so the script was failing there. I changed it to test each model directly instead. A few lines had to be sped up by as much as 1.5x to fit their bar, so tell me if any sound rushed. I can also re-run it with a stock voice like Liam if you'd rather compare.

---

_Mon 12 Oct 2026, 05:57 IST · Your device was connected to this thread._

---

**Edureka** · Mon 12 Oct 2026, 10:12 IST

Awesome! So much better. Just the captions need correction. Also the tag line "Ontari Kadu" isn't catchy. Try something else.

---

**Claude** · Mon 12 Oct 2026, 10:12 IST

Glad it's better! I'll fix the captions to match the sung Telugu and try a catchier tagline.

---

_Mon 12 Oct 2026, 10:13 IST · Claude's checklist:_

> Telugu captions and new tagline
> 
> ✓ Swapped tagline to "నీతో మేమున్నాం" in the lyrics
> ✱ Re-rendering caption frames from the sung lyrics
> ○ Re-record the two hook lines on Eleven v4
> ○ Rebuild the video

---

**Edureka** · Mon 12 Oct 2026, 10:13 IST

Also redo the other languages - English, Hindi, Hinglish, Tamil and Bengali. Try adding a few more languages - based on aspirant count from that language.

---

**Claude** · Mon 12 Oct 2026, 10:13 IST

Got it. I'll finish Telugu first, then redo the other five and add Marathi, Kannada and Malayalam.

---

**Claude** · Mon 12 Oct 2026, 10:14 IST

Here's the Telugu version with corrected captions and a new tagline.

- **Captions:** the old video was showing an earlier draft of the lyrics. I re-rendered it so the words on screen match exactly what's sung, and the word highlight now follows the length of each word.
- **Tagline:** I changed it to **"నీతో మేమున్నాం"** (Neetho Memunnam, "We're with you"). It's in the hook line, the closing line and the title. Two other options if you prefer: "కలిసే గెలుద్దాం" (Kalise Geluddam, "We'll win together") or "ఒక్కడివి కాదు" (Okkadivi Kaadu).
- **Disclosure:** the footer now says the vocals are AI-generated, instead of "synthetic guide vocal".

I'm now working on the other languages.

---

_Mon 12 Oct 2026, 10:16 IST · Claude's checklist:_

> All language versions with ElevenLabs vocals
> 
> ✓ Fixed Telugu captions and tagline
> ✱ Writing Hindi, Marathi, Kannada and Malayalam lyrics
> ○ Generalise the script for every language
> ○ Voice and render English, Hindi, Hinglish, Tamil, Bengali
> ○ Voice and render Marathi, Kannada, Malayalam

---

_Mon 12 Oct 2026, 10:17 IST · Claude's checklist:_

> All language versions with ElevenLabs vocals
> 
> ✓ Fixed Telugu captions and tagline
> ✓ Wrote Hindi, Marathi, Kannada and Malayalam lyrics
> ✓ Generalised the script for every language
> ✱ Voicing and rendering 8 languages on Eleven v4
> ○ Check captions in each video

---

_Mon 12 Oct 2026, 10:29 IST · Claude's checklist:_

> All language versions with ElevenLabs vocals
> 
> ✓ Fixed Telugu captions and tagline
> ✓ Wrote Hindi, Marathi, Kannada and Malayalam lyrics
> ✓ Generalised the script for every language
> ✓ Rendered Hindi, Hinglish, English, Tamil, Bengali, Marathi
> ✱ Rendering Kannada and Malayalam
> ✓ Checked captions match the sung lines

---

_Mon 12 Oct 2026, 10:32 IST · Claude's checklist:_

> All language versions with ElevenLabs vocals
> 
> ✓ Fixed Telugu captions and tagline
> ✓ Wrote Hindi, Marathi, Kannada and Malayalam lyrics
> ✓ Generalised the script for every language
> ✓ Rendered Hindi, Hinglish, English, Tamil, Bengali, Marathi
> ✓ Rendered Kannada and Malayalam
> **✓ Checked captions match the sung lines**

---

**Claude** · Mon 12 Oct 2026, 10:32 IST

All eight new versions are ready: English, Hindi, Hinglish, Tamil and Bengali redone, plus Marathi, Kannada and Malayalam added. Six are attached here and the last two follow in the next message. They use the same setup as the Telugu one: Eleven v4, the "Rao garu" voice, and captions rendered from the sung lines.

- **Hindi** is a new version in Devanagari script, separate from the Hinglish one.
- **Why these three new languages:** after Hindi and English, Maharashtra, Karnataka and Kerala have some of the largest groups of UPSC aspirants. UPSC doesn't publish counts by language, so I judged this from state-wise aspirant numbers. Gujarati and Odia would be next.
- **Taglines:** the new languages get warmer lines instead of a literal "not alone":
  - Marathi: "आम्ही आहोत ना!" ("We're right here!")
  - Kannada: "ನಾವ್ ಜೊತೆಗಿದ್ದೀವಿ" ("We're with you")
  - Malayalam: "ഞങ്ങളുണ്ട് കൂടെ" ("We're with you")
  
  Hindi and Hinglish keep "Akela Nahi". Tamil and Bengali keep their earlier taglines; I didn't change those.
- **Lines that may sound rushed:** a few had to be sped up to fit their bar, the most being one Kannada line at 1.75x. The others are English bars 8 and 11 and Marathi bar 8, at about 1.5x.

Every non-English lyric still needs a native speaker to check it before anything goes public.

---

**Claude** · Mon 12 Oct 2026, 10:32 IST

Here are the Kannada and Malayalam versions.

---

_Mon 12 Oct 2026, 10:45 IST · Note from the coordinator:_

> The user loved the language versions and wants Gujarati and Odia added too (attached). The home page and splash work is going to the Community-first repositioning thread; it doesn't depend on these videos, so go ahead with Gujarati and Odia now.

---

**Claude** · Mon 12 Oct 2026, 10:46 IST

Glad they landed! I'm adding Gujarati and Odia now, using the same voice and setup.

---

_Mon 12 Oct 2026, 10:46 IST · Claude's checklist:_

> Gujarati and Odia versions
> 
> ✓ Wrote Gujarati and Odia lyrics
> ✱ Voicing and rendering both on Eleven v4
> ○ Check the captions

---

_Mon 12 Oct 2026, 10:50 IST · Claude's checklist:_

> Gujarati and Odia versions
> 
> ✓ Wrote Gujarati and Odia lyrics
> ✓ Voiced and rendered both on Eleven v4
> **✓ Checked the captions**

---

**Claude** · Mon 12 Oct 2026, 10:50 IST

The Gujarati and Odia versions are attached. They use the same voice and setup as the others, and their captions match the sung lines.

- **Taglines:** both use a warm "we're right here" line, like the Marathi one. Gujarati is "અમે છીએ ને!" and Odia is "ଆମେ ଅଛୁ ନା!".
- **One line may sound rushed:** Gujarati bar 8 had to be sped up 1.5x to fit its bar.

Both lyrics still need a native speaker's check.
