# Project summary and launch checklist

Sun 11 Oct 2026, 09:02 IST to Sun 11 Oct 2026, 17:25 IST · 36 entries, 7 from you

---

**Edureka** · Sun 11 Oct 2026, 09:02 IST

In a new session keep maintaining the work done so far and keep it up to date. Summarize it once now - dsicussions, choices, decisions, work done, features, content, etc. Also add a checklist of all items open and closed to turn this into a real thriving business. The idea is to launch this as a community that gives a lot for free and allows you to buy some things as you get serious.

_Attached: project-status.md, ai-economics.xlsx, todos.txt, todoist-import.csv, todoist-update.csv, next-steps.md_

---

**Claude** · Sun 11 Oct 2026, 09:02 IST

I'm reading every thread and the shared files first, so the summary reflects what was actually decided and built.

---

_Sun 11 Oct 2026, 09:02 IST · Claude's checklist:_

> Project summary and business checklist
> 
> ✱ Reading project chat, threads and shared files
> ○ Write the summary and checklist
> ○ Set up a routine to keep it current

---

_Sun 11 Oct 2026, 09:04 IST · Claude's checklist:_

> Project summary and business checklist
> 
> ✓ Read the project chat, all 7 threads and the shared files
> ✱ Writing the summary and checklist
> ○ Set up a routine to keep it current

---

_Sun 11 Oct 2026, 09:05 IST · Claude's checklist:_

> Project summary and business checklist
> 
> ✓ Read the project chat, all 7 threads and the shared files
> ✓ Wrote the summary and checklist
> **✓ Set up a daily refresh at 20:55 IST**

---

**Claude** · Sun 11 Oct 2026, 09:05 IST

The summary and the business checklist are ready in one living document: [project-status.md](/mnt/project-files/status/project-status.md). A daily routine refreshes it at 20:55 IST by rereading every thread. It messages you here only when something needs you.

**Where things stand:** the free core is mostly built and runs locally on your PC. That covers the Android app, the web and desktop app, focus blocking, on-device Chotu, the editor desk, and 70 content templates on 9 engines. Nothing is deployed, and the admin console is being built now. The paid side doesn't exist yet: there are no payments or answer feedback, and no sprints or mentor tier. The cheap test from your brief, a pod test with a founding-member pre-sale, hasn't started either.

**What needs you now** (section 7 of the doc):
- Rotate the Cloudflare keys. They're still visible in your 10 Oct message in the project chat.
- Say yes or no to read-aloud in the phone's built-in voice.
- Confirm the marketing defaults: 1M installs by Dec 2027, UPSC plus state PSC, about ₹1.45 crore, public launch in early Dec 2026.

The checklist in section 8 is grouped from validation and the free core through payments, content operations, safety, legal, infrastructure, launch and team, with each item marked done or open. I took the app details from the build thread's reports and didn't open the code itself.

---

**Edureka** · Sun 11 Oct 2026, 10:43 IST

Comment on `project-status.md` (line 41):

```
The web app comes first and installs as a desktop app (a PWA), so there's no second codebase. Regain-style blocking comes from a browser extension on desktop and the Accessibility service on Android
```

what about the mobile app install? Shall we avoid Google play store completely and allow people to download the apk and install? Or is that unnecessary exposure? What about app permissions on android and windows? Lastly what about iOS and Macs and Linux?

---

**Edureka** · Sun 11 Oct 2026, 10:44 IST

Comment on `project-status.md` (line 43):

```
Models: use existing quantized models (Gemma 4 E2B/E4B, EmbeddingGemma 2, Llama Guard 3 1B), pinned and self-hosted. Train only small classifiers for now. No distilling and no training from scratch. No generative video or image models
```

makes sense - need an understanding of the economics here at different levels - # of users, assumed level of activity etc.

---

**Claude** · Sun 11 Oct 2026, 10:44 IST

On platforms: keep Google Play as the main channel. Offer a direct APK only to pilot testers, not as the public route.

**Why not APK-only:**
- **Focus breaks.** For apps installed outside Play, Android 13 and later blocks turning on Accessibility until the user digs into settings and allows "restricted settings". Most people will stop there.
- **Trust.** Play Protect warns on unknown APKs, and an aspirant who already distrusts coaching hype won't push past "this app may be harmful".
- **No auto-updates.** Every fix, model pin or safety change depends on people downloading again.
- **Developer verification is coming anyway.** Google said in 2025 that apps installed outside Play would also need a verified developer, starting in a few countries in Sept 2026 and going global in 2027. Going off-Play doesn't avoid Google; this is from memory, so it's worth checking.
- **What an APK is good for:** the pilot, and members who can't use Play. Sign it with the same key and publish its checksum.

**Permissions:**
- **Android:** internet, notifications (asked after the first Close the Day), and a foreground service for the model download. For Focus, I'd swap Accessibility for **Usage Access**. It only sees which app is in front, Play reviews it more lightly, and it avoids the restricted-settings wall. Nothing else: no contacts, location, SMS or storage.
- **Windows (and every desktop):** the installed web app asks for no OS permissions. The browser extension needs tab and site-blocking permissions and has to pass Chrome Web Store or Edge Add-ons review. A web app can't block other desktop programs; that would need a native helper later.

**iOS, Mac, Linux:**
- **Mac and Linux:** the web app already installs from Chrome or Edge, and the extension works there. Safari would need its own extension build on a Mac.
- **iPhone:** the web app works now through "Add to Home Screen", with push on iOS 16.4 and later. A native iOS app means porting the Kotlin code (Compose Multiplatform can share most of it), a Mac to build on, $99 a year for an Apple developer account, and Apple's Screen Time entitlement for blocking. I'd do this after the pod test shows traction.

I've added this to the doc as an open decision waiting on your yes. Next I'm building the model and AI economics at different user counts and activity levels.

---

_Sun 11 Oct 2026, 10:44 IST · Claude's checklist:_

> Economics of the AI and infra stack
> 
> ✓ Answered platforms and distribution
> ✱ Gathering current model and hosting prices
> ○ Build the cost model at 1k to 1M users
> ○ Add it to the status doc

---

_Sun 11 Oct 2026, 10:46 IST · Claude's checklist:_

> Economics of the AI and infra stack
> 
> ✓ Answered platforms and distribution
> ✓ Gathered current model and hosting prices
> ✓ Built the cost model at 1k to 1M users
> **✓ Added it to the status doc (§10)**

---

**Claude** · Sun 11 Oct 2026, 10:46 IST

The economics are in a spreadsheet you can edit, [ai-economics.xlsx](/mnt/project-files/status/ai-economics.xlsx), with a summary in section 10 of the doc. These are planning estimates from list prices, not measurements, and they leave out people costs.

| Monthly users | 1k | 10k | 100k | 1M |
|---|---|---|---|---|
| Tech cost per month | ₹4.7k | ₹31k | ₹2.9L | ₹29L |
| Net paid revenue per month | ₹6.5k | ₹65k | ₹6.5L | ₹65L |

The assumptions: 30% of users active each day, 3% paying ₹299 a month, and a fifth of members using the free 3 feedbacks a week.

- **On-device Chotu costs nothing to run at any size.** Model downloads from Cloudflare R2 have no egress fee, and the server stays under about ₹18k a month even at 1M users.
- **Content generation is flat at about ₹1.3k a month.** Your editors cost far more.
- **Cloud answer feedback is the one cost that grows with users.** If the free tier ran on Sonnet, it would cost about ₹57 lakh a month at 1M users, almost all of the paid revenue. On Haiku it's about ₹2.7 lakh. So my recommendation is Haiku for free feedback and Sonnet only for paid members.
- **Paid feedback on Sonnet still takes about 40% of each member's net revenue** at 40 feedbacks a month. Running Haiku first and sending only hard answers to Sonnet would cut that a lot.

The yellow cells on the Assumptions sheet are inputs, so you can try your own prices, conversion or activity levels and every scenario recalculates.

---

**Edureka** · Sun 11 Oct 2026, 10:47 IST

Comment on `project-status.md` (line 45):

```
15 thinkers adopted (Kahneman, Oakley, Sierra, Sugarman, Fogg, Gollwitzer, Neff, Story Wars, Sun Tzu, Kautilya and others). Pressure tactics are left out, and so is Khera's winners-and-losers framing
```

suggest adding great Indian thinkers too, afterall the exam is Indian.

---

_Sun 11 Oct 2026, 10:47 IST · Note from the coordinator:_

> I've routed the Indian thinkers request to the Ideas from great minds thread, which owns the thinkers list. Tell the user that in a line, and update the summary when its result comes back rather than doing the research here.

---

**Claude** · Sun 11 Oct 2026, 10:47 IST (edited)

The Indian thinkers are now section F of the [great-minds playbook](/mnt/project-files/research/great-minds-playbook.md#f-indian-thinkers). It covers Thiruvalluvar, the Gita, Patanjali, the Buddha, Kabir, Basavanna, Guru Nanak, Vivekananda, Tagore, Gandhi's talisman, Ambedkar, Savitribai Phule, Azad, Ramanujan, Kalam and Amartya Sen. It's also syllabus, since GS4 asks about Indian moral thinkers. It comes with three rules:
- Balance across regions and faiths.
- A checked source for every quote. The viral fake Kalam and Gandhi lines become myth packs instead.
- No party or faith mascots.

It also adds a "thinker lens" template for GS4 and Essay, and 8 starter quotes. None of the quotes have been checked yet.

---

_Sun 11 Oct 2026, 10:47 IST · Note from the coordinator:_

> Ignore my earlier routing note. Since you've already told the user you're drafting the Indian thinkers addendum, go ahead and do it here; I've told the great-minds thread to stand down.

---

_Sun 11 Oct 2026, 10:47 IST · Claude's checklist:_

> Indian thinkers addendum
> 
> ✱ Reading the playbook's format and filters
> ○ Write the addendum
> ○ Link it from the playbook and the status doc

---

**Edureka** · Sun 11 Oct 2026, 10:47 IST

Comment on `project-status.md` (line 46):

```
Content runs on templates so a small model (Haiku 5.5) can produce volume. The validator rejects any number that isn't in the source, and an editor must approve English and Hindi separately
```

two parts: how do I continue authoring? Better to make that super simple. Second - need to support more languages.

---

_Sun 11 Oct 2026, 10:49 IST · Claude's checklist:_

> Indian thinkers, authoring and languages
> 
> ✓ Added Indian thinkers to the playbook (§F)
> ✓ Sent simpler authoring and more languages to the build and content threads
> **✓ Logged both in the status doc**

---

**Claude** · Sun 11 Oct 2026, 10:49 IST

**How to author today:** start the server on your PC (`npm run dev` in `app\server`) and open `localhost:8787/desk`.
- Use "Write a card" in the Queue or "Start a draft" in the Library, then approve English, then Hindi, then publish.
- For bulk work, a content pack goes in with `npm run import`.

It works, but it means filling in fields by hand.

**Making it simple:** I've asked [App brainstorm and build](#cmsg_0146jwtuzxK2eLF4t48LSTjpFFQM1RaBmW2uMfoRk2eyH6) for a one-screen "Paste and pick" flow on the desk.
- You paste text, a link or a PDF, pick one to three content types (or let it suggest), and press Generate.
- Drafts come back with English and Hindi side by side and any problems highlighted. You edit inline and approve with one tap per language. It will work on your phone too.
- Once the daily news lane is running, most days you'd only be approving. Generating needs an Anthropic API key, which goes in a file on your PC, never in chat.

**More languages:** I've asked both the build and content threads to make the system support any number of languages: the app, the desk, the templates and the Hindi-matching check. My defaults:
- Launch stays English and Hindi.
- Telugu comes next, for the Hyderabad cohort, then Marathi, Tamil, Bengali and Kannada.
- A new language goes live only when it has a human editor to approve it and a distress-phrase list. Without that list, the safety check can't catch a crisis written in that language.

Tell me if you'd order the languages differently. Both items are in section 7 of the doc.

---

**Edureka** · Sun 11 Oct 2026, 10:49 IST

Comment on `project-status.md` (line 49):

```
Content defaults: an optional 60-second wind-down sound, test the name Chotu with about 10 users, Lottie for animation. **Applied as defaults
```

let's add some binaural beats or similar to calm the aspirant when they feel stressed. Also useful to create a routine (like a custom exercise routine) - bring the experts here - • Atomic Habits by James Clear – A modern classic on how tiny, incremental changes compound into massive, life-changing transformations.
• Rich Routines: Simple Habits That Enrich Every Area of Your Life by Steve Houghton – Focuses on a holistic "both-and" approach to balancing financial wealth with health, family, and personal well-being.
• The Joy of Routines: Simple Daily Habits to Reduce Stress, Boost Energy, and Create Balance in Your Life – A practical handbook with customizable tools for designing stress-free daily structures.
• Daily Routines: The habits and rituals of 50 successful people by Hao Nguyen – Explores the morning habits, time management, and schedules of global leaders, athletes, and tech founders.
• The Power of Habit by Charles Duhigg – Explores the science behind why habits exist and how they can be changed.
• Daily Rituals by Mason Currey – Looks into the working habits and daily routines of famous writers, artists, and thinkers.

---

**Claude** · Sun 11 Oct 2026, 10:49 IST (edited)

Both are now in section G of the [playbook](/mnt/project-files/research/great-minds-playbook.md#g-routines-and-calming-sound), and I've sent the app, content and marketing parts to their threads.

**Calm now, 2 taps from anywhere:**
- Guided slow breathing for 1, 3 or 5 minutes is the main tool, because it has the strongest evidence.
- Binaural "calm tones" are offered on top, for headphones. The research on them is mixed, so the app describes them as something some people find relaxing and makes no health claims.
- After a Heavy mood, Calm now sits next to "Need to talk?" and never replaces it.

**My Routine** works like building a custom workout:
- You drag in blocks (study, revision, mock, walk, family time, sleep) and anchor each one to an existing habit.
- There are starter templates for full-time, working, repeater and caregiver aspirants.
- Today's 3 slot into the study blocks, and a gentle Sunday review suggests one change at a time. No streaks.

**The books:**
- I adapted Clear (habit stacking, environment design), Duhigg (keystone habits), and Currey and Nguyen (there's no single right routine). "Never miss twice" is kept as a gentle suggestion, not a rule.
- I couldn't confirm *Rich Routines* or *The Joy of Routines* from memory, so an editor should check those before they go on the shelf.

---

**Claude** · Sun 11 Oct 2026, 10:50 IST

The calm sound and routine builder are written up. The details are in my message above and in section G of the [playbook](/mnt/project-files/research/great-minds-playbook.md#g-routines-and-calming-sound). The build, content and marketing threads each have their part.

---

_Sun 11 Oct 2026, 12:05 IST · Note from the coordinator:_

> The user wants all the open todos in a paste-friendly format for a free to-do app that works in a browser and on Android (message attached). Pull every open item from your launch checklist and the latest thread work. Default: recommend Todoist or TickTick (both free on web and Android, and both turn multi-line paste into one task per line), and give plain text with one task per line, grouped by section, with no checkboxes or markdown symbols that would clutter the tasks. Deliver it as a .txt file in project files plus the text inline if it fits.

---

**Claude** · Sun 11 Oct 2026, 12:07 IST (edited)

Your to-do list is ready to paste: [todos.txt](/mnt/project-files/status/todos.txt). It has 85 tasks, one per line, grouped into 11 sections.

**Which app:** I'd use **Todoist** (free on the web and Android). TickTick works the same way.

**How to import:** make a project called "UPSC Pods", then paste one section at a time into the quick-add box. Todoist offers to turn each line into its own task, so say yes. You can make each section a Todoist section, or use labels if you'd rather keep one list.

**Start with "Do now".** Rotating the Cloudflare keys is the most urgent item. The last section, "Being built by Claude", needs no action from you; it's there so you can track it.

I also marked the admin console as done in the status doc. The daily refresh now keeps this list in step too, removing finished items and adding new ones.

---

**Edureka** · Sun 11 Oct 2026, 12:09 IST

help me import them with the appropriate tags. ToDoist is open in the browser; help me to get it done with a local session

---

**Claude** · Sun 11 Oct 2026, 12:09 IST

On it. I'll make a Todoist import file with labels, put it on your PC, then import it in your open browser.

---

**Claude** · Sun 11 Oct 2026, 12:10 IST

The import file is on your PC: `Documents\Personal\app\status\todoist-import.csv`. I can't click inside your browser from here, so the import itself takes four clicks from you:

1. In Todoist, create a project called **UPSC Pods** and open it.
2. Click the **⋯** menu at the top right of the project.
3. Choose **Import from CSV**.
4. Pick `todoist-import.csv`.

**What you'll get:** 85 tasks in 11 sections (Do now, Validate, Free core, Paid side and so on).
- **Labels:** every task has `@upsc-pods` plus its area, such as `@legal`, `@content` or `@safety`. Decisions also get `@decision`, hiring tasks get `@people`, and the work I'm doing is tagged `@waiting`.
- **Priority:** the "Do now" tasks are set to priority 1. If they come in at the lowest priority instead, tell me and I'll flip the file.

Once it's in, tell me if anything looks off, like missing labels or wrong sections, and I'll fix the file.

---

_Sun 11 Oct 2026, 13:09 IST · Note from the coordinator:_

> The user asked you to update the checklist (attached). Fold in what has landed since your last update. App brainstorm and build has finished the Author tab on the desk, Telugu as a pilot, Calm now and My Routine. Content building plan made the content language-generic, finished seven Telugu packs, built the Indian thinkers, calm and routine content, and is now replacing Gandhi, Ambedkar and Sen with older thinkers like Kautilya. The colloquial-tone rule for UI text is applied. The user's new decision: authoring happens on the web desk, and phone support for authoring is nice to have but low priority, so downgrade or remove that item. Update project-status.md, todos.txt and the Todoist CSV.

---

**Claude** · Sun 11 Oct 2026, 13:13 IST

I've updated the checklist. If you've already imported into Todoist, import [todoist-update.csv](/mnt/project-files/status/todoist-update.csv) into UPSC Pods. It holds only the 6 new tasks, which arrive without a section, so drag them where you want. Then tick off the five old "Being built by Claude" tasks and the old anniversary-posts task. If you haven't imported yet, use the full [todoist-import.csv](/mnt/project-files/status/todoist-import.csv) instead. Both files are also in `Documents\Personal\app\status` on your PC.

What changed in [project-status.md](/mnt/project-files/status/project-status.md):
- **Done:** the Author tab on the web desk, Telugu as a pilot, Calm now and My Routine. App text in Telugu and Hindi now uses an everyday spoken tone, while study content stays standard.
- **Low priority:** authoring on the phone is now marked as a nice-to-have.
- **Thinkers:** Gandhi, Ambedkar and Sen are out of the [playbook](/mnt/project-files/research/great-minds-playbook.md#f-indian-thinkers) in favour of Kautilya, Thiruvalluvar, the Gita, Patanjali and the Bhakti saints. Ambedkar stays only in plain polity facts, like chairing the Drafting Committee. The content thread is still swapping out the cards themselves.
- **New tasks for you:** try the Author tab, find native speakers to check the Hindi and Telugu app text, and get a Telugu editor to review the 7 Telugu packs.

---

_Sun 11 Oct 2026, 16:47 IST · Note from the coordinator:_

> The user asked (attached) what else on the to-do list can be completed, what they can do themselves, and where content stands. Go through the open items and split them into three groups: what Claude threads can finish now, what needs only the user (short, highest leverage first), and a content status with the next batch worth building. For anything Claude can do, send me the list with the owning thread for each (App brainstorm and build, Content building plan or Marketing plan for 1M downloads) and I'll kick them off. Answer the user in your thread.

---

_Sun 11 Oct 2026, 16:49 IST · I was waiting here on the usage limit of this account's Claude plan; that wait has ended._

---

**Claude** · Sun 11 Oct 2026, 17:03 IST

Yes. About 20 items can be finished by Claude now, and I've sent them to the build, content and marketing threads. The full split is in [next-steps.md](/mnt/project-files/status/next-steps.md).

**What only you can do, most useful first:**
1. Rotate the Cloudflare keys. This takes about 5 minutes and is the only security risk still open.
2. Answer five one-word decisions: read aloud, the marketing defaults, the platforms plan, the language order, and the first paid product. The paid side can't be built until you pick the product.
3. Put your Anthropic API key in `server/.dev.vars` on your PC. That turns on the Generate button and makes the daily news lane possible.
4. Install the APK on your phone, try the Author tab, and approve a few drafts.
5. Start the 10 aspirant interviews and look for editors (English, Hindi, Telugu).

**Content:** there are 70 templates and 102 sample files, including 7 Telugu packs, the older thinkers, and the calm and routine content. None of it is editor-approved yet. The thinker swap is finished. The next batch I'd build is the GS2 Polity subject lane and the first real mock paper with five long reads. Those are the deep syllabus material the app still lacks, and the content thread is getting them.

I'll build the monthly cost model including people here and add it to the economics sheet.

---

**Claude** · Sun 11 Oct 2026, 17:04 IST

The cost model with people is done. You don't need to do anything, but the result matters for pricing. At 3% paying and ₹299 a month, the business only breaks even near 1M monthly users. At 100k users it loses about ₹6.6 lakh a month, because the team costs about ₹10 lakh. Breaking even there would take about 6% paying, a higher average price from sprints and mentors, or a smaller team. That makes the founding-member pre-sale and the pricing test the numbers to watch.

The salaries are rough planning figures, and the cells you can change are highlighted yellow. It's on the new "People and total" sheet in [ai-economics.xlsx](/mnt/project-files/status/ai-economics.xlsx), with a summary in [project-status.md §10](/mnt/project-files/status/project-status.md#10-ai-and-infrastructure-economics-added-11-oct). In Todoist, tick off "Build a monthly cost model".

---

_Sun 11 Oct 2026, 17:25 IST · Note from the coordinator:_

> The user asked to pause all activity (attached). Stop any work in progress, including the daily refresh if one is scheduled (disable it rather than delete it), and don't start anything new until the user says to resume.

---

**Claude** · Sun 11 Oct 2026, 17:25 IST

Paused. I've turned off the daily status refresh, but kept it so it can be switched back on. Nothing else is running in this thread, and I won't touch the status files until you say resume.
