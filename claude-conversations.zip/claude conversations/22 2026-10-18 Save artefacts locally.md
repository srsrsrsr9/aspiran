# Save artefacts locally

Sun 18 Oct 2026, 14:47 IST to Sun 18 Oct 2026, 14:54 IST · 4 entries, 1 from you

---

**Edureka** · Sun 18 Oct 2026, 14:47 IST

keep all artefacts locally - here - C:\Users\Srinivas Vedantham\Documents\Personal\app\artefacts

_Attached: README.md_

---

_Sun 18 Oct 2026, 14:48 IST · Claude's checklist:_

> Saving artefacts locally
> 
> ✱ Finding each published artefact
> ○ Fetching their source files
> ○ Saving them to the artefacts folder

---

_Sun 18 Oct 2026, 14:53 IST · Claude's checklist:_

> Saving artefacts locally
> 
> ✓ Found all 12 published artefacts
> ✓ Fetched each one's source
> **✓ Saved 19 files to the artefacts folder**

---

**Claude** · Sun 18 Oct 2026, 14:54 IST

I've saved all 12 artefacts to `C:\Users\Srinivas Vedantham\Documents\Personal\app\artefacts`, and none failed. There was nothing in the folder before, so nothing got overwritten.

- **The 7 pages** are saved as their own HTML files. That covers The Hidden Why, both Pods Template Studio versions (labelled v1 10 Oct and v2 12 Oct), Launch Kit, Routine Builder and Chai Content Preview. UPSC Pods Website is in its own folder with its video and poster image.
- **The 5 docs** are saved as PDFs. Chotu AI Platform Design, the Content Building Plan and the Marketing Plan also have a Word copy, and the Gemma 3 1B note has a Markdown copy.
- **`README.md`** lists each file next to its live link.

These are copies from today, so later edits only show up at the live links. One thing to know: a diagram embedded in Chotu AI Platform Design may show up in the exported copies as a placeholder instead of the drawing.

There's also a copy in the project files at [artefacts/README.md](/mnt/project-files/artefacts/README.md).
