# Deployment plan

Mon 12 Oct 2026, 06:00 IST to Mon 12 Oct 2026, 08:26 IST · 15 entries, 2 from you

---

**Edureka** · Mon 12 Oct 2026, 06:00 IST

plan for deployment as well. I will do it, just need the direction.

_Attached: deployment-plan.md, chotu-model-options.md_

---

_Mon 12 Oct 2026, 06:00 IST · Claude's checklist:_

> Deployment plan
> 
> ✱ Reading the app's code to see what needs deploying
> ○ Write the step-by-step plan
> ○ Share the first steps

---

_Mon 12 Oct 2026, 06:01 IST · Claude's checklist:_

> Deployment plan
> 
> ✓ Read the server, web app, Android and extension setup
> ✱ Writing the step-by-step plan
> ○ Share the first steps

---

_Mon 12 Oct 2026, 06:02 IST · Claude's checklist:_

> Deployment plan
> 
> ✓ Read the server, web app, Android and extension setup
> **✓ Wrote the step-by-step plan**

---

**Claude** · Mon 12 Oct 2026, 06:02 IST

I've written the deployment plan: [deployment-plan.md](/mnt/project-files/deploy/deployment-plan.md). It's simpler than it might look. The server, web app, admin console, /status page and desktop app all ship as one Cloudflare Worker with one `npm run deploy`. The desktop app is just the web app installed from Chrome or Edge. Only the Android app goes out separately.

**First steps:**
1. **Today:** rotate the Cloudflare token and R2 keys from the 10 Oct chat. Then open your Play developer account now, because ID checks and the 14-day closed test take the longest of anything here. Also make a Groq key with a spend limit, and book the lawyer call before buying a domain, since "UPSC" in the name is still an open question.
2. **Once the community-first build is finished:** run the tests locally, then on Cloudflare create the database (D1) and the two storage buckets (R2), add the secrets with `wrangler secret put`, and deploy to the free workers.dev address. The plan lists the exact commands and checks.
3. **After that:** set up the domain with Cloudflare Access in front of /admin and /desk, upload Chotu's models to R2 (with rclone, since they're too big for wrangler), add uptime alerts, do one restore drill, and then the Play tracks.

Expect about ₹500 to ₹1,000 a month plus Groq usage. That includes the $5 Workers Paid plan, which I recommend so the daily backup doesn't hit the free plan's CPU limit.

ElevenLabs doesn't need a server secret. Nothing in the server code uses that key, so it stays on your PC.

A few small code changes belong to the build thread: a default https server address in the Android release build, your new domain in the Focus extension, and release signing.

---

_Mon 12 Oct 2026, 08:05 IST · Note from the coordinator:_

> The user asks (attached) whether Chotu's on-device model sizes can be reduced, or whether there are smaller models that are just as good. Look into it: stronger quantization of Gemma 4 E2B, the 0.5 GB Lite option, and other small models that do well in Hindi, Telugu and Hinglish and run on 4 GB phones. Weigh quality, safety behaviour and licence, and recommend one. Update the deployment plan if it changes anything. Leave app code changes to the Community-first repositioning thread.

---

_Mon 12 Oct 2026, 08:05 IST · Claude's checklist:_

> Smaller models for Chotu
> 
> ✱ Checking smaller and stronger-quantized model options
> ○ Compare quality, Indian languages, safety and licence
> ○ Update the deployment plan if needed

---

_Mon 12 Oct 2026, 08:07 IST · Claude's checklist:_

> Smaller models for Chotu
> 
> ✓ Checked smaller and stronger-quantized model options
> ✓ Compared quality, Indian languages, safety and licence
> **✓ Updated the deployment plan's model step**

---

**Claude** · Mon 12 Oct 2026, 08:07 IST

Yes, it can get smaller. My recommendation is to keep one on-phone model, Gemma 4 E2B, and drop E4B. People then download at most 2.6 GB instead of 3.7 GB, and the server holds 2.6 GB of model files instead of 6.7 GB.

The models that are actually smaller (Qwen3 0.6B, Gemma 3 1B) are weak in Hindi and Telugu, so they aren't "as good". Qwen3 1.7B is about the same size as E2B and worse at Indian languages. Avoid the "uncensored" E2B builds on Hugging Face, because their safety training has been removed.

Two quick tests could shrink it further:
1. **Try E2B on a 4 GB phone.** Google's numbers show it using only 0.7 to 1.7 GB of memory, so it may run there. If it does, you can drop the 0.5 GB Qwen file too and ship a single model.
2. **Try the 2.01 GB variant** of E2B from the same official repo. That would save another 0.6 GB, but the repo doesn't document it, so check it works on your phones first.

Also, Google released smaller "QAT" versions of Gemma 4 in June, but not yet in the file format the phone needs. That's worth checking again before launch.

The comparison table and a 10-question test to run are in [chotu-model-options.md](/mnt/project-files/deploy/chotu-model-options.md). I've also updated step 8 of the deployment plan. Changing the model list in the app goes to the build thread once you've picked.

---

**Edureka** · Mon 12 Oct 2026, 08:25 IST

check unsloth's (https://unsloth.ai/) work on these and confirm. Also look at similar players like Unsloth who are reducing the size of good open models.

---

**Claude** · Mon 12 Oct 2026, 08:25 IST

I'll check Unsloth's Gemma 4 work first, then other teams that make shrunken models, and see what the app can actually use.

---

_Mon 12 Oct 2026, 08:25 IST · Claude's checklist:_

> Unsloth and similar model shrinkers
> 
> ✱ Checking Unsloth's Gemma 4 quantized models
> ○ Look at similar players
> ○ Check what Chotu's phone runtime can load
> ○ Update the model options note

---

_Mon 12 Oct 2026, 08:26 IST · Claude's checklist:_

> Unsloth and similar model shrinkers
> 
> ✓ Checked Unsloth's Gemma 4 quantized models
> ✱ Looking at similar players
> ○ Check what Chotu's phone runtime can load
> ○ Update the model options note

---

_Mon 12 Oct 2026, 08:26 IST · Claude's checklist:_

> Unsloth and similar model shrinkers
> 
> ✓ Checked Unsloth's Gemma 4 quantized models
> ✓ Looked at similar players
> ✓ Checked what Chotu's phone runtime can load
> **✓ Updated the model options note**

---

**Claude** · Mon 12 Oct 2026, 08:26 IST

I checked Unsloth's work, and the recommendation stands: use Google's own E2B file, with no gain from Unsloth's.

- **Unsloth's E2B files aren't smaller at the same quality.** Their 4-bit version is 2.62 GB, against 2.59 GB for Google's file. Their smallest "mobile" version is 2.19 GB, and Google's 2.01 GB variant is smaller still. Every quantizer stops at about 2 GB because half of E2B is a large word-embedding table that compresses poorly.
- **Chotu can't load Unsloth's files anyway.** They're in GGUF format, for llama.cpp. The phone app runs on Google's LiteRT-LM engine, which only loads `.litertlm` files. Switching engines would be a real code change, and it wouldn't save any space.
- **Where Unsloth helps:** fine-tuning Chotu later on your own tone or on Hindi and Telugu examples. Their numbers also show 4-bit keeps about 98% agreement with the full model.

**Similar players:**
- Google's own litert-community builds are the source to use.
- bartowski and the LM Studio community make GGUF files only, so they have the same engine problem.
- Multiverse Computing claims up to 95% compression, but those are vendor claims with no Hindi or Telugu evidence.
- Liquid AI's small models don't list Hindi or Telugu.
- Sarvam has no phone-sized text model. Its on-device speech model, Sarvam Edge, could matter later for voice.

The full table with sources is in [chotu-model-options.md](/mnt/project-files/deploy/chotu-model-options.md#unsloth-and-other-teams-that-shrink-models-checked-12-oct). The next step is still yours: try E2B, including the 2.01 GB variant, on a 4 GB phone and a 6 GB phone.
