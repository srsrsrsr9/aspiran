# Motion video content templates

Fri 23 Oct 2026, 19:09 IST to Fri 23 Oct 2026, 21:48 IST · 16 entries, 2 from you

---

**Edureka** · Fri 23 Oct 2026, 19:09 IST

I like to create content that feels like these samples - do we create some templates or how do we go about this?

Ideally the Deepstash type content should have been like this - animations, motion effects, pan, zoom, camera angles, bg music, with voice over.

 https://youtu.be/AcLJaV4Lkvk?si=NL5YGdwrkAZ6NILM&t=410
https://www.youtube.com/watch?v=jY0-gsNImlk
https://www.youtube.com/shorts/UPIhEjRAyVk
https://www.youtube.com/shorts/Sfv5y_0UBpo
https://www.youtube.com/shorts/KtEgj5hMEUk
https://www.youtube.com/watch?v=qK4Re_ArS3Q
https://www.youtube.com/watch?v=YJAJppVaOXc

_Attached: Motion Stories_

---

**Claude** · Fri 23 Oct 2026, 19:09 IST

First I'll study the samples and break down what makes them work, then propose templates and a production approach.

---

_Fri 23 Oct 2026, 19:09 IST · Claude's checklist:_

> Motion video templates
> 
> ✱ Study the seven samples and the existing Deepstash-style content
> ○ Recommend an approach (templates vs pipeline)
> ○ Build a sample motion template with voice-over and music
> ○ Save source to your artefacts folder

---

_Fri 23 Oct 2026, 19:12 IST · Claude's checklist:_

> Motion video templates
> 
> ✓ Studied the seven samples (thumbnails and frames; YouTube blocks full playback here)
> ✱ Building a sample motion template on the Cobra Effect story
> ○ Voice-over and music via ElevenLabs
> ○ Render to vertical MP4 and publish a preview
> ○ Write up the recommended approach
> ○ Save source to your artefacts folder

---

_Fri 23 Oct 2026, 19:17 IST · Claude's checklist:_

> Motion video templates
> 
> ✓ Studied the seven samples (thumbnails and frames; YouTube blocks full playback here)
> ✓ Voice-over generated with ElevenLabs, with word timings
> ✱ Building the motion engine and seven shot templates (Cobra Effect story)
> ○ Render to vertical MP4 with music, sound effects and captions
> ○ Publish a preview and write up the approach
> ○ Save source to your artefacts folder

---

**Edureka** · Fri 23 Oct 2026, 19:19 IST

why 11labs? Why not https://huggingface.co/maya-research/maya1 or Sarvam Bulbul latest

---

**Claude** · Fri 23 Oct 2026, 19:21 IST

No strong reason. ElevenLabs is just the one already connected here, so I could get real voice-over today (on the free plan, so only stock voices and no music API). The template doesn't depend on it. It only needs an audio file per line plus the time each word is spoken, which drives the captions and the motion cues.

How I'd weigh the two you named:
- **Sarvam Bulbul** fits better for us: natural Indian English, plus Hindi, Telugu and the other Indian languages we need for HI versions, through a cheap API. I'd make it the default.
- **Maya1** is open-source with expressive emotion tags, but it's English-focused and needs a GPU to self-host. It's worth it later if we're producing at volume and want zero per-minute cost.

Neither gives word timings the way ElevenLabs does, so I'll add a word-alignment step (Whisper) that works with any voice. Then switching voices is one line in the story file.

To use Bulbul, I need a Sarvam API key added to this environment's secrets. The sample video is rendered; I'll post it shortly.

---

_Fri 23 Oct 2026, 19:23 IST · Claude's checklist:_

> Motion video templates
> 
> ✓ Studied the seven samples (thumbnails and frames; YouTube blocks full playback here)
> ✓ Voice-over generated with ElevenLabs, with word timings
> ✓ Built the motion engine and seven reusable shots
> ✓ Rendered the Cobra Effect story to a 42 s vertical MP4 with music, effects and captions
> ✓ Published the preview with the recommended approach
> ✓ Saved page, video and source to your artefacts folder
> ○ Switch voice to Sarvam Bulbul (needs an API key)

---

**Claude** · Fri 23 Oct 2026, 19:23 IST

Here's a first motion video: the Cobra Effect story as a 42-second vertical clip with camera zooms and pans, match cuts, a voice-over, a music bed that drops under the voice, sound effects and word-by-word captions. [Motion Stories](https://claude.ai/artifact/SQHoUP63zxhCw1QBNNWdqR) has the video and the reasoning.

To your question, I'd build a pipeline rather than hand-made templates. A writer fills a short story file (one line of voice-over per beat, plus which shot to use). Code then voices it, animates it from a growing library of reusable shots, and renders the MP4 in about 90 seconds with no paid tools. Better shots improve every story at once, and the same file can produce the Hindi version.

Two limits:
- YouTube blocked full playback from here, so I worked from frames of each sample. I couldn't watch the NDTV moment at 6:50.
- The drawings and music are stand-ins.

Next: add a Sarvam API key to this environment's secrets and I'll re-voice the sample in Indian English and Hindi.

Local copies are in `artefacts\Motion Stories` on your PC. The engine is in [content/motion](/mnt/project-files/content/motion/).

---

_Fri 23 Oct 2026, 21:26 IST · Note from the coordinator:_

> The user wants you and the Buyer's-eye app review thread (cmsg_0146jwtuzxK2eLF4t48LSTjpSUBLr2dziykXvGzY4GYCsT) to work out cinematic current affairs together. That thread builds the app on the user's local branch and is about to tackle this feature; your motion/voice-over pipeline is likely the content engine. Please coordinate with it directly and agree on the best way forward.

---

_Fri 23 Oct 2026, 21:27 IST · Claude's checklist:_

> Cinematic current affairs, with the app thread
> 
> ✓ Agreed split and file contract with the app review thread
> ✱ Story shape for a CA scene, written from the Chai cards
> ○ New shots: map zoom, stat reveal, timeline, quote card
> ○ Render 3 sample scenes (app and social cuts, captions, posters)
> ○ Write the week manifest and hand over to the app thread
> ○ Save copies to your artefacts folder

---

**Claude** · Fri 23 Oct 2026, 21:27 IST

I've agreed a split with the [app review thread](#cmsg_0146jwtuzxK2eLF4t48LSTjpSUBLr2dziykXvGzY4GYCsT). I make the weekly current-affairs scenes as videos with captions and a quiz. It builds the player, the free/Plus gating, offline caching and the Sunday reminder. I'm rendering a 3-scene sample week now so it can wire the player against real files.

---

_Fri 23 Oct 2026, 21:32 IST · Claude's checklist:_

> Cinematic current affairs, with the app thread
> 
> ✓ Agreed split and file contract with the app review thread
> ✓ Wrote 3 sample scenes from the Chai cards (GI tag, El Niño, Sendai) and voiced them
> ✱ New shots: map zoom (land only, no borders), stat reveal, timeline, quote, exam links, quiz hand-off
> ○ Render app and social cuts, captions file and poster per scene
> ○ Write the week manifest and hand over to the app thread
> ○ Save copies to your artefacts folder

---

_Fri 23 Oct 2026, 21:36 IST · Claude's checklist:_

> Cinematic current affairs, with the app thread
> 
> ✓ Agreed split and file contract with the app review thread
> ✓ Wrote 3 sample scenes from the Chai cards (GI tag, El Niño, Sendai) and voiced them
> ✓ New shots: map zoom (land only, no borders), stat reveal, timeline, quote, exam links, quiz hand-off
> ✱ Rendering app and social cuts, captions file and poster per scene (about 10 min)
> ○ Write the week manifest and hand over to the app thread
> ○ Save copies to your artefacts folder

---

_Fri 23 Oct 2026, 21:48 IST · Claude's checklist:_

> Cinematic current affairs, with the app thread
> 
> ✓ Agreed split and file contract with the app review thread
> ✓ Wrote 3 sample scenes from the Chai cards (GI tag, El Niño, Sendai) and voiced them
> ✓ New shots: map zoom (land only, no borders), stat reveal, timeline, quote, exam links, quiz hand-off
> ✓ Rendered app and social cuts, captions and posters (3 scenes, 2 min 13 s week)
> ✓ Week manifest handed over; the app thread is wiring the player to it
> ✓ Copies saved to your artefacts folder
> ○ Sarvam voice in English and Hindi (needs an API key)

---

**Claude** · Fri 23 Oct 2026, 21:48 IST

The first sample current-affairs week is ready, and the [app review thread](#cmsg_0146jwtuzxK2eLF4t48LSTjpSUBLr2dziykXvGzY4GYCsT) is now wiring its player to it. You can watch the El Niño scene on [Motion Stories](https://claude.ai/artifact/SQHoUP63zxhCw1QBNNWdqR).

It has 3 scenes made from the 10 Oct Chai cards (GI tag, El Niño, Sendai), about 45 seconds each. Each one runs: hook, a map or timeline, the key number, the exam link, then "Your turn", after which the app shows the quiz. Maps show land only, with no country borders, so we never show an India boundary that differs from the official map. Serious topics play without music.

All scenes are still drafts, as their Chai cards are. Copies are in `artefacts\Motion Stories\ca-2026-41` on your PC. The voice stays ElevenLabs until a Sarvam key is added.
