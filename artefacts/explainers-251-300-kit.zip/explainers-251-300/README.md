# Explainers 251–300: files for the other Claude

Start with `artefacts/content-assignment-2026-11-25-explainers.md`: it is the prompt (paste everything below its line).

Folders mirror the app repo, so each file sits at the path the prompt mentions:
- `artefacts/`: the prompt and the list of 100 (your 50 are 251–300).
- `content/tools/story/explainer.py`: builds each video; `commons.py` finds safely licensed pictures; `endcard.py` the closing card.
- `content/tools/cartesia/`: voice and speech-check helpers the builder uses.
- `content/motion/explainers/201–203/`: three finished examples (calm, fast, photo) with a contact sheet each.
- `content/motion/shorts/2001-09/manifest.json`: a finished pack, for quiz and review-note style.
- `server/public/app/syllabus-lines.js`: the syllabus node ids (gs1-7 and so on).

The builder runs only on the owner's Mac: it reads the voice keys from the Mac's Keychain (no keys are in these
files) and uses the Mac's Avenir Next font. In a chat without that Mac, use these files to write the scripts
(explainer.json), quizzes and ledgers; the main Claude then builds and publishes them.
