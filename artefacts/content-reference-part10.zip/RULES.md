## Part C. Rules for every batch

### C1. Facts
- If a source is pasted in the chat, use only facts from it. Copy numbers exactly. Keep its hedges.
- Otherwise use only **well-established, textbook-level** facts (NCERT, the Constitution and Bare Acts, standard
  reference texts). Leave out anything recent, disputed or uncertain.
- Every number, date, article, case, committee, report, scheme and named study goes in that item's `factsToCheck`
  list. When in doubt, list it.
- **Never invent**:
  - a previous-year question (PYQ);
  - a quotation;
  - a statistic;
  - a survey;
  - a court case;
  - a story about a real aspirant.
- You may only call a question a **PYQ** if it's in Appendix 1 or the owner pastes it. Otherwise call it "practice
  question" and set `"isPYQ": false`.
- **Quotes from real people:** use only ones you're confident are real and correctly attributed, and put each in
  `factsToCheck` with its source. If unsure, paraphrase the idea and don't put it in quotation marks.
- Political topics: present both sides fairly. Never tell the reader what to think about a party, government or person.
- Maps and borders: describe places in words only. Don't describe or draw national borders.

### C2. Voice
- Warm, plain and exact, like a sharp senior explaining over chai. Short sentences. Explain any jargon the first time.
- Teach the concept underneath, and say why it matters for the exam.
- **Word limits are hard limits**, counted in words. Count them with code before you finish.
- Never write: "hurry", "last chance", countdowns, "guaranteed", "100% selection", "topper's secret", "you should have
  …", or anything that scolds. A wrong answer gets an explanation, never a put-down.

### C3. Tone labels (set `tone` on every item)
- `LIGHT`: everyday topics. The only tone where a joke or one emoji is allowed.
- `NEUTRAL`: most policy, polity, economy and geography.
- `SERIOUS`: security, disasters, health crises.
- `TRAGIC`: loss of life. **No jokes, no emoji, no playful lines; not shareable** (set `"shareable": false`). Don't
  make walk-mode audio for TRAGIC topics.

### C4. Hindi (every piece is made in both languages, side by side)
- Every `en` field has a matching `hi` field. Write the Hindi **together with** the English, not as a later
  word-for-word translation.
- Use natural Hindi in Devanagari, as aspirants read it. Use the standard terms: अनुच्छेद, संशोधन, धन विधेयक,
  मौलिक अधिकार, लोकसभा, राज्यसभा, नीति निदेशक तत्व, संघवाद. Keep acronyms as they are (GDP, IMD, UNESCO).
- Keep the same meaning, order, list lengths and answer positions as the English. Numbers stay as digits. Up to a
  third longer than the English is fine.
- **Facts, statements and options** use standard Hindi. **Anything that talks to the reader** (tips, hints,
  explanations, Chotu's lines) uses friendly spoken Hindi with the everyday English words aspirants use (exam, mock,
  revision). Always use आप, and keep it free of gender.
- Where two Hindi terms are common, use the one in NCERT and UPSC's Hindi papers. Note the other in `hiAlt`.

### C5. Files
- Use UTF-8 JSON, 2-space indented, one item per file unless the batch says otherwise.
- **Every item has:**
  - an `id`: lowercase, hyphens, unique, starting with the batch's prefix;
  - `version: 1`;
  - `tone`;
  - `factsToCheck`: a list of strings, which may be empty;
  - `review: {"status": "draft"}`.
- Use only the field names shown in Part D. Don't add fields. If something doesn't fit, put it in `notes`.

### C6. Before you zip: check your own work (use code)
1. Every file parses as JSON and has every required field.
2. Every `en` field has a `hi` partner, and every `hi` field contains Devanagari.
3. Word limits are met: count with code, and fix anything over.
4. List lengths and answer positions match between `en` and `hi`.
5. No banned words (C2), and nothing playful on TRAGIC items.
6. PYQ IDs match Appendix 1 exactly.
7. Then re-read 5 items at random **as a strict checker who didn't write them**. Look for:
   - wrong facts;
   - one-sided politics;
   - Hindi that doesn't match the English;
   - items that only inform and ask nothing of the reader.

   Write what you found and what you fixed into `checks/self-check.json`.

---

