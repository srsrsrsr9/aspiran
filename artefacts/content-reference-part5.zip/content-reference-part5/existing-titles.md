# What the app already has (do not repeat these topics)

Made 4 Nov 2026 from the live library plus part 4. One line per item: id, then title. Pick new topics; no two files on the same topic within a format.

## acronym-unpack (2)
- `eco-sebi`: SEBI unpacked
- `env-iucn`: IUCN, letter by letter

## assertion-reason (24)
- `anc-gupta-age-ar`: The Gupta age: assertion and reason
- `anc-vedic-period-ar`: The Vedic period: assertion and reason
- `art-temple-architecture-styles-ar`: Temple architecture styles: assertion and reason
- `eco-green-revolution-and-farming-ar`: The Green Revolution and Indian farming: assertion and reason
- `eco-interest-rates-and-inflation-ar`: Interest rates, money and inflation: assertion and reason
- `eco-money-fiscal-and-prices-ar`: Money, deficits and prices: assertion and reason
- `eco-trade-and-exchange-rate-ar`: Trade and the exchange rate: assertion and reason
- `env-air-pollution-ar`: Air pollution: assertion and reason
- `env-forests-and-mangroves-ar`: Forests and mangroves: assertion and reason
- `geo-himalayas-and-plate-tectonics-ar`: The Himalayas and plate tectonics: assertion and reason
- `geo-monsoon-mechanism-ar`: How the Indian monsoon works: assertion and reason
- `geo-physical-geography-of-india`: Physical geography of India: assertion and reason
- `his-freedom-struggle-ar`: Freedom struggle: assertion and reason
- `ir-imf-world-bank-and-wto-ar`: IMF, World Bank and WTO: assertion and reason
- `med-delhi-sultanate-administration-ar`: Delhi Sultanate administration: assertion and reason
- `mod-colonial-land-revenue-ar`: Colonial land revenue systems: assertion and reason
- `mod-constitutional-reforms-1909-1935-ar`: Constitutional reforms, 1909 to 1935: assertion and reason
- `pol-centre-state-relations-ar`: Centre-state relations: assertion and reason
- `pol-elections-and-anti-defection-ar`: Elections and anti-defection: assertion and reason
- `pol-fundamental-rights-ar`: Fundamental Rights: assertion and reason
- `pol-parliament-and-amendments-ar`: Parliament and amendments: assertion and reason
- `sci-immunity-and-infections-ar`: Immunity and infections: assertion and reason
- `sci-physics-in-daily-life-ar`: Physics in daily life: assertion and reason
- `soc-urbanisation-and-migration-ar`: Urbanisation and migration: assertion and reason

## before-after (3)
- `env-forests-to-concurrent-list`: How forests and wildlife became a shared subject
- `soc-daughters-coparcenary-rights`: Daughters and the Hindu joint family property
- `soc-education-as-fundamental-right`: When schooling became a Fundamental Right

## better-answer (23)
- `anc-better-intros-ancient-culture`: Spot the better introduction: ancient Indian culture
- `art-better-conclusions-heritage`: Spot the better conclusion: art and heritage
- `eco-better-body-agriculture`: Spot the better body: agriculture
- `eco-better-conclusions-infrastructure`: Spot the better conclusion: infrastructure
- `eco-better-intros-economy`: Spot the better introduction: the economy
- `env-better-body-environment`: Spot the better body: environment
- `env-better-conclusions-climate`: Spot the better conclusion: climate change
- `eth-better-body-case-studies`: Spot the better body: ethics case studies
- `eth-better-conclusions-ethics`: Spot the better conclusion: ethics and integrity
- `eth-better-intros-ethics-concepts`: Spot the better introduction: ethics concepts
- `geo-better-body-geography`: Spot the better body: geography
- `ir-better-conclusions-neighbourhood`: Spot the better conclusion: India and its neighbours
- `ir-better-intros-foreign-policy`: Spot the better introduction: foreign policy
- `mains-better-body-points`: Spot the stronger body point
- `mains-better-conclusions`: Spot the better conclusion
- `mains-better-introductions`: Spot the better introduction
- `mod-better-conclusions-freedom-struggle`: Spot the better conclusion: the freedom struggle
- `pol-better-body-governance`: Spot the better body: governance
- `pol-better-conclusions-federalism`: Spot the better conclusion: federalism
- `pol-better-intros-polity`: Spot the better introduction: polity
- `sci-better-intros-science-tech`: Spot the better introduction: science and technology
- `soc-better-body-welfare`: Spot the better body: health, education and welfare
- `soc-better-intros-indian-society`: Spot the better introduction: Indian society

## bucket-sort (4)
- `eco-direct-vs-indirect-taxes`: Direct tax or indirect tax?
- `env-in-situ-vs-ex-situ`: In situ or ex situ conservation?
- `geo-rabi-kharif-zaid`: Sort the crops by season
- `sci-diseases-by-pathogen`: Sort the disease by what causes it

## committee-match (3)
- `eco-economic-reform-committees`: Economy committees and what they examined
- `his-education-commissions`: Education commissions, 1882 to 1952
- `pol-committees-and-commissions`: Committees and what they examined

## directive-word (1)
- `mains-directive-words-core-six`: Six directive words, decoded

## ethics-dilemma (5)
- `eth-flood-relief-paperwork`: Relief kits and the missing list
- `eth-illegal-factory-jobs`: An unlicensed factory that employs a town
- `eth-inflated-coverage-data`: The figures your predecessor left behind
- `eth-senior-tender-favour`: A senior's request on a tender
- `eth-viral-video-constable`: A viral video and a constable

## fact-or-opinion (2)
- `ir-un-security-council-fact-or-opinion`: UN Security Council: fact or opinion?
- `soc-census-2011-fact-or-opinion`: Census 2011: fact or opinion?

## fill-the-gap (23)
- `anc-ashokan-inscriptions-gap`: Ashoka's inscriptions
- `anc-jainism-basics-gap`: Basics of Jainism
- `art-hindustani-and-carnatic-gap`: Hindustani and Carnatic music
- `art-parts-of-a-stupa-gap`: The parts of a stupa
- `eco-gst-council-gap`: The GST Council
- `eco-monetary-policy-committee-gap`: The Monetary Policy Committee
- `env-biosphere-reserves-gap`: Biosphere reserves
- `env-ozone-layer-gap`: The ozone layer and its protection
- `geo-course-of-the-monsoon-gap`: The course of the monsoon
- `geo-interior-of-the-earth-gap`: The interior of the Earth
- `his-morley-minto-reforms`: The Morley-Minto Reforms
- `his-partition-of-bengal`: The partition of Bengal
- `ir-un-security-council-gap`: The UN Security Council
- `med-mughal-revenue-and-mansabs-gap`: Mughal revenue and the mansab system
- `med-vijayanagara-empire-gap`: The Vijayanagara empire
- `mod-gandhis-early-campaigns-gap`: Gandhi's early campaigns in India
- `mod-road-to-independence-gap`: The road to independence, 1946-48
- `pol-emergency-provisions`: The three emergencies, by article
- `pol-office-of-the-governor-gap`: The office of the Governor
- `pol-rajya-sabha-gap`: The Rajya Sabha
- `sci-blood-and-circulation-gap`: Blood and circulation
- `sci-nuclear-reactors-gap`: How a nuclear reactor works
- `soc-reservation-in-panchayats-gap`: Reservation in panchayats

## flashcards (36)
- `anc-buddhist-councils`: Buddhist councils and sacred sites
- `anc-deck-harappan-sites`: The Harappan civilisation: sites and finds
- `art-classical-dances`: Indian classical dances at a glance
- `art-indian-painting-traditions`: Folk and regional painting traditions
- `eco-banking-terms`: Banking and monetary terms to know
- `eco-deck-agriculture-and-food`: Farm prices, food security and farm schemes
- `eco-deck-budget-and-deficits`: Budget terms and deficits
- `eco-deck-external-sector`: Balance of payments and the rupee
- `eco-deck-money-and-banking`: Money, banking and RBI tools
- `env-deck-biodiversity-treaties`: Biodiversity treaties and lists
- `env-deck-climate-treaties`: Climate and ozone treaties
- `env-deck-ecology-basics`: Ecology basics: energy, pyramids and succession
- `env-deck-protected-areas`: Protected areas and the Wild Life Act
- `env-international-conventions`: Global environmental conventions at a glance
- `geo-deck-earth-interior-and-plates`: Inside the Earth: layers, waves, plates and rocks
- `geo-deck-monsoon-and-seasons`: The monsoon and India's seasons
- `geo-deck-rivers-of-india`: Rivers of India: sources and courses
- `geo-deck-soils-of-india`: Soils of India
- `geo-rivers-and-origins`: Indian rivers and where they rise
- `geo-soils-of-india`: Soils of India: types and traits
- `his-governors-general`: Governors-General and Viceroys: who did what
- `ir-international-groupings`: Groupings India belongs to
- `med-deck-mughal-administration`: Mughal administration under Akbar
- `mod-deck-british-constitutional-acts`: British-era Acts, 1773 to 1947
- `mod-deck-gandhian-movements`: Gandhi's movements, 1917 to 1942
- `pol-deck-constitutional-bodies`: Constitutional bodies and their Articles
- `pol-deck-fundamental-rights`: Fundamental Rights: the key Articles
- `pol-deck-local-government`: Panchayats and municipalities
- `pol-deck-president-and-governor`: The President and the Governor
- `pol-important-amendments`: Landmark amendments to the Constitution
- `pol-writs-and-remedies`: Writs and constitutional remedies
- `sci-deck-biotechnology-basics`: Biotechnology basics
- `sci-deck-indian-space-missions`: India in space: launchers and missions
- `sci-deck-light-and-sound`: Light and sound in everyday life
- `sci-deck-vitamins-and-nutrition`: Vitamins, minerals and deficiency
- `sci-isro-launch-vehicles`: ISRO's launch vehicles, from SLV to SSLV

## how-many-correct (24)
- `anc-buddhism-and-jainism`: Buddhism and Jainism: how many are correct?
- `anc-mauryas-and-ashoka-hmc`: The Mauryas and Ashoka: how many correct?
- `anc-sangam-age-hmc`: The Sangam age: how many correct?
- `art-classical-dances-hmc`: Classical dances of India: how many correct?
- `eco-banking-and-reserve-ratios-hmc`: Banks, reserve ratios and policy rates: how many correct?
- `eco-deficits-and-budget-terms-hmc`: Deficits and budget terms: how many correct?
- `eco-fiscal-and-monetary-institutions`: GST, MPC and Finance Commission: how many correct?
- `eco-msp-and-food-security-hmc`: MSP, procurement and food security: how many correct?
- `env-climate-treaties-hmc`: Climate treaties and India's targets: how many correct?
- `env-ecology-basics-how-many`: Ecology basics: how many are correct?
- `env-wetlands-and-ramsar-hmc`: Wetlands and the Ramsar Convention: how many correct?
- `geo-ocean-currents-tides-salinity-hmc`: Ocean currents, tides and salinity: how many correct?
- `geo-peninsular-rivers-hmc`: Peninsular rivers of India: how many correct?
- `his-national-movement-how-many`: National movement: how many are correct?
- `ir-un-principal-organs-hmc`: The principal organs of the UN: how many correct?
- `med-mughal-administration-hmc`: Mughal administration: how many correct?
- `mod-company-rule-acts-hmc`: Acts of the Company era: how many correct?
- `mod-congress-early-sessions-hmc`: Early sessions of the Indian National Congress: how many correct?
- `pol-panchayats-and-municipalities-hmc`: Panchayats and municipalities: how many correct?
- `pol-parliament-sessions-and-bills-hmc`: Parliament: sessions, sittings and bills: how many correct?
- `pol-president-election-and-powers-hmc`: The President: election and powers: how many correct?
- `sci-isro-launchers-and-orbits-hmc`: ISRO launchers, missions and orbits: how many correct?
- `sci-vitamins-and-nutrients-hmc`: Vitamins and deficiency diseases: how many correct?
- `soc-tribal-rights-laws-hmc`: Tribal rights: PESA, FRA and the Schedules: how many correct?

## index-card (4)
- `eco-global-gender-gap-index`: Global Gender Gap Index decoded
- `eco-global-hunger-index`: Global Hunger Index decoded
- `eco-human-development-index`: Human Development Index, decoded
- `eco-multidimensional-poverty-index`: Global Multidimensional Poverty Index, decoded

## landmark-case (23)
- `eco-mineral-royalty-case`: Mineral royalty and states' power to tax
- `env-godavarman-forest-case`: Godavarman and the meaning of "forest"
- `pol-berubari-reference-case`: The Berubari reference and ceding territory
- `pol-electoral-bonds-case`: The electoral bonds case
- `pol-golaknath-case`: Golaknath and the power to amend Fundamental Rights
- `pol-indra-sawhney-case`: Indra Sawhney and the 50% ceiling
- `pol-ir-coelho-case`: I.R. Coelho and the Ninth Schedule
- `pol-kesavananda-bharati`: Kesavananda Bharati and the basic structure
- `pol-kihoto-hollohan-case`: Kihoto Hollohan and the anti-defection law
- `pol-lily-thomas-case`: Lily Thomas and disqualification on conviction
- `pol-maneka-gandhi`: Maneka Gandhi and a fair procedure
- `pol-maneka-gandhi-case`: Maneka Gandhi and fair procedure under Article 21
- `pol-minerva-mills-case`: Minerva Mills and the limits on amending power
- `pol-njac-case`: The NJAC case and the appointment of judges
- `pol-puttaswamy-privacy-case`: Puttaswamy and the right to privacy
- `pol-shreya-singhal-case`: Shreya Singhal and online speech
- `pol-sr-bommai-case`: S. R. Bommai and Article 356
- `soc-indra-sawhney-case`: Indra Sawhney and OBC reservation
- `soc-navtej-johar-case`: Navtej Singh Johar and Section 377
- `soc-olga-tellis-case`: Olga Tellis and the right to livelihood
- `soc-sc-sub-classification-case`: Sub-classification of Scheduled Castes
- `soc-shayara-bano-case`: Shayara Bano and instant triple talaq
- `soc-unnikrishnan-case`: Unni Krishnan and the right to education

## link-web (4)
- `eco-msme-across-papers`: MSMEs across the syllabus
- `geo-water-across-papers`: Water across every Mains paper
- `his-colonial-railways`: Railways in colonial India, linked up
- `soc-migration-across-papers`: Migration across every Mains paper

## mnemonic (2)
- `anc-great-mughals-order`: The six Great Mughals in order
- `pol-preamble-sssdr`: What the Preamble declares India to be

## odd-one-out (24)
- `anc-dynasties-and-capitals-odd`: Dynasties and their capitals: find the odd one
- `anc-medieval-odd-one-out`: Ancient and medieval India: find the odd one
- `anc-texts-and-authors-odd`: Ancient texts and authors: find the odd one
- `art-heritage-odd-one-out`: Art and heritage: spot the odd one
- `art-music-and-instruments-odd`: Music and instruments: find the odd one
- `eco-crops-and-seasons-odd`: Crops and seasons: find the odd one
- `eco-economic-terms-odd`: Economic terms: find the odd one
- `eco-institutions-and-reports-odd`: Institutions and their reports: find the odd one
- `env-ecology-odd-one-out`: Environment: which one does not belong?
- `env-gases-and-pollutants-odd`: Gases and pollutants: find the odd one
- `env-species-and-habitats-odd`: Species and their homes: find the odd one
- `geo-env-odd-one-out`: Rivers, mountains and ecology: spot the odd one
- `geo-rivers-lakes-and-hills-odd`: Rivers, lakes and hills of India: find the odd one
- `geo-world-regions-odd`: World geography: find the odd one
- `ir-groupings-and-members-odd`: Groupings and their members: find the odd one
- `med-medieval-buildings-odd`: Medieval buildings and their builders: find the odd one
- `mod-national-movement-leaders-odd`: Leaders of the national movement: find the odd one
- `mod-organisations-and-founders-odd`: Organisations and their founders: find the odd one
- `pol-constitution-sources-odd`: Where Constitution features came from: find the odd one
- `pol-constitutional-and-statutory-bodies-odd`: Constitutional and statutory bodies: find the odd one
- `pol-writs-and-remedies-odd`: Writs and remedies: find the odd one
- `sci-biology-basics-odd`: Biology basics: find the odd one
- `sci-physics-and-chemistry-odd`: Physics and chemistry: find the odd one
- `soc-sociology-concepts-odd`: Concepts in Indian society: find the odd one

## optional-node (192)
- `ant-p1-01`: Anthropology paper 1, ant-p1-01: A definition of anthropology with its root words and its three distinguishing features.
- `ant-p1-02`: Anthropology paper 1, ant-p1-02: Social anthropology and sociology: three similarities, three differences, one Indian example.
- `ant-p1-03`: Anthropology paper 1, ant-p1-03: The four branches, each with its subject matter, two sub-fields and one method.
- `ant-p1-04`: Anthropology paper 1, ant-p1-04: Five distinctive human traits, marked biological or cultural or both.
- `ant-p1-05`: Anthropology paper 1, ant-p1-05: Four pre-Darwinian thinkers in one line each: Buffon, Erasmus Darwin, Cuvier, Lyell.
- `ant-p1-06`: Anthropology paper 1, ant-p1-06: Five builders of the synthesis and their main work, one line each.
- `ant-p1-11`: Anthropology paper 1, ant-p1-11: Five features that show Australopithecines were bipedal.
- `ant-p1-12`: Anthropology paper 1, ant-p1-12: Eight skull and body features of Homo erectus as a checklist.
- `ant-p1-13`: Anthropology paper 1, ant-p1-13: Ten Neanderthal skull and body features as a checklist.
- `ant-p1-21`: Anthropology paper 1, ant-p1-21: Three definitions of culture: Tylor, Kroeber and Kluckhohn, Geertz.
- `ant-p1-23`: Anthropology paper 1, ant-p1-23: Three definitions of marriage: Notes and Queries, Gough, Leach.
- `ant-p1-27`: Anthropology paper 1, ant-p1-27: Consanguinity and affinity with three examples each, and primary, secondary and tertiary kin.
- `ant-p1-35`: Anthropology paper 1, ant-p1-35: Four assumptions of classical evolutionism.
- `ant-p1-37`: Anthropology paper 1, ant-p1-37: Why functionalism arose: rejection of conjectural history, holism, fieldwork.
- `ant-p1-38`: Anthropology paper 1, ant-p1-38: Saussure's influence on Lévi-Strauss in three lines.
- `ant-p1-44`: Anthropology paper 1, ant-p1-44: A timeline of fieldwork: armchair era, Torres Strait 1898, Boas, Malinowski, Writing Culture.
- `ant-p2-09`: Anthropology paper 2, ant-p2-09: Varna versus jati in a four-row table: number, scale, basis, source.
- `ant-p2-22`: Anthropology paper 2, ant-p2-22: Five causes of tribal land alienation, colonial and modern.
- `anthropology/ant-p1-01`: None
- `anthropology/ant-p1-02`: None
- `anthropology/ant-p1-03`: None
- `anthropology/ant-p1-04`: None
- `anthropology/ant-p1-05`: None
- `anthropology/ant-p1-06`: None
- `anthropology/ant-p1-11`: None
- `anthropology/ant-p1-12`: None
- `anthropology/ant-p1-13`: None
- `anthropology/ant-p1-21`: None
- `anthropology/ant-p1-23`: None
- `anthropology/ant-p1-27`: None
- `anthropology/ant-p1-35`: None
- `anthropology/ant-p1-37`: None
- `anthropology/ant-p1-38`: None
- `anthropology/ant-p1-44`: None
- `anthropology/ant-p2-09`: None
- `anthropology/ant-p2-22`: None
- `geo-p1-01`: Geography paper 1, geo-p1-01: Davis's structure, process and stage, plus four factors added later.
- `geo-p1-02`: Geography paper 1, geo-p1-02: Direct and indirect sources of knowledge about the interior.
- `geo-p1-03`: Geography paper 1, geo-p1-03: Wegener: Pangaea, four kinds of evidence, and why the theory was rejected.
- `geo-p1-04`: Geography paper 1, geo-p1-04: Types of volcanoes (shield, composite, cinder, caldera, fissure) with one example each.
- `geo-p1-05`: Geography paper 1, geo-p1-05: Davis, Penck, King and Hack: one line each on how landscapes develop.
- `geo-p1-08`: Geography paper 1, geo-p1-08: Definition of monsoon and four regions where it occurs.
- `geo-p1-09`: Geography paper 1, geo-p1-09: Bergeron's air mass types as a table of source region, temperature and humidity.
- `geo-p1-12`: Geography paper 1, geo-p1-12: Natural and human causes of climate change in a two-column list.
- `geo-p1-14`: Geography paper 1, geo-p1-14: A temperature-depth graph for tropical, mid-latitude and polar seas.
- `geo-p1-15`: Geography paper 1, geo-p1-15: Wave terms: crest, trough, wavelength, fetch, swash and backwash, with one sketch.
- `geo-p1-16`: Geography paper 1, geo-p1-16: Marine resources in three columns: biotic, mineral, energy, with one Indian example each.
- `geo-p1-24`: Geography paper 1, geo-p1-24: Causes and features of the quantitative revolution in five points, with three key names.
- `geo-p1-33`: Geography paper 1, geo-p1-33: The rank-size rule as a formula and a log-log graph, with a primate pattern beside it.
- `geo-p1-38`: Geography paper 1, geo-p1-38: Threshold, range, order of goods and the isotropic plain, with one example each.
- `geo-p2-04`: Geography paper 2, geo-p2-04: Onset and advance on a map: heat low, monsoon trough, two branches, normal dates.
- `geo-p2-map`: Geography paper 2, geo-p2-map: The format of Question 1: number of places, words per note, what loses marks.
- `geography/geo-p1-01`: None
- `geography/geo-p1-02`: None
- `geography/geo-p1-03`: None
- `geography/geo-p1-04`: None
- `geography/geo-p1-05`: None
- `geography/geo-p1-08`: None
- `geography/geo-p1-09`: None
- `geography/geo-p1-12`: None
- `geography/geo-p1-14`: None
- `geography/geo-p1-15`: None
- `geography/geo-p1-16`: None
- `geography/geo-p1-24`: None
- `geography/geo-p1-33`: None
- `geography/geo-p1-38`: None
- `geography/geo-p2-04`: None
- `geography/geo-p2-map`: None
- `hist-p1-01`: History paper 1, hist-p1-01: Exploration versus excavation; vertical versus horizontal digs; stratigraphy.
- `hist-p1-02`: History paper 1, hist-p1-02: Primary versus secondary sources, and the problem of layered, orally composed texts.
- `hist-p1-03`: History paper 1, hist-p1-03: Pre-history versus proto-history, and four geographical factors behind site location.
- `hist-p1-04`: History paper 1, hist-p1-04: Neolithic features, Childe's 'Neolithic Revolution', and the gradualist critique.
- `hist-p1-05`: History paper 1, hist-p1-05: Discovery (who, where, when) and the three phases with approximate Mature Harappan dates.
- `hist-p1-06`: History paper 1, hist-p1-06: Six theories of decline, each with its proponent and one piece of evidence.
- `hist-p1-18`: History paper 1, hist-p1-18: Ashoka's titles, dates and the key sources, in three lines.
- `hist-p1-19`: History paper 1, hist-p1-19: Three sources for the Mauryan state with one strength and one limit each.
- `hist-p1-45`: History paper 1, hist-p1-45: R.S. Sharma's feudalism thesis as a six-step chain.
- `hist-p1-69`: History paper 1, hist-p1-69: Zat and sawar: meaning, purpose, and the three classes of mansabdars by sawar.
- `hist-p2-11`: History paper 2, hist-p2-11: A table of the three settlements: year, author, region, unit, owner, revision.
- `hist-p2-26`: History paper 2, hist-p2-26: Causes in four boxes: political, economic, military, social-religious, plus the trigger.
- `hist-p2-32`: History paper 2, hist-p2-32: Gandhi's South African years: satyagraha, Hind Swaraj, return in 1915.
- `history/hist-p1-01`: None
- `history/hist-p1-02`: None
- `history/hist-p1-03`: None
- `history/hist-p1-04`: None
- `history/hist-p1-05`: None
- `history/hist-p1-06`: None
- `history/hist-p1-18`: None
- `history/hist-p1-19`: None
- `history/hist-p1-45`: None
- `history/hist-p1-69`: None
- `history/hist-p2-11`: None
- `history/hist-p2-26`: None
- `history/hist-p2-32`: None
- `pa-p1-01`: Public administration paper 1, pa-p1-01: Three definitions of Public Administration (Wilson, White, Nigro and Nigro) and which view each ref
- `pa-p1-02`: Public administration paper 1, pa-p1-02: The context of Wilson's 1887 essay: spoils system, Garfield's assassination, the Pendleton Act.
- `pa-p1-03`: Public administration paper 1, pa-p1-03: Henry's five paradigms with rough dates, locus or focus, and one thinker each.
- `pa-p1-04`: Public administration paper 1, pa-p1-04: The setting of NPA: the late-1960s crises, Waldo, Minnowbrook 1968, Marini's 1971 volume.
- `pa-p1-05`: Public administration paper 1, pa-p1-05: The core assumptions of Public Choice: methodological individualism, rational self-interest, politi
- `pa-p1-07`: Public administration paper 1, pa-p1-07: Government versus governance in two lines.
- `pa-p1-08`: Public administration paper 1, pa-p1-08: Four causes behind the rise of NPM.
- `pa-p1-11`: Public administration paper 1, pa-p1-11: The three types of legitimate authority, each with its basis and one Indian example.
- `pa-p1-13`: Public administration paper 1, pa-p1-13: Four phases of the Hawthorne studies: years, design, finding.
- `pa-p1-15`: Public administration paper 1, pa-p1-15: Four classical principles Simon called proverbs, each with its opposite.
- `pa-p1-19`: Public administration paper 1, pa-p1-19: Maslow's pyramid and Alderfer's ERG side by side.
- `pa-p1-20`: Public administration paper 1, pa-p1-20: Four families of leadership theory as a timeline from the 1930s to the 1990s.
- `pa-p1-34`: Public administration paper 1, pa-p1-34: Agraria-Industria and fused-prismatic-diffracted as two labelled sketches.
- `psir-p1-01`: Psir paper 1, psir-p1-01: The meaning of political theory: polis, the 'is' and 'ought' questions, and conceptual analysis.
- `psir-p1-02`: Psir paper 1, psir-p1-02: The three traditional approaches with a strength and a weakness of each.
- `psir-p1-03`: Psir paper 1, psir-p1-03: Locke's limited state: consent, natural rights, trust and resistance.
- `psir-p1-04`: Psir paper 1, psir-p1-04: The classical Marxist state: Marx and Engels, Engels's Origin, Lenin's withering away.
- `psir-p1-05`: Psir paper 1, psir-p1-05: Why a post-colonial theory: colonial legacies and Said's Orientalism.
- `psir-p1-07`: Psir paper 1, psir-p1-07: Rawls's case against utilitarianism in three lines.
- `psir-p1-12`: Psir paper 1, psir-p1-12: Hohfeld's four incidents of rights, each with an example.
- `psir-p1-14`: Psir paper 1, psir-p1-14: Four classical views: Athens, Rousseau, protective, developmental.
- `psir-p1-25`: Psir paper 1, psir-p1-25: Hind Swaraj in five points: form, critique of civilisation, railways-lawyers-doctors, true swaraj, English rule wi
- `psir-p1-26`: Psir paper 1, psir-p1-26: Ambedkar's critique of caste in five points: division of labourers, graded inequality, endogamy, shastras, loss of
- `psir-p1-35`: Psir paper 1, psir-p1-35: Gramsci's puzzle and answer in three lines.
- `psir-p1-36`: Psir paper 1, psir-p1-36: Four features of totalitarianism in Arendt.
- `psir-p1-44`: Psir paper 1, psir-p1-44: Constitutional basis of judicial review in India: three articles.
- `psir-p1-54`: Psir paper 1, psir-p1-54: Federal and unitary features of the Constitution in two columns, with Articles.
- `psir-p2-08`: Psir paper 2, psir-p2-08: Idealism in five points: human nature, law, League, interdependence, normative aim.
- `psir-p2-28`: Psir paper 2, psir-p2-28: Four phases of Indian foreign policy with one defining event each.
- `psir-p2-36`: Psir paper 2, psir-p2-36: Timeline of India-US relations from 1954 to today, with ten markers.
- `psir-p2-38`: Psir paper 2, psir-p2-38: Timeline: 1950, 1954, 1959, 1962, 1976, 1988, 1993, 1996, 2003, 2005, 2017, 2020, 2024.
- `psir/psir-p1-01`: None
- `psir/psir-p1-02`: None
- `psir/psir-p1-03`: None
- `psir/psir-p1-04`: None
- `psir/psir-p1-05`: None
- `psir/psir-p1-07`: None
- `psir/psir-p1-12`: None
- `psir/psir-p1-14`: None
- `psir/psir-p1-25`: None
- `psir/psir-p1-26`: None
- `psir/psir-p1-35`: None
- `psir/psir-p1-36`: None
- `psir/psir-p1-44`: None
- `psir/psir-p1-54`: None
- `psir/psir-p2-08`: None
- `psir/psir-p2-28`: None
- `psir/psir-p2-36`: None
- `psir/psir-p2-38`: None
- `public-administration/pa-p1-01`: None
- `public-administration/pa-p1-02`: None
- `public-administration/pa-p1-03`: None
- `public-administration/pa-p1-04`: None
- `public-administration/pa-p1-05`: None
- `public-administration/pa-p1-07`: None
- `public-administration/pa-p1-08`: None
- `public-administration/pa-p1-11`: None
- `public-administration/pa-p1-13`: None
- `public-administration/pa-p1-15`: None
- `public-administration/pa-p1-19`: None
- `public-administration/pa-p1-20`: None
- `public-administration/pa-p1-34`: None
- `soc-p1-01`: Sociology paper 1, soc-p1-01: Five marks of modernity, each with one line of explanation.
- `soc-p1-02`: Sociology paper 1, soc-p1-02: A definition of sociology and the formal versus synthetic debate on its scope, with two thinkers on each side.
- `soc-p1-03`: Sociology paper 1, soc-p1-03: The steps of the scientific method and the features of scientific knowledge.
- `soc-p1-04`: Sociology paper 1, soc-p1-04: Comte's three stages and hierarchy of sciences.
- `soc-p1-05`: Sociology paper 1, soc-p1-05: Fact versus value, with one example of each on the same issue.
- `soc-p1-08`: Sociology paper 1, soc-p1-08: The base and superstructure model as a labelled two-layer diagram, with forces and relations of production in 
- `soc-p1-09`: Sociology paper 1, soc-p1-09: The definition of a social fact with its two features, and three everyday examples.
- `soc-p1-10`: Sociology paper 1, soc-p1-10: Weber's definition of social action and Verstehen in three lines.
- `soc-p1-11`: Sociology paper 1, soc-p1-11: The unit act: four elements.
- `soc-p1-12`: Sociology paper 1, soc-p1-12: Merton's three rejected postulates of functionalism.
- `soc-p1-13`: Sociology paper 1, soc-p1-13: Significant symbols, role-taking, mind and self: one line each.
- `soc-p1-15`: Sociology paper 1, soc-p1-15: A definition of stratification and four systems: slavery, estate, caste, class.
- `soc-p1-17`: Sociology paper 1, soc-p1-17: Vertical, horizontal, inter- and intragenerational mobility: one line each.
- `soc-p1-24`: Sociology paper 1, soc-p1-24: Durkheim's definition of religion and the sacred and profane in four lines.
- `soc-p2-01`: Sociology paper 2, soc-p2-01: Indology: sources, assumptions and main scholars.
- `soc-p2-02`: Sociology paper 2, soc-p2-02: Srinivas's training and fieldwork: teachers, Coorgs, Rampura, in three lines.
- `soc-p2-03`: Sociology paper 2, soc-p2-03: Core ideas of the Marxist perspective: mode of production, class, conflict, dialectic.
- `soc-p2-09`: Sociology paper 2, soc-p2-09: Ghurye's six features of caste as a numbered list with one current example each.
- `sociology/soc-p1-01`: None
- `sociology/soc-p1-02`: None
- `sociology/soc-p1-03`: None
- `sociology/soc-p1-04`: None
- `sociology/soc-p1-05`: None
- `sociology/soc-p1-08`: None
- `sociology/soc-p1-09`: None
- `sociology/soc-p1-10`: None
- `sociology/soc-p1-11`: None
- `sociology/soc-p1-12`: None
- `sociology/soc-p1-13`: None
- `sociology/soc-p1-15`: None
- `sociology/soc-p1-17`: None
- `sociology/soc-p1-24`: None
- `sociology/soc-p2-01`: None
- `sociology/soc-p2-02`: None
- `sociology/soc-p2-03`: None
- `sociology/soc-p2-09`: None

## pair-up (26)
- `anc-ancient-texts-and-authors`: Match the ancient text to its author
- `anc-dynasties-and-founders-pair`: Dynasties and their founders
- `anc-harappan-sites-and-finds-pair`: Harappan sites and what they are known for
- `art-folk-dances-and-states`: Match the folk dance to its state
- `art-folk-paintings-and-states-pair`: Folk painting styles and their states
- `art-temples-and-dynasties`: Temples and the dynasties behind them
- `eco-committees-and-subjects-pair`: Economic committees and their subjects
- `eco-regulators-and-sectors-pair`: Regulators and the sectors they watch
- `eco-reports-and-publishers-pair`: Reports and indices and who publishes them
- `env-national-parks-and-states-pair`: National parks and their states
- `env-pollutants-and-effects-pair`: Pollutants and their main effects
- `env-tiger-reserves-states`: Match the tiger reserve to its state
- `geo-cities-and-rivers-pair`: Cities and the rivers they stand on
- `geo-local-winds-pair`: Local winds and showers and where they occur
- `geo-straits`: Match the strait to what it separates
- `geo-straits-of-the-world-pair`: Straits and the waters they join
- `ir-headquarters-pair`: Organisations and their headquarters
- `med-visitors-and-rulers-pair`: Foreign visitors and the rulers they saw
- `mod-newspapers-and-founders-pair`: Newspapers and the people behind them
- `mod-satyagrahas-and-causes-pair`: Satyagrahas and campaigns and their causes
- `pol-articles-and-what-they-say-pair`: Articles and what they say
- `pol-constitution-borrowed-features`: Borrowed features of the Constitution
- `pol-schedules-of-the-constitution-pair`: Schedules of the Constitution and what they hold
- `sci-diseases-and-their-causes-pair`: Diseases and what causes them
- `sci-instruments-and-uses-pair`: Instruments and what they measure
- `soc-commissions-on-social-groups-pair`: Commissions and committees on social groups

## rank-it (2)
- `geo-largest-states-by-area`: India's largest states by area
- `pol-minimum-age-for-offices`: Minimum ages in the Constitution

## scheme-snapshot (4)
- `eco-atal-pension-yojana`: Atal Pension Yojana at a glance
- `eco-mgnrega`: MGNREGA: a legal right to work
- `eco-pm-jan-dhan-yojana`: PM Jan Dhan Yojana: banking for all
- `eco-pm-kisan`: PM-KISAN: income support for farmers

## story-beats (3)
- `his-champaran-satyagraha`: Champaran, 1917: the indigo fields
- `his-poona-pact-1932`: The Poona Pact, 1932
- `soc-vidyasagar-widow-remarriage`: Vidyasagar and the right to remarry

## timeline-shuffle (25)
- `anc-dates-from-saka-to-chola-tl`: From the Saka era to the Chola temples
- `anc-delhi-sultanate-dynasties`: Delhi Sultanate dynasties to the Mughals
- `anc-foreign-travellers-to-india`: Foreign travellers who wrote about India
- `art-world-heritage-inscriptions-tl`: When Indian sites joined the World Heritage List
- `eco-digital-payments-tl`: Digital payments and identity
- `eco-economic-reforms-tl`: Milestones of economic policy
- `eco-planning-and-institutions-tl`: Planning and financial institutions
- `env-conservation-programmes-tl`: Conservation programmes in India
- `env-environment-laws-tl`: India's environment laws
- `env-global-environment-treaties-tl`: Global environment treaties
- `geo-railways-and-metros-tl`: Railways and metros in India
- `his-acts-1773-1858`: Company-era Acts in order
- `his-revolt-to-congress`: From the Revolt to the Congress
- `ir-founding-of-groupings-tl`: When international groupings were founded
- `ir-india-foreign-policy-milestones`: Milestones in India's foreign policy
- `ir-india-foreign-policy-tl`: Milestones of India's foreign policy
- `med-mughal-buildings-tl`: Mughal buildings in order
- `mod-congress-and-mass-movements-tl`: The Congress and mass movements
- `mod-reform-organisations-tl`: Social and religious reform organisations
- `pol-landmark-amendments-tl`: Landmark Constitution amendments
- `pol-making-the-constitution-tl`: Making the Constitution and the first steps
- `pol-rights-based-laws-tl`: Rights-based laws in India
- `sci-indian-space-milestones-tl`: Milestones of India's space programme
- `sci-scientific-discoveries-tl`: Discoveries that changed science
- `soc-social-reform-laws-tl`: Social reform laws in order

## trap-spotter (24)
- `anc-buddhism-and-jainism-trap`: Buddhism and Jainism: spot the trap
- `anc-harappan-civilisation-trap`: The Harappan civilisation: spot the trap
- `art-painting-traditions-trap`: Painting traditions of India: spot the trap
- `eco-balance-of-payments-and-fdi-trap`: Balance of payments, FDI and FPI: spot the trap
- `eco-capital-markets-trap`: Capital markets and regulators: spot the trap
- `eco-inflation-and-price-indices-trap`: Inflation and price indices: spot the trap
- `env-ecology-basics-trap`: Ecology basics: spot the trap
- `env-iucn-cites-and-species-trap`: IUCN, CITES and species protection: spot the trap
- `env-laws-reserves-and-treaties`: Environment: laws, reserves and treaties
- `geo-atmosphere-and-winds-trap`: Atmosphere and winds: spot the trap
- `geo-indian-soils-trap`: Soils of India: spot the trap
- `ir-borders-and-boundary-lines`: Borders and boundary lines: spot the trap
- `ir-regional-groupings-trap`: Regional groupings and India: spot the trap
- `med-vijayanagara-and-bahmani-trap`: Vijayanagara and the Bahmani kingdom: spot the trap
- `mod-gandhian-movements-trap`: Gandhi's early campaigns and mass movements: spot the trap
- `mod-social-reform-movements-trap`: Social and religious reform movements: spot the trap
- `pol-constitutional-bodies-trap`: Constitutional and statutory bodies: spot the trap
- `pol-emergency-provisions-trap`: Emergency provisions: spot the trap
- `pol-parliament-and-offices-traps`: Spot the trap: Parliament and key offices
- `pol-supreme-court-and-high-courts-trap`: Supreme Court and High Courts: spot the trap
- `sci-biotechnology-basics-trap`: Biotechnology basics: spot the trap
- `sci-health-and-disease-traps`: Health and disease: spot the trap
- `sci-solar-system-trap`: The solar system: spot the trap
- `soc-education-rte-and-nep-trap`: Education: RTE and the National Education Policy: spot the trap

## two-levels (4)
- `eco-cash-reserve-ratio`: Cash Reserve Ratio, explained twice
- `eth-conflict-of-interest`: Conflict of interest, explained twice
- `eth-emotional-intelligence`: Emotional intelligence, explained twice
- `eth-probity`: Probity, explained twice

## two-truths (24)
- `anc-chola-state-tt`: The Chola state: two truths and a lie
- `anc-post-mauryan-kingdoms-tt`: After the Mauryas: two truths and a lie
- `art-heritage-two-truths`: Art and heritage: two truths and a lie
- `art-world-heritage-sites-india-tt`: World Heritage Sites in India: two truths and a lie
- `eco-direct-and-indirect-taxes-tt`: Direct and indirect taxes: two truths and a lie
- `eco-industry-and-msmes-tt`: Industry and MSMEs: two truths and a lie
- `eco-poverty-and-employment-measures-tt`: Measuring poverty and jobs: two truths and a lie
- `env-national-parks-and-tiger-reserves-tt`: National parks and tiger reserves: two truths and a lie
- `env-renewable-energy-tt`: Renewable energy: two truths and a lie
- `geo-islands-of-india`: India's islands: spot the false one
- `geo-minerals-and-industries-tt`: Minerals and industries of India: two truths and a lie
- `geo-world-physical-features-tt`: World physical features: two truths and a lie
- `ir-arms-control-regimes-tt`: Arms control regimes and India: two truths and a lie
- `ir-un-and-global-bodies`: The UN and global bodies: find the lie
- `med-bhakti-and-sufi-traditions-tt`: Bhakti and Sufi traditions: two truths and a lie
- `mod-governors-general-and-viceroys-tt`: Governors-General and Viceroys: two truths and a lie
- `mod-press-and-education-colonial-tt`: Press and education under colonial rule: two truths and a lie
- `pol-amending-the-constitution-tt`: Amending the Constitution: two truths and a lie
- `pol-parliamentary-committees-tt`: Parliamentary committees: two truths and a lie
- `pol-preamble-and-citizenship-tt`: The Preamble and citizenship: two truths and a lie
- `sci-chemistry-in-daily-life-tt`: Chemistry in daily life: two truths and a lie
- `sci-computing-and-ai-tt`: Computing and artificial intelligence: two truths and a lie
- `sci-everyday-biology-and-physics`: Everyday science: find the false statement
- `soc-laws-for-women-tt`: Laws for women's rights: two truths and a lie

## union-state-list (2)
- `pol-seventh-schedule-lesser-known`: Seventh Schedule: the less obvious subjects
- `pol-seventh-schedule-sort`: Union, State or Concurrent?

## versus (4)
- `eco-fiscal-vs-monetary-policy`: Fiscal policy versus monetary policy
- `geo-western-vs-eastern-ghats`: Western Ghats versus Eastern Ghats
- `pol-lok-sabha-vs-rajya-sabha`: Lok Sabha versus Rajya Sabha
- `sci-nuclear-fission-vs-fusion`: Nuclear fission versus nuclear fusion

## who-am-i (3)
- `anc-ancient-rulers`: Guess the ancient ruler
- `his-national-leaders-who-am-i`: Who am I? Leaders of the national movement
- `sci-indian-scientists`: Guess the Indian scientist

## word-bank (2)
- `ess-essay-vocabulary`: Essay vocabulary in two languages
- `eth-gs4-core-terms`: GS4 core values in two languages
